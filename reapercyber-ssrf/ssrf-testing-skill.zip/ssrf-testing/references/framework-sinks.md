## 13. CMS / Framework / Platform → Bilinen SSRF Sink Eşleme Tablosu

**Önemli düzeltme:** Aşağıdaki eşlemeler **varsayılan/tipik özellik**
bilgisidir, her sürümde/yapılandırmada zafiyet olduğu anlamına
gelmez. "Davranış Bağımlılığı" sütunu bu eşlemenin default mu,
configuration/version'a mı bağlı olduğunu belirtir.

| Platform | Bilinen SSRF-Prone Özellik | Davranış Bağımlılığı |
|---|---|---|
| WordPress | Pingback mekanizması (`xmlrpc.php`, `pingback.ping`), `wp_remote_get()` kullanan eklentiler | Default behavior (pingback) + application-specific (eklentiler) |
| Jira / Confluence (Atlassian) | Webhook/entegrasyon URL alanları, "gadget" harici veri kaynağı tanımlama | Version-dependent |
| GitLab | "Import project from URL", webhook URL tanımlama, CI/CD entegrasyonları | Default behavior — bkz. §2 kategori 10 (repository import) |
| Jenkins | Plugin webhook'ları, "harici bir URL'den yapılandırma çek" özellikleri | Application-specific (plugin'e bağlı) |
| Grafana | "Data source" tanımlama (bir dashboard'un veri çektiği URL) | Default behavior — klasik bir SSRF sink örneğidir |
| Kurumsal admin panelleri (genel — Jira/Confluence, self-hosted CRM/ERP, identity/SSO yönetim araçları) | SMTP relay / LDAP dizini / özel SSO endpoint'i yapılandırma + "Test Connection" butonu | Default behavior — bkz. §2 kategori 14 |
| Self-hosted monitoring/observability araçları (Prometheus Alertmanager, Zabbix, Nagios benzeri) | Alert/notification hedefi olarak özel bir webhook/SMTP/LDAP endpoint'i tanımlama | Default behavior — bkz. §2 kategori 14 |
| Kibana / Elasticsearch | Bazı plugin/entegrasyon URL alanları | Application-specific |
| Redmine / Trac | Harici bağlantı/repository URL alanları | Application-specific |
| Slack-benzeri mesajlaşma platformları (self-hosted, örn. Mattermost, Rocket.Chat) | Link preview/"unfurl" özelliği | Default behavior — bkz. §2 kategori 1 |
| Discourse (forum yazılımı) | Link önizleme, "oneboxing" (bir URL'i zengin içerik kartına çevirme) | Default behavior |
| WordPress/Drupal/Joomla eklenti ekosistemi — "URL'den resim/medya çek" | Medya kütüphanesi "URL'den yükle" özelliği | Application-specific (çekirdek + eklenti) |
| wkhtmltopdf / Puppeteer / headless Chrome tabanlı PDF/rapor üretimi | HTML render sırasında harici kaynak (resim/script/iframe) çekme | Default behavior — bkz. §2 kategori 3 |
| ImageMagick | Bazı delegate/coder'lar (örn. eski `MSL`/`MVG` coder'ları) URL tabanlı kaynak çekebilir | Version-dependent (modern sürümlerde `policy.xml` ile kısıtlanabilir) |
| Apache Solr | "Remote streaming" özelliği (`stream.url` parametresi) | Configuration-dependent (varsayılan olarak bazı sürümlerde kapalı) |
| Shopify/e-ticaret platformları — "webhook" ve "app entegrasyonu" URL'leri | Uygulama mağazası entegrasyon URL'leri | Application-specific |
| OAuth/OIDC Identity Provider entegrasyonları | "Discovery URL"/"metadata URL" alanı (`.well-known/openid-configuration` çekimi) | Default behavior — bkz. §2 kategori 7 |
| SAML Service Provider'lar | "IdP metadata URL'i" alanı | Default behavior |
| Video transcoding servisleri (self-hosted, örn. bazı medya sunucu yazılımları) | "URL'den video indir/işle" | Default behavior — bkz. §2 kategori 11 |
| Monitoring/uptime-check araçları (self-hosted) | "İzlenecek URL" tanımlama — genelde kasıtlı bir özellik | Default behavior — bkz. §6.1 yetki context'i |
| RSS/Atom feed okuyucuları (self-hosted) | Feed URL'i çekme | Default behavior |
| PDF imzalama/doğrulama servisleri | "Doğrulama URL'i"/"zaman damgası sunucusu URL'i" alanı | Application-specific |
| Java tabanlı enterprise uygulamalar (genel) | `URLConnection`/`HttpURLConnection` üzerinden URL açan herhangi bir özellik (çok geniş bir dosya/protokol şeması desteği sunar — `file://`, `jar://`, `netdoc://` dahil, bkz. §12.5) | Default behavior — Java'nın URL handling mimarisi diğer dillere göre daha geniş protokol desteği sunar |
| PHP tabanlı uygulamalar (genel, `allow_url_fopen`/cURL) | `file_get_contents()`, `fopen()`, cURL ile URL açan herhangi bir özellik — geniş protokol şeması desteği (`gopher://` dahil, cURL build'ine bağlı) | Configuration-dependent (`allow_url_fopen` ayarına bağlı) |
| .NET tabanlı uygulamalar | `HttpClient`/`WebRequest` ile URL açan özellikler | Default behavior — modern `HttpClient` bazı eski şemaları (`file://`) desteklemez |
| Webmail/e-posta istemcileri (self-hosted) | "Uzak resim yükleme" (e-posta içindeki harici resimleri sunucu tarafında proxy'leyerek gösterme — gizlilik amaçlı bir özellik, ama SSRF riski taşır) | Default behavior |
| API Gateway / BFF katmanları (genel) | Dinamik upstream/route tanımlama — bkz. §11 microservice notu | Application-specific |
| n8n / Node-RED / Zapier-benzeri no-code otomasyon araçları | "HTTP Request" node'u — **kasıtlı ve dokümante edilmiş** bir SSRF-benzeri özellik | Default behavior — bkz. §6.1, asıl soru yetkilendirme/hedef kısıtlaması |
| Swagger UI / Postman / API dokümantasyon-test araçları | "Import from URL" ile OpenAPI/Swagger spesifikasyonunu bir URL'den çekme özelliği | Default behavior — bkz. §2 kategori 10 (repository/API-spec import) |

### 13.1 PDF/HTML Render Zincirlerinde Derinlemesine Exploitation

`wkhtmltopdf`/Puppeteer/headless Chrome gibi HTML-render-to-PDF/image
araçları, yukarıdaki tabloda tek satır olarak geçse de, SSRF'in
ötesine geçebilen üç ayrı yapılandırma-bağımlı zincir sunar:

- **wkhtmltopdf `--enable-local-file-access` ile `file://` + `http://`
  kombinasyonu:** Bu bayrak açıksa, render edilen HTML içinden
  `file://` şemasıyla yerel dosya okunabilir (§12.2 ile aynı impact)
  **ve** bu iki farklı şema aynı render işleminde birlikte
  kullanılabilir — örn. `file://` ile okunan bir dosyanın içeriği,
  aynı render sürecinde `http://` ile canary'ye POST edilen bir
  formun içine enjekte edilerek blind bir dosya-okuma senaryosunda
  bile exfiltration sağlanabilir (SSRF ile dosya içeriğini "response'a
  yansıtma" imkanı olmasa bile, bir sonraki `http://` isteğinin
  body'sine gömülerek OOB ile dışarı taşınabilir).
- **Puppeteer/headless Chrome — `--no-sandbox` + `--remote-debugging-
  port` kombinasyonu ile SSRF → RCE zinciri:** Eğer render işlemini
  yürüten Chrome instance'ı bu iki bayrakla başlatılmışsa VE
  debugging portu (genelde `9222`) internal ağdan erişilebilirse, bir
  SSRF bu debugging port'una ulaşıp Chrome DevTools Protocol (CDP)
  üzerinden **doğrudan komut çalıştırmaya kadar** giden bir zincir
  kurabilir (CDP'nin `Page.navigate`/`Runtime.evaluate` gibi
  metotları, sandbox kapalıyken dosya sistemi erişimine kadar
  genişleyebilir). Bu, §12.3'teki "protokol smuggling" mantığının
  Chrome'un kendi debug protokolüne uygulanmış bir örneğidir — dict/
  gopher yerine CDP'nin WebSocket tabanlı JSON-RPC'si smuggle edilir.
- **LaTeX rendering — `\input{|command}` deseni (az bilinen ama
  kritik bir alt-vektör):** Bazı LaTeX motorları (özellikle
  `shell-escape` etkinse) `\input{|<komut>}` sözdizimiyle bir komutun
  çıktısını dosya içeriği gibi işleyebilir — bu SSRF'in kendisi değil
  bir komut enjeksiyonudur, ama HTML/LaTeX render zincirlerinde
  (örn. bir "URL'den PDF üret" özelliğinin arka planda LaTeX
  kullanması) aynı sink'in her ikisine de (SSRF + command injection)
  açık olabileceği unutulmamalı — ikisi ayrı bulgular olarak
  raporlanmalı, kök neden aynı render zinciri olsa da.
