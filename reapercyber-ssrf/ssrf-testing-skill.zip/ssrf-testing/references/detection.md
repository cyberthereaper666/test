## 5. Generic SSRF Detection

### Kavramsal Zincir — Outbound Kanıtı ile Hedef Attribution Ayrı

```
Reflection (URL parametre olarak kabul ediliyor mu?)
   ↓
Parsing (URL formatı doğrulanıyor mu, hata vermiyor mu?)
   ↓
Outbound attempt (sunucu gerçekten bir bağlantı deniyor mu?)
   ↓
Reachability (bağlantı hedefe ulaşıyor mu — OOB kanıtı)
   ↓
Negatif kontrol doğrulaması (§5.1 — geçersiz bir hedef FARKLI davranıyor mu?)
   ↓
Target attribution     (hangi ağ/hedef — ayrı bir aşama, bkz. §7 Fingerprinting)
```

Bu diyagram bir kanıt **olgunlaşma** sürecini gösterir. "Confirmed"
etiketi için gereken minimum kanıt seti §8.4'te tanımlıdır.

### İlk Tarama — Kendi Kontrolündeki Domain ile Canary Probe (Birincil Yöntem)

SSRF'de "polyglot fuzzing" (SSTI/EL'deki gibi) **birincil yöntem
değildir** — SSRF'nin en güvenilir ve en düşük false-positive riskli
ilk tarama yöntemi, doğrudan **kendi kontrolündeki bir OOB domain'i**
ile canary probe göndermektir (bkz. §9.3 interactsh-client kurulumu,
test oturumunun en başında başlatılmalıdır):

```
http://<benzersiz-alt-domain>.oast.fun/
https://<benzersiz-alt-domain>.oast.fun/
```

Her aday parametreye **biricik bir subdomain/path** ile bu canary
gönderilir (örn. `param1.oast.fun`, `param2.oast.fun`) — bu, hangi
parametrenin gerçekten outbound isteği tetiklediğini birebir
eşleştirmeyi sağlar (SSTI/EL'deki "canary marker" prensibinin ağ
seviyesindeki karşılığı).

### Pozitif Sayılma Kuralı — En Az Bir Geçerli Evidence Kanalı

**Netleştirme:** Bir probe'un **outbound evidence** sayılması için
aşağıdaki iki kanaldan **en az biri** yeterlidir — ikisinin birden
bulunması gerekmez, yalnızca ikisi birden bulunursa daha güçlü bir
kanıt oluşturur (§8.3'teki gibi ayrı evidence kategorileri sayılır):

1. **Full/reflected evidence:** Hedef sunucudan (interactsh canary
   domain'inden) dönen response'un içeriği (veya bir kısmı) hedef
   uygulamanın kendi response'unda **görünüyor**.
2. **OOB evidence:** interactsh log'unda canary domain'ine gelen bir
   DNS lookup **ve/veya** HTTP isteği kaydı **var** (bkz. §9.3).

Yalnızca "parametre kabul edildi, hata vermedi" tek başına **hiçbir
evidence kategorisine girmez** — bu yalnızca P1 (parsing) kanıtıdır,
outbound attempt kanıtı değildir.

### Aşamalı Generic Probe Sırası

1. **Marker-only / format baseline:** Geçerli bir URL formatı
   (`https://example.com`) ile normal davranışı öğren.
2. **Canary — HTTP(S) doğrudan:**
   ```
   http://<canary1>.oast.fun
   https://<canary2>.oast.fun
   ```
3. **Canary — şema/format varyasyonları (parametre bir tam URL değil
   de yalnızca hostname/path bekliyor olabilir, bkz. §6 Context
   Detection):**
   ```
   <canary3>.oast.fun                    (şemasız, host-only context)
   //<canary4>.oast.fun                  (protocol-relative)
   <canary5>.oast.fun/path               (path fragment context)
   ```
4. **Localhost/internal reachability probe (P2'den kavramsal olarak
   AYRI bir soru — timing/hata farkı üzerinden dolaylı, henüz cloud
   metadata'ya geçilmeden genel bir "internal erişim var mı" testi):**

   **Gerçek loopback adresleri (RFC gereği loopback — bu grup için
   normal hedefte network stack'i istisnasız loopback'e yönlendirir):**
   ```
   http://127.0.0.1
   http://localhost
   http://[::1]
   ```
   **"Unspecified address" (`0.0.0.0`, `[::]`) — TEKNİK DÜZELTME:**
   `0.0.0.0` (IPv4) ve `[::]` (IPv6) RFC gereği **loopback değildir**,
   "belirtilmemiş adres" (unspecified/any address) anlamına gelir —
   normalde bir sunucunun **dinlediği** (bind ettiği) tüm arayüzleri
   ifade eder, bir **istemcinin bağlanacağı** bir hedef olarak
   tanımlı değildir. Ama pratikte önemli bir **istisna** vardır:
   birçok işletim sistemi/network stack'i, `0.0.0.0`'a **çıkış
   (outbound connect) hedefi** olarak bağlanma denemesini kernel
   seviyesinde loopback'e (`127.0.0.1`) yönlendirir — bu davranış
   RFC'de garanti edilmez, **işletim sistemine/network stack'ine
   özgüdür** ve bu yüzden `0.0.0.0`/`[::]` gerçek dünyada sık
   karşılaşılan, **ampirik olarak doğrulanması gereken** bir
   SSRF/loopback-bypass probe'udur — teknik olarak "loopback" değil
   "genellikle loopback'e eşdeğer davranan unspecified adres" olarak
   ele alınmalıdır:
   ```
   http://0.0.0.0
   http://[::]
   ```
   Bu ayrım önemlidir çünkü bir hedefte `127.0.0.1` engellenmiş ama
   `0.0.0.0` engellenmemiş olabilir (blacklist yalnızca literal
   "loopback" adreslerini tanıyıp "unspecified" adresi tanımıyor
   olabilir) — bu da B17'nin (CIDR/loopback range genişletmesi)
   kavramsal bir uzantısıdır, ayrı bir bypass fırsatı olarak
   değerlendirilmelidir.

   Bu probe'lar canary'den **farklı** bir soruya cevap arar — canary
   "sunucu dışa bir istek atıyor mu?" (P2a/P2b — resolution/connection attempt)
   sorusuna cevap verirken, bu probe'lar "sunucu kendi loopback'ine/
   internal ağına erişebiliyor mu?" (internal reachability) sorusuna
   cevap verir. Bunlar aynı P2 kategorisi **değildir** — bir hedefin
   dış dünyaya (canary) çıkabilmesi, illa kendi loopback'ine
   erişebileceği anlamına gelmez (bazı egress-filtering
   konfigürasyonları dış trafiğe izin verirken loopback'e giden
   trafiği farklı işleyebilir) ve tam tersi de mümkündür — bu yüzden
   ikisi ayrı evidence kategorisidir, biri diğerinin yerine geçmez.
5. **Error-based differential:** Bariz geçersiz bir hedef
   (`http://this-host-does-not-exist-<random>.invalid`) ile geçerli
   canary'nin ürettiği hata mesajı/status code/timing farkını
   karşılaştır (bkz. §5.1).

### 5.1 Negatif Kontrol Nasıl Kurulur

**Differential comparison (birincil yöntem):**
```
Canary (geçerli, kendi kontrolünde):  http://<canary>.oast.fun
   → beklenen: interactsh log'unda kayıt VAR
Negatif kontrol (kasıtlı çözümlenemez):
   http://this-host-does-not-exist-<random>.invalid
   → beklenen: interactsh log'unda kayıt YOK, muhtemelen farklı bir
     hata mesajı/status code (DNS resolution failure)
```

Bu iki senaryonun **response davranışı farklıysa** (farklı status
code, farklı hata mesajı, farklı timing) → bu, sunucunun gerçekten
DNS çözümlemesi + bağlantı denemesi yaptığının güçlü bir dolaylı
kanıtıdır (semi-blind SSRF sinyali) — OOB kanıtı olmasa bile. **Not:**
Bu sinyal bir **detection** aracı olarak güçlüdür (bu aşamada amaç
budur), ama **classification** (confirmed/probable) kararı origin
attribution koşuluna bağlıdır — bkz. §8.4.

**İkinci negatif kontrol — kapalı bir port:**
```
http://<canary>.oast.fun:9999   (canary domain'inde dinlenmeyen bir port)
   → beklenen: "connection refused" tarzı FARKLI bir hata (DNS
     çözümlendi ama bağlantı reddedildi)
```
Bu üçlü karşılaştırma (geçerli host+açık port / geçerli host+kapalı
port / geçersiz host) sunucunun **DNS çözümleme aşaması** ile
**TCP bağlantı aşamasını** ayırt etmeyi sağlar — bu ayrım, §7
Fingerprinting ve §8 WAF/filtre bypass için kritik bir temel oluşturur
(bir filtre DNS seviyesinde mi çalışıyor yoksa bağlantı seviyesinde
mi, sorusunun cevabı).
