### 12.16 [Infrastructure/Proxy-Mediated SSRF] Reverse Proxy / API Gateway Misconfigürasyonu — Absolute-URI ve SNI Routing İstismarı

**Kategori notu — bu skill'i uygulayan agent için önemli bir
hatırlatma:** Buraya kadarki tüm profiller (§12.1-§12.15)
**Application-level SSRF** modeline dayanır: `parametre → uygulama
kodu → HTTP client çağrısı`. Bu bölüm ise farklı bir kategoridir —
**Infrastructure/Proxy-Mediated SSRF**: `saldırgan isteği → proxy/
gateway'in kendi routing mantığı → keyfi upstream`. Bir hedefte
§2'deki application-level sink taraması (URL parametresi, webhook
alanı vb.) **hiçbir aday bulamasa bile**, bu, testin bittiği anlamına
gelmez — önündeki reverse proxy/API gateway katmanı da ayrıca bu
kategori altında test edilmelidir; ikisi birbirinin yerine geçmez.

Bu, klasik "parametre kontrol edilebiliyor" SSRF modelinden **farklı**
bir hedef profilidir: burada zafiyet bir uygulama parametresinde
değil, **reverse proxy/API gateway'in kendi routing mantığında**
bulunur — **routing manipülasyonu confirmed olduktan sonra** sonuç
SSRF'e eşdeğer bir etki yaratabilir (saldırgan, proxy'yi **pre-auth
bir forward proxy'ye** dönüştürerek internal ağa/`localhost`'a bağlı
servislere tam okuma erişimi kazanabilir) — ama bu sınıflandırma
**otomatik değildir**: önce aşağıdaki tekniklerden birinin
(absolute-URI/SNI routing manipülasyonu) gerçekten hedefin routing
kararını değiştirdiği **bağımsız olarak doğrulanmalı** (örn. farklı
bir authority/SNI değeriyle farklı bir backend'den yanıt alındığının
gösterilmesi), ancak o zaman `INFRASTRUCTURE_MEDIATED_SSRF` olarak
sınıflandırılmalıdır (§14.1).

- **Absolute-URI request line istismarı:** Bazı reverse proxy/gateway
  yapılandırmaları, gelen bir HTTP isteğinin **request line**'ındaki
  authority kısmını (`GET http://<authority>/path HTTP/1.1` formundaki
  "absolute-URI" biçimi — normalde yalnızca forward proxy'lere özgü
  bir sözdizimidir) **normal host-based routing'in üzerine
  yazacak** şekilde yanlış yapılandırılmış olabilir. `Host:` header'ı
  bu durumda genelde **yok sayılır** — yani saldırgan, `Host:`
  header'ı ne olursa olsun, request line'daki authority'yi doğrudan
  hedef seçmek için kullanabilir.
- **SNI (Server Name Indication) alanı üzerinden routing:** Benzer bir
  misconfiguration deseni, TLS handshake'indeki SNI alanının
  **doğrudan** (ek bir doğrulama olmadan) backend seçimi/routing için
  kullanılmasıdır — saldırgan SNI alanına internal bir hostname/IP
  yazarak proxy'yi o backend'e yönlendirebilir.
  ```nginx
  # Örnek — yanlış yapılandırılmış bir Nginx stream/SNI-preread bloğu,
  # SNI değerini doğrulamadan doğrudan upstream olarak kullanır
  map $ssl_preread_server_name $backend {
      default $ssl_preread_server_name;
  }
  ```
- **Etki:** Bu iki desenin ikisi de **full-response** SSRF ile
  sonuçlanır — proxy, internal hedeften dönen **tam cevabı** saldırgana
  geri akıtır, bu da yalnızca blind probe değil, doğrudan internal
  servislerin (SOAP/Axis2 endpoint'leri, Keycloak admin arayüzleri,
  diğer admin console'ları) **enumerate edilip etkileşime
  girilmesini** sağlar.
- **Tespit:** Standart parametre-tabanlı SSRF testleri bu deseni
  yakalamaz — bunun yerine ham HTTP isteğinin request line'ını elle
  (raw socket/`nc`/Burp Repeater'ın "raw" modu ile) absolute-URI
  formatında oluşturup denemek gerekir; bu nedenle bu profil, §4 Sink
  Discovery'nin **protokol/altyapı seviyesi** bir uzantısıdır,
  uygulama parametresi seviyesinde değil.
