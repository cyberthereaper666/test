### 12.9 Azure — Instance Metadata Service (IMDS)

- **Endpoint:** `http://169.254.169.254/metadata/instance?api-version=2021-02-01`
- **Zorunlu header:**
  ```
  Header: Metadata: true
  ```
- **Managed Identity token endpoint'i:**
  ```
  http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/
  Header: Metadata: true
  ```

