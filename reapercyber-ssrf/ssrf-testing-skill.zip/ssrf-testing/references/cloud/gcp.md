### 12.8 GCP — Metadata Server

- **Endpoint:** `http://metadata.google.internal/computeMetadata/v1/`
  (veya doğrudan `169.254.169.254`)
- **Zorunlu header (GCP'nin kendi SSRF-koruması — bu header olmadan
  istek reddedilir):**
  ```
  http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token
  Header: Metadata-Flavor: Google
  ```
  ```
  http://metadata.google.internal/computeMetadata/v1/project/project-id
  Header: Metadata-Flavor: Google
  ```
- **Bypass notu:** `Metadata-Flavor: Google` header zorunluluğu,
  AWS IMDSv2 ile aynı "yalnızca URL kontrolü yeterli değil" kısıtını
  getirir — aynı istisna (genel amaçlı proxy/header kontrolü mümkünse)
  burada da geçerlidir.

