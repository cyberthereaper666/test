### 12.13 Kubernetes — API Server ve Kubelet

- **API server (kimlik doğrulamalı, bir service account token'ı
  gerektirir — SSRF tek başına yeterli olmayabilir, §11'de belirtilen
  zincire bakınız):**
  ```
  https://kubernetes.default.svc/api/v1/namespaces/<ns>/pods
  Header: Authorization: Bearer <service-account-token>
  ```
- **Kubelet API (bazı yapılandırmalarda kimlik doğrulamasız):**
  ```
  http://<node-ip>:10250/pods
  http://<node-ip>:10255/pods       (salt-okunur, eski/bazı ortamlarda hâlâ açık)
  ```

