### 12.7 AWS — Instance Metadata Service (IMDS)

- **Endpoint:** `http://169.254.169.254/latest/meta-data/`
- **IMDSv1 (token'sız, eski/varsayılan bazı ortamlarda hâlâ açık):**
  ```
  http://169.254.169.254/latest/meta-data/
  http://169.254.169.254/latest/meta-data/iam/security-credentials/
  http://169.254.169.254/latest/meta-data/iam/security-credentials/<rol-adı>
  http://169.254.169.254/latest/meta-data/iam/info
  http://169.254.169.254/latest/user-data
  http://169.254.169.254/latest/dynamic/instance-identity/document
  ```
- **Ek yüksek-değerli metadata path'leri (IMDSv1'de doğrudan, IMDSv2'de
  token header'ıyla birlikte kullanılır — genel keşif/impact
  zenginleştirme için, `/latest/meta-data/`'nin döndürdüğü dizin
  listesiyle birebir örtüşür):**
  ```
  http://169.254.169.254/latest/meta-data/instance-id
  http://169.254.169.254/latest/meta-data/ami-id
  http://169.254.169.254/latest/meta-data/hostname
  http://169.254.169.254/latest/meta-data/local-ipv4
  http://169.254.169.254/latest/meta-data/public-ipv4
  http://169.254.169.254/latest/meta-data/placement/region
  http://169.254.169.254/latest/meta-data/placement/availability-zone
  http://169.254.169.254/latest/meta-data/security-groups
  http://169.254.169.254/latest/meta-data/network/interfaces/macs/
  http://169.254.169.254/latest/meta-data/network/interfaces/macs/<mac>/security-group-ids
  http://169.254.169.254/latest/meta-data/network/interfaces/macs/<mac>/vpc-id
  http://169.254.169.254/latest/meta-data/tags/instance/          (yalnızca "instance metadata tags" özelliği açıksa)
  ```
  **Kullanım önceliği:** `iam/security-credentials/<rol-adı>` her
  zaman en yüksek impact'lidir (doğrudan credential); diğerleri
  (network/placement/tags) genelde **impact assessment**'ı
  zenginleştirmek (§10.4 — "hangi VPC, hangi security group, hangi
  instance" gibi bağlam bilgisi vererek raporun ikna ediciliğini
  artırmak) için kullanılır, tek başına kritik sayılmaz.
- **IMDSv2 (token zorunlu — modern/güvenli varsayılan yapılandırma,
  Strong negative indicator DEĞİL, bkz. §7 Negative Capability
  Matrix):** Doğrudan `GET` isteği **reddedilir** (401/403). Önce
  `PUT` ile bir token almak gerekir:
  ```
  PUT http://169.254.169.254/latest/api/token
  Header: X-aws-ec2-metadata-token-ttl-seconds: 21600

  → dönen token ile:
  GET http://169.254.169.254/latest/meta-data/
  Header: X-aws-ec2-metadata-token: <token>
  ```
  **Kritik SSRF-özel not:** IMDSv2'nin `PUT` metodu ve özel header
  gereksinimi, **çoğu klasik SSRF senaryosunda** (yalnızca bir URL
  parametresi kontrol edilebiliyorsa) bir **doğal engel** oluşturur —
  çünkü saldırgan genelde yalnızca hedef URL'i kontrol eder, HTTP
  metodunu veya ek header'ları değil. Bu durumda IMDSv2 SSRF'i
  tamamen engellemiş olabilir (bu, "SSRF yok" değil "SSRF var ama
  IMDSv2 nedeniyle credential'a bu spesifik sink üzerinden
  ulaşılamıyor" şeklinde raporlanmalıdır) — **istisna:** eğer sink
  saldırganın hem metodu hem header'ları kontrol etmesine izin veren
  bir "genel amaçlı HTTP proxy/webhook test aracı" ise (§2 kategori
  10), IMDSv2 yine de bypass edilebilir.
  **Spekülatif/doğrulanması gereken ek olasılık (hedefte ampirik
  test gerektirir, evrensel bir teknik olarak varsayılmamalı):**
  Eğer hedef uygulamanın önünde outbound isteği işleyen bir ara katman
  (kendi proxy/gateway'i) varsa ve bu katman genel bir "method
  override" konvansiyonunu (`X-HTTP-Method-Override`,
  `X-Forwarded-Method`, veya bir form alanı olan `_method` gibi —
  bunlar SSRF'e özgü değil, genel bir HTTP framework konvansiyonudur)
  onurluyorsa, teorik olarak bir `GET`/`POST` isteğinin ara katman
  tarafından `PUT`'a çevrilip IMDSv2 token adımını tamamlaması
  **mümkün olabilir** — ama bu, hem ara katmanın bu konvansiyonu
  desteklemesini hem de bu dönüşümün outbound IMDS isteğine kadar
  taşınmasını gerektiren, hedefe çok özel ve doğrulanması gereken bir
  zincirdir; genel bir bypass tekniği olarak güvenilmemelidir.
- **ECS/Fargate task metadata (farklı bir endpoint, IMDS'ten ayrı):**
  ```
  http://169.254.170.2/v2/credentials/<GUID>
  ```
  (GUID genelde `AWS_CONTAINER_CREDENTIALS_RELATIVE_URI` ortam
  değişkeninde bulunur — SSRF tek başına bu GUID'i bilemez, başka bir
  bilgi sızıntısıyla (örn. bir env-dump endpoint'i) birlikte
  zincirlenmesi gerekebilir.)
- **Credential kapsamı doğrulama — İKİ AYRI ADIM, KARIŞTIRILMAMALI
  (impact assessment, §10.4):**
  1. **Baseline confirmation ("credential gerçekten geçerli mi?"
     — SSRF confirmation'ının doğal bir parçası, her zaman yapılır):**
     Elde edilen `AccessKeyId`/`SecretAccessKey`/`Token` üçlüsü,
     hedefin AWS CLI'si üzerinden `aws sts get-caller-identity` gibi
     **yıkıcı olmayan** bir çağrı ile doğrulanabilir — bu, credential'ın
     gerçekten geçerli ve hangi role/hesaba ait olduğunu kanıtlar,
     §0.2'nin kalıcı değişiklik yasağını ihlal etmez.
  2. **Privilege-expansion validation ("bu credential ile daha geniş
     bir yetkiye geçebilir miyim?" — VARSAYILAN OLARAK ÇALIŞTIRILMAZ,
     yalnızca açıkça gerekli olduğunda denenir):** Bkz. aşağıdaki STS
     AssumeRole zinciri. Bu adım risk seviyesi olarak birinciden
     **farklıdır** ve default workflow'un bir parçası **değildir** —
     yalnızca ilk credential'ın (adım 1) dar yetkili göründüğü VE
     bulgunun impact'ini kanıtlamak için bu ek doğrulamanın **kesinlikle
     gerekli** olduğu durumlarda, bilinçli bir ek adım olarak denenir;
     "SSRF confirmed" sonucu **yalnızca adım 1'e** bağlıdır, adım 2
     asla otomatik/varsayılan bir sonraki adım değildir.
- **Modern IAM zincirleme senaryoları — impact'i büyütme (yalnızca
  doğrulama amaçlı, §0.2 sınırları içinde, YUKARIDAKİ adım 2
  kategorisinde):** Elde edilen credential bazen doğrudan geniş
  yetkili değildir, ama bir **zincirin başlangıç noktasıdır**:
  - **STS AssumeRole zinciri (privilege-expansion validation):** İlk
    credential yalnızca `sts:AssumeRole` yetkisine sahip olabilir;
    `aws sts assume-role --role-arn <arn>` gibi yine yıkıcı olmayan
    bir çağrıyla daha geniş yetkili bir role geçilip geçilemediği
    doğrulanabilir — bu, impact assessment'ı ("yalnızca dar bir rol"
    vs "assume-role zinciriyle geniş bir role ulaşılabiliyor")
    netleştirir, ama SSRF'in "confirmed" statüsünü **değiştirmez**,
    yalnızca impact seviyesini günceller.
  - **IRSA (IAM Roles for Service Accounts, EKS) ve Workload Identity
    Federation (GCP):** Kubernetes ortamında (§11) IMDS credential'ı
    yerine bir **service account token'ının** cloud IAM'e federe
    edildiği senaryolarda, SSRF ile elde edilen şey doğrudan AWS/GCP
    credential'ı değil, bir **Kubernetes service account token'ı**
    olabilir (bkz. §11 Kubernetes API server notu) — bu durumda
    "hangi credential türü elde edildi" (ham AKID/Secret mi, yoksa
    bir K8s SA token'ı mı) rapor edilirken netleştirilmelidir, çünkü
    doğrulama/kullanım yöntemi farklıdır (K8s SA token'ı doğrudan AWS
    CLI ile değil, `kubectl`/K8s API ile doğrulanır).

