## 16. SSRF → RCE Zincirleri (Impact Yükseltme Referansı)

Bu bölüm, §10.4'teki impact assessment'ı somutlaştırmak için, bu
skill'in daha önce tanımladığı bileşenlerin (§12 protokol profilleri,
§11 modern mimari, §9.1 stored/indirect) **nasıl art arda
zincirlenerek RCE'ye kadar gidebileceğini** özetler — yeni bir teknik
tanımlamaz, mevcut bölümlere çapraz referans verir.

**Derinleşme Triage Gate — KRİTİK, request bütçesini korur:** Bir
SSRF confirmed olduğunda, aşağıdaki zincirlerin **hepsini otomatik
olarak** denemek (gopher→Redis→FastCGI, K8s exec, Envoy config
manipülasyonu vb.) hem gereksiz request bütçesi tüketir hem de
düşük-değerli bir SSRF'i orantısız bir efor gerektiren bir "impact
avcılığına" çevirir. Derinleşmeden önce hızlı bir triage sorusu
sorulmalı — bu bir **eleme** değil, **derinleşme sırasını belirleme**
mekanizmasıdır (aynı §2'deki host/parametre skorlaması mantığı):

```
SSRF confirmed
   ↓
Hedef ne? (scheme_support/Sink Capability Matrix'ten, §7)
   ├─ Yalnızca kendi kontrolündeki canary/dış bir servis
   │  → düşük öncelikli derinleşme; bulguyu full/blind SSRF olarak
   │    raporla, gopher/RCE zincirlerini DENEMEDEN bırakmak makuldür
   │    (yine de scope/zaman izin veriyorsa denenebilir, yasak değil)
   ├─ 169.254.169.254/cloud metadata veya bilinen bir internal servis
   │  (Redis/Elasticsearch/K8s API vb. fingerprint edildi)
   │  → YÜKSEK öncelikli derinleşme; ilgili §12 profili ve/veya
   │    aşağıdaki zincir tablosu uygulanır
   └─ Bilinmiyor/henüz fingerprint edilmedi
      → önce §7 fingerprinting'e geri dön, hedefi belirle, sonra
        bu triage'a geri gel
```

Bu triage, **hiçbir zinciri yasaklamaz** — yalnızca "hangi sırayla,
ne kadar efor harcanacağı" kararını hedefin gözlemlenen değerine
bağlar. Düşük değerli bir hedefte de scope/zaman bolsa zincirler
denenebilir; yüksek değerli bir hedefte bu triage'ı atlayıp
doğrudan derinleşmek her zaman haklıdır.

**KRİTİK ÖNKOŞUL GATE — bu bölüm §10'daki confirmation'ın YERİNE
geçmez:** Aşağıdaki her zincir, **yalnızca** SSRF ve zincirdeki **her
ara kapasite bağımsız olarak confirmed olduktan sonra** bir sonraki
adıma geçilerek uygulanır. "SSRF confirmed" tek başına "zincirdeki
sonraki adım da çalışacak" anlamına **gelmez** — örneğin "Redis'e
gopher ile erişim confirmed" ile "Redis üzerinden RCE confirmed"
arasında **çok sayıda bağımsız koşul** vardır (Redis'in çalıştığı
kullanıcının dosya yazma izni, `CONFIG SET`'in devre dışı bırakılıp
bırakılmadığı, hedef dizinin yazılabilir olup olmadığı, SSH'ın
`authorized_keys` dosyasını nasıl işlediği, vb.). Doğru
sınıflandırma zincirin **her adımını ayrı ayrı** confirmed/
probable/inconclusive olarak işaretlemektir:

```
SSRF confirmed (§10.1)
   ↓
[ara kapasite 1] confirmed/probable/inconclusive — bağımsız kanıt gerekir
   ↓
[ara kapasite 2] confirmed/probable/inconclusive — bağımsız kanıt gerekir
   ↓
...
   ↓
RCE confirmed (yalnızca zincirin TAMAMI ayrı ayrı doğrulanmışsa)
```

| Zincir | Adımlar (her adım AYRI doğrulanmalı, otomatik varsayılmaz) | İlgili Bölümler |
|---|---|---|
| Redis → SSH key yazma → SSH ile RCE | (1) **[confirmed gerekir]** gopher ile Redis'e `CONFIG SET dir /root/.ssh/` — Redis'in `CONFIG` komutuna izin verdiği ayrıca doğrulanmalı (bazı yapılandırmalarda `rename-command`/`protected-mode` ile kapatılmıştır) (2) **[confirmed gerekir]** `CONFIG SET dbfilename authorized_keys` (3) **[confirmed gerekir]** `SET` ile saldırganın public key'ini value olarak yaz (4) **[confirmed gerekir]** `SAVE` ile dosyaya yaz — Redis'in çalıştığı kullanıcının `/root/.ssh/` dizinine yazma izni olup olmadığı ayrı bir koşuldur, genelde Redis root olarak ÇALIŞMAZ, bu adım çoğu gerçek hedefte başarısız olur (5) **[confirmed gerekir]** SSH ile bağlan — bu adımın başarısı yalnızca yukarıdaki TÜM adımların gerçekten çalıştığının kanıtıdır | §12.3 (gopher/Redis payload'ları) |
| FastCGI/PHP-FPM → RCE | **[confirmed gerekir]** gopher ile FastCGI protokolüne saldırganın PHP kodunu içeren bir `SCRIPT_FILENAME`+ham PHP payload'ı gönderme (Gopherus'un FastCGI modülü bu encoding'i otomatik üretir) — hedef path'in gerçekten var olduğu ve PHP-FPM'in bu path'i işlediği ayrı bir önkoşuldur | §12.3 (Gopherus aracı), §15 |
| AWS IMDS → User Data okuma → RCE | (1) **[confirmed]** `iam/security-credentials/` ile credential çal (2) **[confirmed gerekir]** `EC2 DescribeInstanceAttribute --attribute userData` ile (credential'ı kullanarak) instance'ın user-data'sını oku — credential'ın bu spesifik API çağrısına yetkili olduğu ayrı bir koşuldur, IAM policy dar kapsamlıysa bu adım başarısız olur (3) **[probable/inconclusive, hedefe özel]** script içinde hardcode edilmiş bir secret/credential veya zafiyetli bir kurulum adımı varsa bunu istismar et — bu adımın varlığı garanti değildir | §12.7 (AWS IMDS), §10.4 |
| Kubernetes API → Pod exec → RCE | (0) **[AYRI ÖNKOŞUL — SSRF'in doğal sonucu DEĞİLDİR]** service account token'ı elde etmek genelde bir **dosya okuma** vektörü gerektirir (`/var/run/secrets/kubernetes.io/serviceaccount/token`) — SSRF tek başına bu dosyayı okuyamaz, bu adım yalnızca SSRF'in **başka bir zafiyetle** (örn. §12.2'deki `file://` okuma, veya ayrı bir LFI) zincirlendiği durumlarda mümkündür; token elde edilmeden bu zincirin geri kalanı **hiç başlamaz** (1) **[confirmed gerekir, adım 0 sağlanmışsa]** K8s API'nin `pods/exec` subresource'una token ile istek atarak bir pod içinde komut çalıştır — kimlik doğrulanmış kullanıcının bu yetkiye sahip olması (RBAC) **ayrı ve genelde kısıtlı** bir koşuldur, çoğu service account'ta bu yetki yoktur | §11 (Kubernetes API server), §12.13, §12.2 (file:// önkoşulu) |
| Service mesh Envoy admin → config manipülasyonu | (1) **[confirmed]** `/config_dump` ile mesh topolojisini çıkar (2) **[probable/inconclusive, hedefe özel]** admin API'nin config-değiştirme endpoint'lerine yazma izni varsa trafiği kendi kontrolündeki bir servise yönlendir — birçok gerçek dünya kurulumunda admin API salt-okunur/read-only olarak açıktır, yazma her zaman mümkün değildir | §11 (Envoy admin API path'leri) |
| Reverse proxy absolute-URI/SNI istismarı → internal admin panel'e tam erişim | §12.16'daki misconfigürasyonla proxy'yi forward-proxy'ye çevir (confirmed gerekir), ardından internal admin panellerini (Keycloak, SOAP/Axis2 vb.) doğrudan hedefle | §12.16 |

**Kullanım notu:** Bu tablo bir **checklist değil, bir impact-mantığı
referansıdır** — her satırdaki adımların her biri hedefe özel
koşullara (versiyon, yapılandırma, yetki) bağlıdır; agent bir SSRF
confirmed olduktan sonra (§10.1-§10.2) bu tabloyu tarayarak "bu
spesifik hedefte hangi zincir mantıklı bir sonraki adım olabilir"
sorusunu sorar, tüm zincirleri körlemesine denemez, ve **hiçbir ara
adımı bir öncekinin başarısından otomatik olarak çıkarsamaz.**
