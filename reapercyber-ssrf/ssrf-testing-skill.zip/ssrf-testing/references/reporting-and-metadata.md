## 14. Raporlama ve Payload Metadata Şeması

### 14.1 Raporlama Şablonu

Her SSRF bulgusu için rapor şu unsurları içermelidir:

1. **`vulnerability_class`** — bulgunun gerçek sınıfı, açıkça
   etiketlenir: `SSRF` / `OPEN_REDIRECT` (yanlışlıkla SSRF sanılmaması
   için, bkz. §3.1) / `XXE_SSRF_CHAIN` (XXE üzerinden dolaylı, bkz.
   §3.3) / `SSRF_AUTHORIZATION_BYPASS` (kasıtlı bir ağ aracının
   yetkisiz erişime açık olması, bkz. §6.1) / `PROTOCOL_SMUGGLING`
   (gopher/dict üzerinden internal servis manipülasyonu, bkz. §12.3)
   / `INFRASTRUCTURE_MEDIATED_SSRF` (reverse-proxy/gateway routing
   istismarı, application-level bir sink DEĞİL, bkz. §12.16) /
   `UNKNOWN`. **`file://` sonucu için özel not:** `file://` ile elde
   edilen bir dosya okuma, tek eksenli `SSRF` etiketi yerine iki
   eksenli raporlanmalıdır — `delivery: file` (§12.2, taşıma
   mekanizması SSRF'in genel modeliyle aynıdır) + `impact_class:
   local-file-read` (nihai etki, ağ üzerinden bir hedefe erişim değil,
   dosya sistemi okumasıdır) — bu, "SSRF" teriminin network-request
   çağrışımıyla tam örtüşmeyen bu sonucu daha doğru tanımlar.
2. **Hedef:** URL/route, HTTP method, etkilenen parametre/alan.
3. **SSRF türü ve confidence seviyesi** — **SSRF classification** ve
   **target classification** §8.4'teki tanıma göre **ayrı ayrı**
   raporlanır:
   - SSRF (causality) "confirmed" mi: Eksen 1'den **tek bir kanıt
     türü** (full/reflected / OOB / semi-blind-differential /
     stored-indirect) **yeterlidir** — DNS-only OOB için §8.4'teki
     koşullu kural geçerlidir.
   - Target (attribution) "confirmed" mi: en az bir Strong indicator
     + tutarlı behavior — SSRF classification'ından bağımsız bir alan.
   - Full mu Blind mi Semi-blind mi — bu ayrım (§1.4) rapor
     seviyesinde de zorunlu olarak belirtilmelidir çünkü impact
     kanıtlama yöntemini doğrudan etkiler.
   - **`network_capability`** — blind/semi-blind bulgular için ayrıca
     belirtilir: `dns-only` (yalnızca DNS çözümlemesi gözlemlendi,
     P2a/P3 koşullu) / `tcp-connect` (bağlantı kuruldu ama protokol
     tamamlanmadı) / `full-protocol` (P4 tamamlandı, HTTP/protokol
     etkileşimi doğrulandı). Bu alan, "DNS-only SSRF" gibi daha zayıf
     bir bulgunun "full SSRF" ile aynı güvenle raporlanmasını önler
     — ikisi de `confirmed` olabilir (DNS-only, §8.4'teki koşullar
     sağlanırsa) ama `network_capability` farkı okuyucuya gerçek
     kapsamı netleştirir.
   - confidence_score (§10.5) yalnızca destekleyici bilgidir.
4. **Detection payload'ı** — tam request/response ve interactsh log
   kaydı (varsa).
5. **Confirmation kanıtı** — "confirmed" için gereken tek Eksen-1
   kanıtının kendisi ve onun §5.1'e göre kurulmuş negatif kontrolü.
6. **Beklenen vs gerçekleşen sonuç** — net karşılaştırma.
7. **False-positive olmadığının kanıtı** — negatif kontrol, ve
   gerekiyorsa Open Redirect/XXE ayrımının gösterimi.
8. **Impact assessment gerekçesi** — §10.4'teki dört eksen: hedefin
   niteliği, elde edilen bilginin hassasiyeti, protokol smuggling ile
   ikincil etki var mı, yetkilendirme/allowlist context'i.
9. **Reproduction adımları** — başka birinin aynı sonucu tekrar
   üretebilmesi için yeterli detay.

**Rapora eklenmemesi gerekenler:** Zafiyeti kanıtlama amacı taşımayan,
elde edilebilecek credential'larla yapılabilecek zararlı aksiyonların
ayrıntılı bir listesi; zafiyetle doğrudan ilgisi olmayan hedef sistem
iç bilgileri.

### 14.2 Payload Metadata Şeması

Yeni bir payload eklerken, şu alanları takip et:

| Alan | Açıklama |
|---|---|
| protocol | Hangi protokol/şema (http/https/file/gopher/dict/ftp/ldap/jar/netdoc veya "generic") |
| target_environment | Hangi ortam (AWS/GCP/Azure/Alibaba/Oracle/DigitalOcean/Kubernetes/internal-generic) |
| syntax | Tam payload metni |
| context | full-url/hostname-only/path-fragment/header-value/xml-entity/config-value |
| purpose | detection / fingerprinting / confirmation / impact |
| expected_result | Beklenen çıktı (ham/raw temsil) |
| alternatives | Eşdeğer alternatif syntax'lar (IP encoding varyantları vb.) |
| behavior_dependency | default / configuration-dependent / version-dependent / application-specific |
| evidence_category | full-reflected / OOB / semi-blind-differential / stored-indirect / target-fingerprint |
| fp_risk | Yanlış pozitif riski: düşük / orta / yüksek |
| kaynak | Bu payload'ın kökeni |
| payload_stage *(yeni eklenen payload'lar için zorunlu)* | §1.5 Payload Stage Model'e göre: P0-input-acceptance / P1-parsing / P2a-dns-resolution / P2b-tcp-connection-attempt / P3-confirmed-contact / P4-protocol-negotiation / P5-response-capture / P6-impact |
| prerequisites *(yeni eklenen payload'lar için zorunlu)* | Bu payload'ın çalışması için gerekli önkoşullar (örn. `redirect_following=true`, `imds_version=v1`, `gopher_scheme_supported=true`) |
| side_effect_level *(yeni eklenen payload'lar için zorunlu)* | none / read-only / external-interaction (OOB) / state-changing (örn. Redis'e yazma) |

**Geriye dönük etiketleme yapılmıyor** — bu üç alan yalnızca
**bundan sonra eklenecek** içerik için zorunludur.
