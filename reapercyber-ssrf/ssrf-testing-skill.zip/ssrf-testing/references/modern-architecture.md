## 11. Modern Mimari Notları

- **Proxy-aware SSRF — hedefin kendi outbound HTTP client'ı bir
  kurumsal forward-proxy arkasındaysa (§12.16'daki reverse-proxy'den
  TAMAMEN farklı bir mimari, karıştırılmamalı):** Bazı kurumsal
  ortamlarda, hedef uygulamanın **kendi** HTTP client'ı (`HTTP_PROXY`/
  `HTTPS_PROXY`/`NO_PROXY` ortam değişkenleri veya framework-seviyesi
  bir proxy ayarı ile) tüm outbound trafiğini bir **kurumsal forward-
  proxy** üzerinden geçirecek şekilde yapılandırılmış olabilir:
  ```
  uygulama → HTTP client → HTTP_PROXY/HTTPS_PROXY → kurumsal forward-proxy → hedef
  ```
  Bu mimari, SSRF metodolojisini önemli noktalarda değiştirir:
  - **DNS nerede çözülüyor?** Bazı HTTP client'lar (proxy kullanırken)
    DNS çözümlemesini **uygulamanın kendisinde değil, proxy'de**
    yaptırır (`CONNECT` metoduyla) — bu durumda §9.3'teki DNS-only
    OOB testi **uygulamadan değil, proxy'den** bir DNS sorgusu
    görecektir; bu, `probe_result`'taki `target_hypothesis` alanına
    "corporate-proxy" olarak eklenmelidir, `internal-service` değil.
  - **TCP bağlantısını kim kuruyor?** Proxy kullanılıyorsa, gerçek
    TCP bağlantısını **proxy** kurar — internal hedeflere erişim
    artık uygulamanın kendi network konumuna değil, **proxy'nin**
    network konumuna/egress kurallarına bağlıdır. Bu, çoğu zaman
    SSRF'in etkisini **azaltır** (proxy genelde daha kısıtlı bir
    egress politikasına sahiptir) ama bazen **artırır** (proxy, farklı
    bir network segmentinden erişilebilen internal servislere doğal
    bir "atlama noktası" sağlayabilir — örn. proxy'nin kendisi bir
    DMZ'de, hem internete hem bazı internal servislere erişebiliyor
    olabilir).
  - **Allowlist/blacklist hangi tarafta uygulanıyor?** Eğer koruma
    uygulama kodunda ise (hedef URL'i kontrol eden bir middleware),
    proxy bu kontrolü **bilmez** ve her isteği olduğu gibi iletir —
    korumayı atlatmak için proxy'nin **kendi** CONNECT/routing
    davranışını (hangi hedeflere izin verdiğini) ayrıca fingerprint
    etmek gerekir; bu genellikle uygulamanın kendi korumasından
    **bağımsız** bir ikinci katmandır.
  - **Redirect sonrası proxy tekrar devreye giriyor mu?** §8.2.4'teki
    "validate-every-hop" sorusu burada da geçerlidir — bir redirect
    zincirinin her hop'u da proxy üzerinden mi geçiyor, yoksa yalnızca
    ilk istek mi proxy'lenip redirect'ler doğrudan mı takip ediliyor
    (bazı HTTP client'lar bunu farklı ele alır).
  - **Fingerprint sinyali:** Response timing'inde ekstra bir "hop"
    gecikmesi, `Via`/`X-Forwarded-*` header'larının **outbound**
    yönde de eklenmiş olması (yalnızca inbound'da değil), veya bir
    proxy'ye özgü hata sayfası (örn. Squid/proxy ürünlerinin kendi
    "403 Forbidden" şablonu) bu mimarinin varlığına işaret eder.
  Bu mimari tespit edildiğinde, `probe_identity`/`probe_result`
  state modeline (§2) bir `via_proxy: true/false` alanı eklenmesi
  önerilir — bu, aynı hedefe atılan farklı probe'ların sonuçlarını
  doğru yorumlamak için gereklidir (bkz. §8.2.6 Canonical Target
  Resolution Model'e benzer bir mantık, burada "proxy hop"u da
  zincire eklenmiş olur).

- **Microservice/API-first mimari:** SSRF'nin tetiklendiği servis ile
  hedeflenen internal servis farklı olabilir — bir API Gateway/BFF
  (Backend-for-Frontend) katmanındaki bir SSRF, arkasındaki tüm
  microservice mesh'ine erişim sağlayabilir; bu, tek bir SSRF'nin
  etkisini büyük ölçüde artıran bir mimari örüntüdür (bkz. §10.4
  impact assessment).
- **Service mesh (Istio/Linkerd) ortamları:** Servisler arası
  iletişim genelde bir sidecar proxy üzerinden geçer; bir SSRF, mesh
  içindeki **sidecar admin API'lerine** erişim sağlayabilir — bu, mesh'in
  trafiğini/konfigürasyonunu görüntüleme/manipüle etme kapasitesine
  kadar gidebilir. Envoy admin arayüzü — **environment-dependent bir
  varsayım, kesin değil:** yaygın kurulumlarda `15000` portu
  kullanılır ve kimlik doğrulaması genelde uygulanmaz, ama gerçek
  bind adresi/port/auth durumu **hedefe özgüdür ve ampirik olarak
  fingerprint edilmelidir** (bazı kurulumlar admin arayüzünü farklı
  bir portta açar veya bir mTLS/network-policy kısıtlaması ekler) —
  somut, yüksek değerli path'ler (port doğrulandıktan sonra):
  ```
  http://127.0.0.1:15000/                    (admin ana sayfa, komut listesi)
  http://127.0.0.1:15000/config_dump         (TÜM mesh konfigürasyonu — route, cluster, listener tanımları)
  http://127.0.0.1:15000/clusters            (mesh içindeki tüm servis/cluster listesi — internal network topolojisi keşfi için doğrudan kullanılabilir)
  http://127.0.0.1:15000/stats               (metrik/istatistik — bazen internal endpoint isimlerini de sızdırır)
  http://127.0.0.1:15000/certs               (mTLS sertifika bilgisi)
  http://127.0.0.1:15000/server_info         (Envoy sürüm/build bilgisi — fingerprinting için)
  ```
  `/clusters` ve `/config_dump` özellikle değerlidir çünkü tek bir
  istekle **tüm mesh'in internal servis haritasını** çıkarır — bu,
  §9.4'teki sınırlı port taramasının yerini büyük ölçüde
  alabilecek, çok daha verimli bir internal network keşif yöntemidir
  (bir SSRF ile bu endpoint'e ulaşılabiliyorsa, port taramaya hiç
  gerek kalmadan tüm topoloji elde edilir).
- **Kubernetes ortamı (özellikle yüksek etkili bir hedef):**
  - **Kubernetes API server** — genelde `https://kubernetes.default.
    svc` veya cluster IP'si üzerinden erişilebilir; pod'un service
    account token'ı (`/var/run/secrets/kubernetes.io/serviceaccount/
    token` — bu bir **dosya okuma** gerektirir, SSRF'nin kendisi
    değil, ama SSRF ile birlikte zincirlenebilir eğer uygulama başka
    bir zafiyetle bu dosyayı okuyup bir header'a koyabiliyorsa) ile
    kimlik doğrulanmış istekler atılabilir.
  - **kubelet API** — genelde `10250` portunda, bazı yapılandırmalarda
    kimlik doğrulamasız erişilebilir, pod/container bilgisi ve bazen
    komut çalıştırma (`exec`) kapasitesi sunar.
  - **`*.svc.cluster.local`** iç DNS formatı — bir SSRF'nin
    Kubernetes ortamında olduğuna dair güçlü bir fingerprint
    sinyalidir (bkz. §7).
- **Serverless/FaaS (Lambda, Cloud Functions, Azure Functions):**
  Cloud metadata servisi burada da geçerlidir (§12), ama bazı
  serverless ortamlarında IMDS'e erişim tamamen farklı bir mekanizma
  üzerinden (örn. Lambda'da ortam değişkenleri + geçici credential'lar,
  doğrudan IMDS yerine) sağlanır — bu ortamlarda klasik
  `169.254.169.254` payload'ı **negatif** dönebilir, bu ortamı elemez,
  yalnızca farklı bir credential-erişim modeli olduğunu gösterir;
  ortam değişkenlerine erişim (varsa, başka bir zafiyet zinciriyle)
  daha alakalı bir hedef olabilir.
- **Webhook/event-driven mimari:** Modern SaaS ürünlerinin çoğu
  webhook tabanlı entegrasyon sunar (§2, §9.1) — bu, SSRF'nin
  "birinci sınıf vatandaş" olarak beklenen bir özellik olduğu bir
  alandır; asıl soru genelde hedef kısıtlamasının (yalnızca dış
  IP'lere izin) doğru uygulanıp uygulanmadığıdır (§6.1, §10.4).
- **GraphQL API'ler:** SSRF'nin kendisi için ayrı bir teknik
  gerektirmez — GraphQL burada yalnızca bir **taşıma katmanıdır**,
  sink genelde bir resolver'ın arkasındaki "URL'den veri çek" mantığıdır
  (§4 Sink Discovery aynen uygulanır). Bu taşıma katmanının kendine
  özgü üç pratik sonucu vardır:
  - **Introspection ile sink keşfi:** Introspection açıksa (`{
    __schema { types { name fields { name args { name } } } } }`
    sorgusu), `url`/`webhook`/`endpoint`/`link`/`source` gibi alan
    adı deseni taşıyan tüm mutation/query argümanları tek seferde
    listelenebilir — bu, §2'deki manuel parametre-adı taramasının
    GraphQL'e özgü otomatik bir eşdeğeridir.
  - **Batching ile paralel canary gönderimi:** GraphQL'in batch-request
    desteği (birden fazla query/mutation'ın tek bir HTTP isteğinde
    dizi olarak gönderilmesi) varsa, birden fazla aday alana **aynı
    anda** biricik canary'ler göndermek mümkündür — bu, §5'teki
    "her aday parametreye ayrı istek" akışını GraphQL'e özgü olarak
    hızlandırır (rate-limit/WAF açısından da tek bir istek gibi
    görünebileceğinden dikkatli kullanılmalı).
  - **Multipart file-upload ile SSRF (GraphQL'in `multipart/form-data`
    tabanlı dosya yükleme uzantısı kullanıldığında):** Yüklenen
    dosyanın **içeriği** bir SSRF vektörü taşıyabilir (bkz. §9.2 —
    SVG/XML içi harici referans) — bu durumda sink GraphQL'in kendisi
    değil, dosyayı işleyen alt sistemdir, GraphQL yalnızca dosyanın
    taşıyıcısıdır.
- **CI/CD pipeline'ları — platform-özgü credential/token yüzeyleri:**
  Bir CI/CD sisteminin (Jenkins, GitLab CI, GitHub Actions self-hosted
  runner) kendisi bir SSRF hedefi olabilir — pipeline tanımlarında
  dışarıdan bir URL çekme/import etme adımı varsa, bu hem pipeline'ın
  çalıştığı runner'ın internal ağına hem de runner'ın kendi cloud
  credential'larına (self-hosted runner'lar genelde bir cloud instance
  üzerinde çalışır, bkz. §12) erişim sağlayabilir. Platforma özgü ek
  yüzeyler:
  - **GitHub Actions:** Runner süreci içinde `ACTIONS_RUNTIME_TOKEN`
    ortam değişkeni ve buna karşılık gelen internal API
    (`http://127.0.0.1:<port>/_apis/...` — port genelde
    `ACTIONS_RUNTIME_URL` ortam değişkeninde belirtilir) — bir SSRF
    bu internal API'ye ulaşabiliyorsa, cache/artifact API'leri
    üzerinden pipeline'ın kendi build sürecine müdahale imkanı doğar.
  - **GitLab Runner:** `CI_JOB_TOKEN` ile birlikte internal container
    registry veya GitLab API'sine kimlik doğrulanmış erişim —
    runner'ın kendi ağındaki bir SSRF, bu token'ı ortam
    değişkenlerinden okuyabilen başka bir zafiyetle zincirlenirse
    (SSRF'nin kendisi token'ı okumaz, bu bir dosya/env-okuma
    gerektirir) registry'ye erişim genişleyebilir.
  - **Genel kural:** Self-hosted runner'ların **cloud instance
    üzerinde** çalıştığı doğrulanırsa (§7 fingerprinting), standart
    cloud metadata testleri (§12) de bu runner'a karşı doğrudan
    uygulanmalıdır — CI/CD SSRF'i genelde yalnızca kendi başına değil,
    altındaki cloud instance'ın metadata'sına açılan bir kapı olarak
    en yüksek impact'e ulaşır.
- **Reverse proxy / API Gateway header injection:** `X-Forwarded-Host`,
  `X-Forwarded-For`, `X-Original-URL` gibi header'ların bazı
  reverse-proxy/yönlendirme mantıklarında bir outbound isteğin
  hedefini (özellikle bir "upstream" seçimi/host-based routing
  senaryosunda) etkileyebilmesi, header-value context'ine (§6) özgü
  bir SSRF yüzeyidir. **Tutarlılık notu (bkz. §2'deki sinyal-güdümlü
  kural — bu ondan bağımsız/çelişkili bir ek kural DEĞİLDİR):** Bu
  header'lar §5'teki generic detection akışına **körlemesine her
  endpoint'te değil**, yalnızca §2'de tanımlanan sinyal (routing/
  proxy davranışı gözlemi, header'ın bir callback/URL üretiminde
  kullanıldığının görülmesi) mevcutsa dahil edilir — hedefin bir
  reverse-proxy/API-gateway mimarisi olduğu bu bölümde zaten
  gözlemlendiyse, bu doğrudan sinyalin kendisidir ve header testini
  önceliklendirmek için yeterli bir gerekçedir.
