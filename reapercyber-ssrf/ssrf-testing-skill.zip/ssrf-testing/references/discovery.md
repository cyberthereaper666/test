## 2. Discovery & Risk Scoring

### Endpoint/parametre adayları nereden çıkarılır
- Recon sonuçları: canlı host listesi, JS bundle'ları, OpenAPI/Swagger,
  GraphQL introspection, Burp/proxy history.
- Teknoloji fingerprint (framework/CMS tespiti) → §13'teki
  Framework→sink tablosuyla eşleştirilerek hangi endpoint'lerin
  bilinen SSRF sink'i taşıdığı önceden daraltılır (bu eşleme
  **varsayılan**dır, kesin değildir).

### Yüksek öncelikli endpoint kategorileri (azalan risk sırası)
1. **URL/link önizleme ve "unfurl" özellikleri** — sosyal paylaşım
   kartı üretimi, mesajlaşma uygulamalarında link preview, "URL'den
   içe aktar" özellikleri. SSRF'nin **klasik ve en yaygın** sink'i.
2. **Webhook/callback URL kayıt mekanizmaları** — kullanıcının kendi
   webhook URL'ini tanımlayabildiği entegrasyon ayarları (uygulama bu
   URL'e periyodik/tetiklenmeli istek atar).
3. **Dosya/resim/PDF işleme — "URL'den yükle" özellikleri** — profil
   fotoğrafı/logo/avatar'ı bir URL'den çekme, PDF/rapor üretiminde
   harici bir sayfayı/resmi dahil etme (`wkhtmltopdf`, headless
   Chrome/Puppeteer tabanlı render motorları).
4. **Web crawler/scraper/screenshot servisleri** — "bu URL'in
   ekran görüntüsünü al" veya "bu sayfayı tara/indeksle" özelliği
   sunan araçlar (SEO analiz araçları, arşivleme servisleri, sosyal
   medya zamanlama araçlarının "önizleme" özelliği) — bu servisler
   **tasarım gereği** kullanıcı tanımlı bir URL'e istek atar,
   dolayısıyla §6.1'deki "kasıtlı özellik" kategorisine girer; asıl
   soru genelde hedef kısıtlamasının (internal IP/localhost'a
   erişimin engellenip engellenmediği) doğru uygulanıp
   uygulanmadığıdır.
5. **XML/döküman işleme (XXE-SSRF overlap)** — SVG/DOCX/PDF/RSS/
   SOAP gibi XML tabanlı formatların import/parse edildiği
   endpoint'ler (bkz. §3.3).
6. **API entegrasyon/proxy endpoint'leri** — bir "veri kaynağı URL'i"
   veya "API endpoint" tanımlayan admin panelleri (özellikle
   monitoring/dashboard araçlarında — Grafana tarzı "data source"
   tanımlama klasik bir örnektir).
7. **OAuth/SAML/OIDC metadata URL alanları ve redirect/callback
   parametreleri** — "Identity Provider metadata URL'i" gibi bir
   federasyon/SSO konfigürasyon alanı, ayrıca `redirect_uri`/
   `return_url`/`next`/`continue` gibi post-authentication yönlendirme
   parametreleri (bazı sunucu tarafı OAuth implementasyonları, bu
   parametreyi yalnızca tarayıcıya yönlendirmekle kalmaz, geçerliliğini
   doğrulamak için **sunucu tarafında da** bir istek atabilir).
8. **PDF export / rapor üretimi / e-posta şablonu render'ı** — sunucu
   tarafında HTML'i render edip resim/PDF'e çeviren özellikler.
9. **Import/senkronizasyon özellikleri** — "bir URL'den/feed'den içe
   aktar" (RSS/Atom feed okuyucuları, "CSV'yi bir URL'den yükle").
10. **Repository/paket/API-spec içe aktarma özellikleri** — "bir Git
    reposunu/paket kaydını/OpenAPI-Swagger spesifikasyonunu URL'den
    içe aktar" özelliği (CI/CD araçları, paket yöneticisi arayüzleri,
    API dokümantasyon/test araçları) — modern geliştirici araçlarında
    giderek yaygınlaşan, sıkça atlanan bir sink kategorisi.
11. **Video/medya transcoding servisleri** — bir video/medya dosyasını
    uzak bir URL'den indirip işleyen servisler.
12. **DNS/network yardımcı araçları** — "ping"/"traceroute"/"whois"/
    "port kontrolü" gibi meşru ağ araçları sunan admin panelleri
    (genelde **doğrudan** ve **kasıtlı** bir SSRF-benzeri özelliktir,
    yetkilendirme sınırı test edilmelidir).
13. **PDF/döküman imzalama, harici doğrulama servisleri** — "belge
    doğrulama URL'i" gibi harici bir servise referans veren alanlar.
14. **İnfra servis entegrasyon konfigürasyonu + "bağlantıyı test et"
    özelliği — YÜKSEK DEĞERLİ, sık atlanan bir kategori:** Kurumsal
    SaaS/admin panellerinde bir harici servisi (SMTP relay, LDAP
    dizini, Redis/Memcached cache, Elasticsearch cluster'ı, S3-uyumlu
    özel depolama endpoint'i, mesaj kuyruğu) yapılandırmaya yarayan
    ve genelde yanında **"Test Connection"/"Bağlantıyı Doğrula"**
    butonu bulunan formlar. Bu buton, sunucunun kullanıcı tanımlı
    host:port'a **gerçek bir TCP/protokol seviyesi bağlantı**
    denemesi yapmasına yol açar — bu, klasik bir SSRF sink'idir ve
    genelde §12.4'teki (dict://) port-probe kapasitesiyle doğrudan
    örtüşür (bazı durumlarda gopher ile protokol smuggling'e bile
    zincirlenebilir, örn. LDAP/SMTP alanına gopher payload'ı
    denenmesi). Bu kategori diğerlerinden farklıdır çünkü sink genelde
    bir `url` parametresi değil, **ayrı host + port (+ opsiyonel
    protokol) alanlarının kombinasyonudur** — bkz. aşağıdaki parametre
    listesi.

### Yüksek öncelikli parametre adları

**URL/adres çekirdek adları (genel):**
`url`, `uri`, `link`, `href`, `src`, `source`, `target`, `dest`,
`destination`, `redirect`, `callback`, `webhook`, `endpoint`,
`host`, `hostname`, `domain`, `server`, `path`, `file`, `document`,
`resource`, `fetch`, `load`, `import`, `feed`, `proxy`, `remote`,
`origin`, `forward`, `connect`, `connection`

**OAuth/SSO/post-action redirect'e özgü (klasik ve çok yaygın bir
alt kategori — bu isimler genelde bir "redirect" değil, tam bir
outbound istek olarak da işlenebilir, özellikle server-side OAuth
callback doğrulaması yapan akışlarda):**
`redirect_uri` (OAuth2 spesifikasyonunun standart parametre adı),
`return_url`, `return_uri`, `return_to`, `returnUrl`, `next`,
`continue`, `service` (CAS protokolüne özgü), `success_url`,
`failure_url`, `client_url`

**Önizleme/render/import'a özgü:**
`preview_url`, `image_url`, `avatar_url`, `logo_url`, `icon_url`,
`thumbnail`, `snapshot`, `render_url`, `pdf_url`, `report_url`,
`template_url`, `html_url`, `screenshot_url`, `og_image` (Open Graph
image — link unfurling özelliklerinde çok yaygın), `oembed_url`
(oEmbed standardı — bilinen bir SSRF vektörü)

**Webhook/entegrasyon'a özgü:**
`webhook_url`, `notify_url`, `notification_url`, `callback_url`,
`hook`, `subscription_url`, `ping_url`, `data_source_url`,
`connection_string`, `connection_url`, `api_endpoint`, `api_url`,
`service_url`, `base_url`, `metadata_url`, `discovery_url`
(OIDC discovery), `validation_url`, `verification_url` (domain/webhook
sahiplik doğrulama akışları — SSRF için klasik bir sink deseni)

**İçe/dışa aktarma, dosya ve repository'e özgü (yüksek değerli, sık
atlanan bir alt kategori):**
`download_url`, `export_url`, `attachment_url`, `media_url`,
`rss_url`, `atom_url`, `repository_url`, `git_url`, `package_url`
(bir "git/paket reposunu URL'den içe aktar" özelliği — CI/CD ve
paket yöneticisi entegrasyonlarında yaygın), `manifest_url` (web app
manifest/PWA fetcher'ları), `wsdl_url` (SOAP/WSDL fetcher'ları —
hem SSRF hem XXE overlap riski taşır, bkz. §3.3), `swagger_url` /
`openapi_url` (API spesifikasyonunu bir URL'den içe aktarma —
modern API test/dokümantasyon araçlarında sık görülen bir özellik),
`upload_url` (yüklenen bir dosyanın nereye "yönlendirileceğini"
belirten alan — bazı depolama entegrasyonlarında), `helm_chart_url`
/ `chart_repo_url` (Helm chart repository — Kubernetes tabanlı
araçlarda), `terraform_module_source` / `module_source` (IaC modül
kaynağı — bazı IaC otomasyon platformlarında kullanıcı tanımlı bir
modül URL'i çekilir), `dockerfile_url` (uzak bir Dockerfile/build
context çekimi), `sitemap_url`, `robots_url` (SEO/crawler araçlarına
özgü, `crawl_url` ailesiyle aynı kategori)

**Medya/streaming'e özgü (video/medya transcoding kategorisinin somut
parametre karşılıkları — bkz. §2 kategori 11):**
`stream_url`, `video_url`, `hls_url`, `m3u8_url` (HLS manifest
URL'i — dikkat: bir HLS/DASH manifest'inin **içeriği** de başka
harici URL'ler referans edebilir, bu durumda tek bir parametre iki
aşamalı bir SSRF zincirine yol açabilir: manifest URL'i → manifest
içeriğindeki segment/alt-manifest URL'leri)

**İnfra servis konfigürasyonu + "bağlantıyı test et" deseni (§2
kategori 14 — yüksek değerli, host+port kombinasyonu şeklinde farklı
bir context'tir, tek bir `url` parametresi değildir):**
`smtp_host` / `smtp_server` / `mail_server` (SMTP relay
yapılandırması), `ldap_url` / `ldap_server` (dizin servisi
yapılandırması — LDAP injection ile de kesişebilir, ayrı bir
zafiyet sınıfı), `redis_url` / `redis_host` (cache/queue backend
yapılandırması), `elasticsearch_url` / `es_url` (arama motoru
backend'i), `s3_endpoint` / `storage_endpoint` (S3-uyumlu özel
depolama endpoint'i — MinIO tarzı entegrasyonlarda yaygın),
`database_host` / `db_host` (bazı "bağlantıyı test et" özellikleri
burada da gerçek bir TCP handshake denemesi yapar, SQL injection'dan
tamamen ayrı bir SSRF yüzeyi), `queue_url` / `broker_url` (mesaj
kuyruğu backend'i), `proxy_pac_url` (Proxy Auto-Config dosyası
URL'i — hem tarayıcı hem bazı sunucu tarafı HTTP client'ları PAC
dosyalarını fetch edip yorumlayabilir)

**Web crawler/scraper/screenshot servislerine özgü (§2'deki
"URL'den içerik çek" kategorisinin somut parametre karşılıkları):**
`crawl_url`, `scrape_url`, `screenshot_url`, `render_target`

**Ağ aracı/admin panel'e özgü:**
`ip`, `port`, `address`, `host_check`, `ping_target`, `probe_url`,
`healthcheck_url`, `proxy_host`, `proxy_port`, `proxy_url`

**Header-tabanlı SSRF vektörleri (KRİTİK — ayrı bir delivery
mekanizması, yalnızca query/body parametre taraması bunları
YAKALAMAZ; bkz. §6 header-value context, §11 reverse-proxy header
injection):** Yukarıdaki tüm isimler query/body/JSON parametreleri
içindir — ama bazı SSRF sink'leri **parametre değil, HTTP header**
üzerinden tetiklenir. **Düzeltme — bu bir "her endpoint'te körlemesine
dene" listesi değildir, sinyal-güdümlü bir listedir:** Bu header'ları
denemek için önce şu sinyallerden birinin varlığı aranmalı —
response'ta bir header değerinin **yansıması/kullanılması** (örn.
oluşturulan bir callback/redirect URL'inde `X-Forwarded-Host`
değerinin göründüğü), hedefin bir reverse-proxy/gateway mimarisi
olduğu (§12.16), veya hedefin bir "URL doğrulama"/routing mantığı
sergilediği (§6). Bu sinyallerden biri yoksa, bu header'ları her
endpoint'te tekrar tekrar denemek düşük getirili bir request
harcamasıdır — request bütçesi (§10.6) daha yüksek öncelikli
adaylara ayrılmalıdır. Sinyal varsa deneme listesi:
`X-Forwarded-Host`, `X-Forwarded-For`, `X-Forwarded-Server`,
`X-Original-URL`, `X-Rewrite-URL`, `X-Host`, `Forwarded` (RFC 7239
standardı, `X-Forwarded-*` ailesinin standart karşılığı). **Daha
düşük öncelikli/koşullu header'lar (yalnızca özel bir zincir
gözlemlenirse anlamlı):** `X-Forwarded-Proto` (yalnızca uygulama bu
değeri bir callback/redirect URL'i **oluşturmak** için kullanıyorsa
anlamlıdır — kendi başına bir SSRF sink'i değildir, `scheme`
reconstruction/canonical URL üretimi için kullanılan bir yardımcı
değerdir), `X-Real-IP` (bazı routing/rate-limit mantıklarında hedef
seçimini etkileyebilir), `Referer`/`Origin` (yalnızca sunucu tarafı
kodun bu değeri okuyup **ayrıca bir dış istek** tetiklediği
gözlemlenirse test edilir — örn. bir "referans doğrulama" özelliği;
bu header'lar **çoğunlukla** SSRF ile ilgisizdir, CORS/CSRF/analytics
amaçlı okunur, kör bir SSRF payload'ı olarak denenmeleri düşük
önceliklidir).
Bu header'lar özellikle reverse-proxy/API-gateway mimarilerinde
(§12.16) ve `:authority` pseudo-header context'inde (§12.1) yüksek
önceliklidir.

**Array/çoğul parametre formu — kolayca gözden kaçan bir varyant:**
Yukarıdaki her isim, tekil formunun yanında bir **dizi/liste** olarak
da karşınıza çıkabilir — özellikle toplu import özelliklerinde
(`urls`, `urls[]`, `links[]`, `images[]`, `webhook_urls`,
`attachment_urls` gibi). Bu formların tespiti ve testi tekil forma
göre iki ek incelik gerektirir: (1) dizinin **her elemanı** ayrı
ayrı test edilmeli (yalnızca ilk/son eleman değil — bazı framework'ler
yalnızca birini işler, bkz. B27 JSON array injection), (2) dizi
formatının kendisi (`url[0]=`, `url[]=`, JSON array) hedefin
kullandığı framework'e göre değişir, context detection (§6)
sırasında bu format da ayrıca doğrulanmalıdır.

**Bilinçli olarak DIŞARIDA bırakılanlar:** `id`, `type`, `name`,
`title`, `description`, `status`, `format`, `config`, `data`,
`content`, `value`, `key`, `token` gibi son derece jenerik terimler
bu listeye **kasıtlı olarak eklenmemiştir** — nadirlik/ayırt edicilik
esastır, kapsayıcılık değil. Benzer şekilde `map_url`,
`translation_url` gibi bağlamsal olarak SSRF'e işaret etme ihtimali
düşük, çok genel görünen isimler de kasıtlı olarak eklenmemiştir —
bu isimler görülürse §2'deki endpoint-kategorisi eşleşmesine (bir
"harita"/"çeviri" özelliğinin gerçekten harici bir URL çektiği
doğrulanmışsa) bakılarak değerlendirilmelidir, isim başına otomatik
öncelik verilmez.

**Yazım biçimi notu:** Yukarıdaki terimler örnek olarak tek bir
biçimde (snake_case veya camelCase) yazılmıştır — gerçek hedeflerde
her ikisi de (`downloadUrl`/`download_url`, `imageUri`/`image_url`
gibi) görülebilir; tarama sırasında hem snake_case hem camelCase hem
de kebab-case (`download-url`) varyantları aranmalıdır, bu bir
kısıtlama değil bir hatırlatmadır.

**Bu listenin ne işe yaradığına dair kritik netleştirme — YANLIŞ
ANLAŞILMAYA AÇIK BİR NOKTA:** Bu liste bir "internette/hedefte bu adı
taşıyan her URL'i tara" listesi **değildir**. Doğru kullanım akışı
tam tersi yönde işler:

1. Recon aşamasında (§2 "Endpoint/parametre adayları nereden
   çıkarılır") **hedefin kendi** endpoint'leri/parametreleri
   toplanır (Burp geçmişi, JS bundle'ları, OpenAPI spec'i vb.).
2. Bu listedeki isimler, toplanan **gerçek** parametre adlarıyla
   eşleştirilir — örn. hedefte `POST /api/webhook {"callback_url":
   "..."}` gibi bir endpoint görülüyorsa, `callback_url` bu listeyle
   eşleştiği için risk skoruna +3 puan alır (§2 Risk skoru tablosu).
3. Payload (canary, IP-encoding varyantları vb.) **yalnızca o
   spesifik parametrenin değerine** gönderilir — liste kendisi asla
   bir hedef/URL kaynağı değildir.

**İki yönlü, birbirini tamamlayan sınır (§2'deki mevcut ilkeyle
tutarlı):**
- Liste **zorunlu bir gate değildir** — parametre adı listede
  olmayan bir aday da test edilebilir, yalnızca önceliği daha
  düşüktür (kuyrukta geriye alınır, elenmez).
- Liste **tek başına yeterli kanıt da değildir** — bir parametre
  adının listeyle eşleşmesi, o parametrenin zafiyetli olduğu
  anlamına gelmez; yalnızca "bu parametreye generic detection
  probe'u (§5) denemeye değer" anlamına gelir. Asıl zafiyet kanıtı
  hâlâ §8.4'teki evidence kurallarından gelir.

Özetle: bu liste bir **öncelik sıralaması** aracıdır, ne bir tarama
hedefi listesi ne de bir zafiyet kanıtıdır.

### Risk skoru (basit toplama modeli — örnek, standart değil)
| Sinyal | Puan |
|---|---|
| Parametre adı eşleşmesi (URL/adres deseni) | +3 |
| Endpoint kategorisi eşleşmesi | +3 |
| Parametre değeri zaten bir URL formatında (örn. `http://...` içeriyor) | +4 |
| Response header'larında outbound HTTP client imzası (`X-Forwarded-For` işleniyor, `Via` header'ı vb.) | +2 |
| Teknoloji fingerprint bilinen bir SSRF-prone framework'e işaret ediyor (§13) | +2 |
| Stored/indirect zincir şüphesi (örn. bir webhook kaydı, sonradan tetikleniyor) | +2 |

Toplam ≥5 olan (endpoint, parametre) çiftleri generic detection
kuyruğuna öncelikli alınır.

**Kritik netleştirme — bu skor bir SIRALAMA/ÖNCELİKLENDİRME
heuristiği'dir, bir eleme/gate mekanizması DEĞİLDİR:** Skor eşiğin
altında kalan (veya "parametre değeri şu an URL formatında değil"
gibi tekil bir sinyalin eksik olduğu) adaylar **atlanmaz**, yalnızca
kuyrukta daha geriye alınır. Örneğin bir `url` parametresi henüz
`http://` içermiyor diye (belki uygulama önüne sabit bir prefix
ekliyor, belki kullanıcı henüz doldurmamış) bu parametreyi test
dışı bırakmak, gerçek zafiyetleri kaçırmanın (false negative) en
sık nedenlerinden biridir — böyle bir "zorunlu önkoşul" kuralı
**kasıtlı olarak eklenmemiştir**. Zaman/request bütçesi kısıtlıysa
skor sıralamayı belirler, ama düşük skorlu bir adayın **hiç**
denenmemesi bu skill'in tasarım amacına aykırıdır.

### Duplicate önleme (agent state)

**Model düzeltmesi:** `evidence_category`, bir probe'un **sonucudur**
(çıktısı), probe'un **kimliğinin** bir parçası değildir — bu ikisini
aynı anahtar içinde tutmak, bir `target_hypothesis` değiştiğinde
(örn. AWS → GCP fingerprint güncellemesi) veya yeni bir evidence
türü aranmak istendiğinde (örn. önce reflection kontrolü yapıldı,
şimdi aynı probe'un OOB sonucu da kontrol edilmek isteniyor) gereksiz
"tekrar deneme" karmaşasına yol açabilir. Bu nedenle iki ayrı yapı
kullanılır:

**`probe_identity`** — bir probe'un **girdisini** tanımlar, tekrar
denenip denenmediğini bu belirler:

| Alan | Açıklama |
|---|---|
| endpoint | Test edilen URL/route |
| parameter | Etkilenen parametre adı |
| context | full-url / hostname-only / path-fragment / header-value / xml-entity / config-value (§6) |
| payload_family | canary-oob / ip-obfuscation / protocol-smuggling / cloud-metadata / dns-rebinding vb. |
| canonical_payload | Payload'ın normalize edilmiş/kanonik hali (bkz. §8.2.6) |
| delivery_mode | Nasıl gönderildiği: query-param / body-json / header / multipart / config-value |

**`probe_result`** — aynı `probe_identity` için elde edilen
**çıktıyı** ayrı ayrı tutar, probe'un tekrar denenip denenmeyeceğini
etkilemez:

| Alan | Açıklama |
|---|---|
| target_hypothesis | O anki lider hedef tahmini (AWS/GCP/Azure/internal-service/unknown) — değişebilir, probe'u geçersiz kılmaz |
| evidence_category | reflection/oob/timing/error-differential/stored-indirect (§8.3) — bir probe birden fazla evidence kategorisi üretebilir |
| classification | confirmed/probable/inconclusive/negative (§8.4) |

Yeni bir probe denemeden önce `probe_identity` tablosunu kontrol et —
aynı `probe_identity` daha önce denenmişse **payload'ın kendisi**
tekrar gönderilmez, ama `target_hypothesis` güncellendiğinde veya
yeni bir evidence kategorisi aranmak istendiğinde (örn. yalnızca
reflection kontrolü yapılmış bir probe için şimdi OOB kontrolü de
isteniyor) aynı `probe_identity` üzerinde **yeni bir `probe_result`
kaydı** açılabilir — bu bir "tekrar" sayılmaz, çünkü aranan kanıt
türü farklıdır.

### Çoklu Host / Wildcard Scope Triage (`*.example.com` gibi geniş kapsam)

Scope tek bir host değil bir wildcard/subdomain listesiyse (onlarca
veya yüzlerce host), aşağıdaki triage katmanı §2'deki parametre-seviyesi
risk skorunun **üstüne** eklenir. **Temel kural, tüm skill boyunca
geçerli olan aynı ilkedir: bu bir önceliklendirmedir, bir eleme
değildir — düşük öncelikli bir host asla scope'tan çıkarılmaz, yalnızca
kuyrukta daha geriye alınır.** Kaynak/zaman sonsuz değilse önce
yüksek öncelikliler test edilir, ama kaynak yeterliyse **scope'taki
her host** aynı pipeline'dan (§1 Layer modeli) geçirilir.

**1. Host-seviyesi risk skoru (parametre skoruyla aynı toplama
mantığı, ayrı bir eksen):**

| Sinyal | Puan |
|---|---|
| Subdomain adı yüksek öncelikli bir işlevi işaret ediyor (`admin.`, `api.`, `internal.`, `staging.`, `jenkins.`, `gitlab.`, `grafana.`, `webhook.` vb.) | +3 |
| Teknoloji fingerprint'i §13'teki bilinen bir SSRF-prone framework/CMS ile eşleşiyor | +3 |
| Host'ta §2'deki yüksek öncelikli endpoint kategorilerinden biri (webhook, önizleme, import, screenshot vb.) doğrudan görünüyor | +4 |
| Host, scope'taki diğer host'larla **aynı codebase/deployment** olduğu bilinen bir "sibling" (aşağıya bkz.) | +2 (kendi başına değil, bir referans host'tan devralınan bulgu varsa) |
| Host canlı ama teknolojisi/işlevi belirsiz | 0 (elenmez, yalnızca kuyrukta nötr sırada) |

Bu skor **yalnızca deneme sırasını** belirler — §2'deki parametre
skorunda olduğu gibi, düşük skorlu bir host da mutlaka test edilir,
yalnızca daha sonra.

**2. Sibling-host propagation (bulgu transferi) — en verimli teknik:**
`app1.example.com`, `app2.example.com`, `customer-a.example.com` gibi
subdomain'ler çoğunlukla **aynı kod tabanının farklı deployment'larıdır**
(multi-tenant SaaS, farklı müşteri instance'ları, farklı ortamlar).
Bu durumda:
```
1. Bir host'ta (örn. app1) bir endpoint/parametre confirmed/probable
   SSRF olarak işaretlendiğinde
2. Aynı path + aynı parametre + aynı payload, diğer sibling host'lara
   (app2, app3, ...) DOĞRUDAN denenir — sıfırdan discovery/context/
   fingerprint pipeline'ı tekrarlanmaz, çünkü aynı kod muhtemelen aynı
   sink'i taşır
3. Sibling'lerden biri FARKLI davranırsa (örn. app2'de aynı payload
   negatif dönüyorsa) bu tek başına "app2 güvenli" anlamına gelmez —
   farklı bir konfigürasyon/versiyon/WAF katmanı olabilir; app2 için
   standart pipeline (§1) sıfırdan çalıştırılmalı, sibling
   propagation yalnızca bir **hızlandırma**dır, yerine geçen bir
   "atla" mekanizması değildir.
```
**Sibling tespiti nasıl yapılır:** Aynı response header imzası/aynı
teknoloji fingerprint'i (§7), aynı sayfa yapısı/aynı statik dosya
hash'i, veya doğrudan bilinen bir multi-tenant mimarisi (örn. bir
SaaS ürününün her müşteri için `{musteri}.example.com` şeklinde
subdomain vermesi) sibling ilişkisinin göstergesidir.

**3. Paralel çalışma (§10.7'nin çoklu-host genişletmesi):** Farklı
host'lardaki generic probe'lar (§5) paralel yürütülebilir — her host
için canary'ler zaten biricik olduğundan (§9.3) OOB sonuçları
karışmaz. **interactsh-client tek bir oturumda tüm host'lar için
paylaşılabilir** — her host'a farklı bir subdomain/path segmenti
atanarak (`app1.<canary>.oast.fun`, `app2.<canary>.oast.fun` gibi)
tek bir log dosyasından hangi host'un OOB tetiklediği ayırt edilir;
host başına ayrı bir interactsh-client örneği başlatmaya gerek yoktur.

**4. State modeli genişlemesi:** `probe_identity`'deki `endpoint`
alanı zaten tam URL'i (host dahil) içerir — çoklu host senaryosunda
ek olarak bir `host_group` alanı (hangi sibling grubuna ait olduğu)
tutulması, hem duplicate-önleme hem sibling-propagation kararlarını
kolaylaştırır.

**5. Request bütçesi (§10.6) host başına ayrı düşünülür** — tek bir
host'un bütçesini tüketmesi diğer host'ların test edilmesini
engellemez; her host kendi bağımsız bütçesiyle değerlendirilir,
toplam scope büyükse öncelik yukarıdaki host-skoruna göre belirlenir.

**6. Büyük scope tek oturumda bitmiyorsa:** Bkz. §1.8 Oturumlar-Arası
Devamlılık — host-skoru ve tamamlanma durumu (`completed`/`pending`)
kalıcı bir state'e yazılarak bir sonraki oturumda kaldığı yerden
devam edilir, aynı host'lar sıfırdan taranmaz.

**Özet — kaçırılmaması gereken tek kural:** Wildcard scope'ta hiçbir
host, yalnızca "düşük öncelikli görünüyor" diye testin dışında
bırakılmaz. Triage yalnızca **hangi host'un önce** test edileceğini
belirler; kaynak/zaman yeterliyse hepsi test edilir.

---

## 4. SSRF Sink Discovery

Parametre adlarının yanı sıra, mümkünse **sink pattern'lerini** de ara.
Kaynak koda erişim varsa (açık kaynak proje, expose `.git`, JAR/paket
dekompilasyonu, hata mesajlarında sınıf/kütüphane adı) şu tür isimler
bir sinyaldir:

- `requests.get(...)`, `urllib.request.urlopen(...)`, `httpx.get(...)`
  (Python)
- `axios.get(...)`, `fetch(...)`, `http.request(...)`,
  `node-fetch`, `got(...)` (Node.js)
- `HttpClient.send(...)`, `URLConnection.openConnection(...)`,
  `OkHttpClient`, `RestTemplate.getForObject(...)`,
  `WebClient.get()` (Java/Spring)
- `curl_exec(...)`, `file_get_contents(...)` (URL wrapper'ı açıksa),
  `fopen(..., "r")` (URL wrapper'ı açıksa) (PHP)
- `HttpClient.GetAsync(...)`, `WebRequest.Create(...)` (.NET)
- `Net::HTTP.get(...)`, `open-uri` (Ruby)

**Black-box (kaynak koda erişim yok) senaryoda** sink discovery
pratikte §2'deki attack surface taramasıyla örtüşür: yüksek öncelikli
endpoint kategorileri zaten bu sink'lerin dışarıdan gözlemlenebilir
izleridir. Response header'larında görülen HTTP client imzaları
(`User-Agent` echo'su, `Via`, `X-Forwarded-*` işleme davranışı) hem
sink discovery hem fingerprinting (§7) için aynı anda kullanılabilir.

### Konsolide Edilmiş Input-Location Haritası

Bu skill boyunca input'un gelebileceği yer (delivery mekanizması)
farklı bölümlere dağılmış durumda — aşağıdaki tablo, hangi input
konumunun nerede detaylandırıldığını tek bir yerden gösteren bir
**indeks**tir (yeni bir teknik tanımlamaz):

| Input Konumu | Detaylandırıldığı Bölüm |
|---|---|
| Query/body parametreleri (klasik) | §2 parametre listesi |
| JSON alanları (nested dahil) | §2, §6 "JSON-field context" |
| XML/SVG/DOCX/PDF içi referanslar | §9.2, §3.3 (XXE overlap) |
| Multipart/dosya içeriği | §9.2 |
| HTTP header'ları | §2 "Header-tabanlı SSRF vektörleri" (sinyal-güdümlü, bkz. not) |
| Cookie değerleri | Ayrı ele alınmamıştır — header-value context (§6) ile aynı mantık uygulanır, nadir ama olası bir vektördür |
| URL path segmentleri | §6 "path-fragment context" |
| Config/YAML/manifest değerleri | §6 "config/manifest-value context", §11 (Kubernetes/CI-CD) |
| Stored/kayıtlı alanlar (webhook vb.) | §9.1 |
| Array/çoğul formlar (`urls[]` vb.) | §2 "Array/çoğul parametre formu" |
| GraphQL argümanları | §11 GraphQL notu |
| WebSocket mesaj içeriği | Ayrı ele alınmamıştır — bir WebSocket bağlantısı kurulduktan sonra mesaj içeriğinin bir SSRF sink'ine ulaşması, uygulamaya özel bir mimari gerektirir; genel prensip aynıdır (§5 generic detection), ayrı bir protokol profili değildir |
| Reverse-proxy/gateway routing (parametre değil) | §12.16 (infrastructure-mediated, ayrı bir keşif kanalı — §1.1) |
| URL içindeki URL (örn. bir redirect/callback URL'in query string'i içinde başka bir URL) | Ayrı ele alınmamıştır — context detection (§6) sırasında fark edilmesi gereken iç içe bir örüntüdür, ayrı bir mekanizma değildir |

Bu tablo tamamlanmış bir liste değildir — amaç, "input nereden
geliyor" sorusunu sorarken hangi bölüme bakılacağını hızlıca
bulmaktır.
