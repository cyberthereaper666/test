## 15. Referans Araçlar ve Kaynaklar

**Araçlar:**
- **interactsh-client** (bkz. §9.3) — OOB testleri için birincil ve
  bu skill'in merkezi bağımlılığı; blind SSRF confirmation'ının büyük
  çoğunluğu bu araca dayanır.
- **Gopherus** (`tarunkant/Gopherus`) — gopher protokol smuggling
  payload'larını (Redis, Memcached, SMTP, MySQL, FastCGI için) doğru
  RESP/binary encoding ile otomatik üreten bir araç; §12.3'teki elle
  hazırlanan payload'ların encoding hatasına açık olması nedeniyle
  gerçek testte bu aracın kullanılması önerilir.
- **remote-method-guesser** — Java RMI hedeflerine karşı gopher
  payload'ı hazırlamak/kullanmak için (Gopherus'un Java RMI'a özgü
  bir tamamlayıcısı); Java-tabanlı bir hedefte RMI servisi tespit
  edilirse kullanılır.
- **SSRFmap** — bilinen SSRF payload ailelerini (cloud metadata,
  protokol şemaları, IP encoding varyantları) otomatik deneyen bir
  tarama aracı; bu skill'in §5/§8'deki manuel/sinyal-güdümlü
  metodolojisinin yerine değil, tamamlayıcısı olarak düşünülmelidir —
  otomatik tarama negatif dönse bile bu skill'deki context-detection
  ve bypass metodolojisi elle uygulanmalıdır.
- **ipfuscator** (`dwisiswant0/ipfuscator`) — §8.2.2'deki IP encoding
  varyantlarının (decimal/octal/hex/karışık taban) tamamını bir IPv4
  adresinden otomatik üreten bir araç; elle üretmek yerine bu skill'in
  §8.2.1 sıralı deneme stratejisiyle birlikte kullanılabilir.
- **r3dir** (`Horlad/r3dir`) — §8.2.4'teki redirect-tabanlı bypass
  için kendi sunucunu barındırmadan seamless redirect-hedef fuzzing
  sağlayan bir redirection servisi; Burp'e Hackvertor tag'leriyle
  entegre edilebilir.
- **Singularity of Origin** — DNS rebinding saldırıları için özelleşmiş
  bir framework/araç (bkz. §3.5); `1u.ms` gibi hazır bir servis
  yeterli olmadığında (özel TTL/IP çifti senaryoları gerektiğinde)
  kullanılır.
- **OOB yakalama alternatifleri (interactsh dışında, denklik amaçlı
  listelenmiştir — bu skill interactsh'i birincil araç olarak
  benimser, §9.3):** Burp Collaborator (Burp Suite'e entegre),
  `canarytokens.org`, `ssrf-sheriff` (`teknogeek/ssrf-sheriff`),
  `webhook.site`, `pingb.in`.

**Bilgi kaynakları (araç değil, referans dokümantasyon):**
- **PortSwigger Web Security Academy — "Server-side request forgery
  (SSRF)"** — SSRF'nin temel taksonomisi (full/blind), cloud metadata
  istismarı ve yaygın bypass tekniklerine dair birincil eğitim
  kaynağı.
- **PayloadsAllTheThings** (`swisskyrepo/PayloadsAllTheThings`) —
  "Server Side Request Forgery" bölümü; cloud provider'a özgü
  metadata endpoint listeleri, IP encoding varyantları ve redirect
  status code (307/308) notları için geniş bir referans.
- **HackTricks** — "SSRF (Server Side Request Forgery)" ve
  "URL Format Bypass" alt sayfaları; protokol şeması istismarı, curl
  URL globbing, ve anormal redirect status code zinciri gibi ileri
  seviye teknikler için güncel tutulan bir kaynak, düzenli olarak
  tekrar kontrol edilmelidir.
- **Orange Tsai — "A New Era of SSRF: Exploiting URL Parser in
  Trending Programming Languages"** (Black Hat araştırması) — §8.2.3'teki
  parser confusion payload'larının birincil kaynağı; farklı dillerin
  URL parser'larının RFC 3986 yorumlama farklarını sistematik olarak
  belgeler.
- **Cloud provider resmi dokümantasyonu** (AWS IMDSv2 geçiş rehberi,
  GCP metadata server güvenlik notları, Azure IMDS dokümantasyonu) —
  her provider'ın kendi SSRF-koruma mekanizmasının (token/header
  zorunluluğu) güncel davranışını doğrulamak için birincil kaynaktır.
- **Not — bu dosyada bilinçli olarak yapılmayan bir şey:** Bu skill
  dosyası, hiçbir yerde spesifik bir CVE/GHSA kimliği veya kesin
  sürüm numarası hard-code etmez — davranış (ör. "IMDSv2 zorunlu
  ortamlarda token adımı gerekir") anlatılır ve şüpheli/yüksek etkili
  bir iddiayla karşılaşıldığında güncel kaynaktan **testte ampirik
  olarak** doğrulanması önerilir.
- **`verify_before_use` prensibi — özellikle bölgesel/az yaygın cloud
  provider profilleri için (§12.10-§12.15):** Bu skill'deki Hetzner,
  Linode/Akamai, Vultr, Scaleway, OpenStack gibi daha az global
  hedefte karşılaşılan provider profilleri, yazım anında doğrulanmış
  resmi dokümantasyona dayanır — ama bu tür sağlayıcıların
  API'leri/endpoint yolları AWS/GCP/Azure'a göre **daha sık ve daha az
  duyurulu** şekilde değişebilir. Bu profillerden biri kullanılmadan
  önce (özellikle bir payload art arda birkaç denemede de negatif
  dönüyorsa), agent'ın o provider'ın **o anki** resmi dokümantasyonunu
  hızlıca teyit etmesi (bir web araması ile) önerilir — bu, ekstra bir
  "izin" adımı değil, request bütçesini (§10.6) yanlış/eskimiş bir
  path'e harcamamak için bir verimlilik adımıdır.
