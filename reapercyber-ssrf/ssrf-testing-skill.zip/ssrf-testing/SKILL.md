---
name: ssrf-testing
description: Server-Side Request Forgery (SSRF) tespiti, fingerprinting, context detection, protokol/hedef-özel exploitation ve raporlama için kapsamlı test skill'i. HTTP(S), file, gopher, dict, FTP, LDAP protokol handler'ları; AWS/GCP/Azure/Alibaba/Oracle/DigitalOcean/Kubernetes cloud metadata servisleri; ve bilinen CMS/framework SSRF sink'lerini kapsar. Yalnızca yetkilendirilmiş bug bounty / pentest / CTF ortamlarında kullanılır.
---

# Server-Side Request Forgery (SSRF) — Kapsamlı Test Skill'i

## 0. Amaç, Kapsam ve Güvenlik Sınırı

### 0.1 Kapsam

**Kapsam içi:** Server-Side Request Forgery (SSRF) — tüm türleri:
**full/basic SSRF** (response'ta hedef sunucunun cevabı doğrudan
yansıtılıyor), **blind SSRF** (hiçbir yansıma yok, yalnızca OOB/timing
ile doğrulanabilir), **semi-blind SSRF** (yansıma yok ama hata mesajı/
status code/timing farkı üzerinden dolaylı sinyal alınabiliyor), ve
protokol bazlı tüm alt türler: HTTP(S) tabanlı SSRF, **dosya sistemi
protokol handler'ları** (`file://`), **binary protokol smuggling**
(`gopher://` üzerinden Redis/Memcached/SMTP/HTTP request forgery),
**diğer URL şeması handler'ları** (`dict://`, `ftp://`, `ldap://`,
`tftp://`, `sftp://`, `jar://`, `netdoc://`), ve **cloud metadata
servisi istismarı** (AWS IMDS, GCP metadata server, Azure IMDS,
Alibaba Cloud, Oracle Cloud, DigitalOcean, Kubernetes API server).

**Kapsam dışı (ama sık karışan komşu sınıflar — ayrım §3'te
detaylandırılmıştır):** **Open Redirect** (yalnızca istemciyi/
tarayıcıyı yönlendirir, sunucunun kendisi hedef URL'e istek atmaz —
§3.1), **CSRF** (Cross-Site Request Forgery — istemci/tarayıcı
kimlik bilgisiyle üçüncü taraf bir sunucuya sahte istek yaptırma,
SSRF'nin "sunucunun kendisi istek atar" modelinden temelde farklı
bir tehdit modeli — §3.2), **XXE tabanlı SSRF** (XML External Entity
işleme zincirinin bir SSRF birincil vektörü olarak kullanılması —
kapsam dışıdır çünkü kök neden ve tespit metodolojisi XML parser'a
özgüdür, ama bu skill §3.3'te bu overlap'i ve XXE skill'ine nasıl
devredileceğini açıklar), **RFI/LFI** (Remote/Local File Inclusion —
sunucunun bir dosyayı/URL'i doğrudan **kod olarak çalıştırmak**
üzere include etmesi; SSRF'nin "veri olarak getirme" modelinden
farklıdır — §3.4), **DNS rebinding** (SSRF doğrulamasını atlatmak
için kullanılan bir **teknik**tir, ayrı bir zafiyet sınıfı değildir —
bu skill'in §8.2'sinde bir bypass kategorisi olarak ele alınır, ayrı
bir üst başlık değildir).

### 0.2 Etik / Güvenlik Sınırı

Testler yalnızca yetkilendirilmiş scope içinde yapılır. **Gerçekten
gerekli olan tek sınırlar:**
- Dosya/veri **silme veya değiştirme yok**.
- **Kalıcı** sistem/konfigürasyon değişikliği **yok**.
- **Reverse shell veya kalıcı C2 yok**.
- Kasıtlı ağır **DoS yok** (özellikle internal port/network taraması
  yaparken — bkz. §9.4 sınırlı port taraması kuralı).
- Test **scope'un dışına sıçramaz** — SSRF'nin doğası gereği bir
  istek **her zaman** hedef uygulamanın bulunduğu ağdan/cloud
  hesabından çıkar; bu nedenle "scope dışına sıçrama" burada özel bir
  anlam kazanır: yalnızca **hedef uygulamanın kendi altyapısına**
  (kendi internal network'ü, kendi cloud metadata'sı, kendi internal
  servisleri) yönelik istekler kapsam içidir — üçüncü taraf bir
  sistemin (başka bir müşterinin cloud hesabı, hiç ilgisi olmayan bir
  internal IP aralığı) taranması kapsam dışıdır.

**Bunların dışında kalan her şey serbesttir** — cloud metadata
servislerinden credential/token okuma, internal servislerin banner/
versiyon bilgisini toplama, internal network topolojisini haritalama
(port taraması dahil, sınırlı ve makul kapsamda), internal admin
panellerine erişimin gösterilmesi — bunlar SSRF'nin "gerçek etkiyi
kanıtlama" gereğinin normal ve beklenen parçasıdır. Cloud metadata'dan
elde edilen bir **geçici credential'ı** (örn. AWS STS token) gerçek
API çağrılarında kullanmak (örn. `aws sts get-caller-identity` ile
kimin/hangi rolün olduğunu doğrulamak) makul bir confirmation
adımıdır; ama bu credential ile **kalıcı/yıkıcı** bir aksiyon
(kaynak silme, IAM policy değiştirme) almak §0.2'nin "kalıcı sistem
değişikliği yok" sınırını ihlal eder — token'ın **var olduğunu ve
kullanılabilir olduğunu** kanıtlamak yeterlidir.

## 1. Genel Metodoloji Akışı

Bu section, skill'in **zorunlu execution contract'ıdır**. Agent önce
scope'u doğrular; ardından yalnızca elde edilen sinyale göre ilgili
layer'a geçer. Aşağıdaki sıra bir "her endpoint'te her şeyi çalıştır"
checklist'i değildir.

### 1.1 Layer modeli

```text
Layer 1 — Discovery / Source / Sink
   ↓
Layer 2 — Generic SSRF Detection (protokol/hedef bilinmeden)
   ↓
Layer 3 — Context Detection (URL nereye/nasıl besleniyor)
   ↓
Layer 4 — Target/Protocol Fingerprinting (hangi ağ, hangi protokol, hangi cloud)
   ↓
Layer 5 — Confirmation (bağımsız evidence ile doğrulama)
   ↓
Layer 6 — Impact Assessment / Reporting
```

Her layer, bir öncekinden gelen **sinyale** göre dallanır — sinyal
negatifse bir sonraki aday endpoint/parametreye geçilir, aynı layer'da
tekrar tekrar denenmez (bkz. §2 Duplicate önleme).

**Layer 1'in iki paralel keşif kanalı olduğu unutulmamalı:** Layer 1
(Discovery) tek bir kanal değildir — **Application-level Discovery**
(§2, parametre/endpoint taraması) ve **Infrastructure-Mediated
Discovery** (§12.16, reverse-proxy/gateway routing testi) **paralel**
çalıştırılması gereken iki ayrı kanaldır. Application-level tarama
hiçbir aday bulamasa bile Layer 1'in "tamamlandığı" anlamına gelmez —
infrastructure kanalı ayrıca test edilmeden Layer 1 kapatılmaz.

### 1.2 Signal → Decision → Action → Result

```text
Signal:    Aday endpoint/parametre tespit edildi (§2)
Decision:  Risk skoru eşik üstünde mi? (§2 Risk skoru tablosu)
Action:    Generic detection probe'u gönder (§5)
Result:
  ├─ Outbound request evidence VAR → Context Detection'a geç (§6)
  └─ Outbound request evidence YOK →
         ├─ Blok sinyali var mı? (HTTP 403/401/406, WAF blok sayfası, vb.)
         │    ├─ EVET + SSRF ile ilişkili (bkz. §8.2 blok tespiti) →
         │    │    BYPASS pipeline'a geç (§8.2) — sonraki adaya GEÇME
         │    └─ EVET + SSRF ile ilgisiz (auth/CSRF/rate-limit) →
         │         adayı "beklemede" listesine al, sonraki adaya geç
         └─ Blok sinyali yok (gerçekten evidence yok) →
              bağlam/protokol alternatiflerini dene (§1.6 fallback),
              hepsi tükenirse sonraki adaya geç
```

**403/401 alındığında varsayılan davranış bypass denemesidir —
bu, kullanıcının açıkça onaylamasını gerektirmeyen, skill'in yerleşik
default'udur.** "Evidence yok → sonraki adaya geç" kuralı yalnızca
blok sinyali de yoksa (gerçekten sessiz/belirsiz bir negatif) geçerlidir.
Detaylı blok tespiti ve bypass sıralaması için bkz. §8.2.

Bu döngü her aday için tekrarlanır. **Karar kayıt sözleşmesi:** Agent,
her denenen (endpoint, parametre, context, payload_family,
target_hypothesis, evidence_category) 6'lısını bir state tablosunda
tutar (somut şema §2'de) — aynı kombinasyon tekrar denenmez.

### 1.3 Signal önceliği ve fail-safe

Çelişen sinyaller ortaya çıktığında öncelik şu sıradadır:
1. **OOB evidence (interactsh callback)** (§9.3) — en güvenilir, çünkü
   sunucunun gerçekten dışa istek attığını ağ seviyesinde kanıtlar.
2. **Full/reflected response evidence** (§5.1) — ikinci güvenilir,
   hedef sunucudan gelen içeriğin doğrudan görünmesi.
3. **Error-signature/status-code differential** (§7, §8.3) — üçüncü
   güvenilir, dolaylı ama tutarlı bir sinyal.
4. **Timing** (§9.4) — en zayıf, tek başına confirmed sayılmaz.

Fail-safe kural: Belirsizlik durumunda **daha düşük** classification'a
düş (`confirmed` yerine `probable`, `probable` yerine `inconclusive`) —
asla belirsiz bir sinyali "confirmed" olarak yukarı yuvarlama.

### 1.4 Hızlı Referans Tablosu

| Kategori | Delivery Mekanizması | Confirmation Zorluğu |
|---|---|---|
| Full/Basic SSRF | Hedef sunucunun cevabı response'a yansıyor | Kolay — doğrudan görülür |
| Semi-blind SSRF | Yalnızca status code/hata mesajı/timing farkı var | Orta — differential comparison gerekir |
| Blind SSRF | Hiçbir yansıma yok | Zor — yalnızca OOB (interactsh) ile confirmed olabilir |
| Protokol smuggling (gopher/dict) | Binary protokol payload'ı HTTP request içine gömülür | Zor — genelde blind, OOB veya yan etki (örn. Redis'e yazılan key) ile doğrulanır |
| Cloud metadata SSRF | `169.254.169.254` veya eşdeğeri hedeflenir | Kolay-Orta — credential/token response'ta görünürse kolay, görünmezse blind teknikleriyle |
| XXE-tabanlı SSRF | XML parser üzerinden dolaylı | XXE skill metodolojisiyle tespit edilir, bu skill yalnızca sonucu SSRF olarak sınıflandırır |

### 1.5 Payload Stage Model (P0–P6)

| Stage | Anlamı |
|---|---|
| P0 — input acceptance | Payload (URL string'inin kendisi) uygulama tarafından reddedilmeden kabul ediliyor mu (henüz hedefe hiçbir bağlantı denemesi yapılmamış olabilir — bu, P6'daki "hedeften dönen verinin saldırgana ulaşması" ile **karıştırılmamalı**, yalnızca girdinin sistem tarafından işlenmeye başlandığının kanıtıdır) |
| P1 — parsing | Uygulama URL'i "tanıyor" mu (bir URL parser'dan geçiyor mu, hata vermeden kabul ediliyor mu) |
| P2a — DNS resolution observed | Hedef hostname için bir DNS sorgusu gözlemlendi mi (interactsh'te yalnızca DNS interaction kaydı) — bu, bir TCP bağlantısının da denendiğinin kanıtı **değildir** |
| P2b — TCP connection attempt observed | Hedefe bir TCP bağlantı denemesi (SYN, timing farkı, connection-refused hatası) gözlemlendi mi — DNS aşamasından **bağımsız** olarak, hedef IP-literal olarak verilmişse DNS hiç devreye girmeden doğrudan bu aşamaya geçilebilir |
| P3 — confirmed contact | Kendi kontrolündeki (interactsh gibi) bir endpoint'e **doğrulanabilir** bir bağlantı ulaşıyor mu (yalnızca P2a/DNS-only bir kayıt bu aşamayı kısmen karşılar ama §8.4'teki koşullu kural geçerlidir; P2b + gerçek bir TCP/HTTP etkileşimi bu aşamayı tam karşılar) |
| P4 — protocol negotiation | Hedef protokolün (HTTP/gopher/dict/vb.) tam handshake'i tamamlanıyor mu |
| P5 — response capture | Hedeften dönen cevap sunucu tarafından **okunuyor** mu (blind/full ayrımı burada netleşir) |
| P6 — impact | Hedeften dönen cevap saldırgana bir şekilde **ulaşıyor** mu (doğrudan reflection, dolaylı sinyal, veya OOB exfiltration) |

### 1.6 Protokol-Seviyesi Fallback Zinciri Örneği

```text
http://<canary>.oast.fun çalışmadı (outbound bağlantı yok)
  → https:// dene (bazı whitelist'ler yalnızca http'ye izin verir,
    bazıları yalnızca https'e)
    → çalışmadı → http://<canary>.oast.fun:443/ dene (443 portuna
      HTTP — bazı port-tabanlı filtreler yalnızca port numarasına
      bakar, şema/port uyumsuzluğunu kontrol etmez)
      → çalışmadı → protocol-relative // dene (bazı parser'lar şema
        kontrolünü `//` önekiyle atlatır)
        → çalışmadı → userinfo ile dene: http://<user>:<pass>@
          <canary>.oast.fun/ (bazı allowlist'ler userinfo alanını
          hesaba katmadan yalnızca ilk göze çarpan host-benzeri
          string'i kontrol edebilir — bkz. §8.2.3)
          → çalışmadı → query-string confusion dene:
            http://<canary>.oast.fun?@expected-safe-domain.com/
            (bazı naif regex kontrolleri `?` sonrasını görmezden
            gelip yalnızca `@` öncesini host sanabilir — B8/B9 ile
            aynı aile, farklı bir sözdizimi varyantı)
            → çalışmadı → IP-literal dene (DNS çözümlemesi
              engelleniyor olabilir — bkz. §8.2 IP obfuscation
              teknikleri)
              → çalışmadı → context detection'a geri dön (§6), belki
                parametre bir URL değil bir hostname/path fragment'i
                bekliyor (örn. yalnızca `domain.com` kabul edip
                önüne sabit `https://` ekliyor olabilir)
```

### 1.7 Prerequisite Gate — Cloud Metadata/Protokol-Smuggling Payload'ları Doğrudan Ateşlenmez

Cloud metadata ve protokol smuggling (gopher/dict) payload'ları
**önkoşulsuz ateşlenmez**. Önce P2a/P2b (resolution/connection attempt) ve P3
(reachability) kanıtı elde edilir (genelde kendi kontrolündeki bir
interactsh domain'i ile), ardından hedefin **hangi ağda/cloud'da**
çalıştığı (P4 öncesi bir fingerprinting adımı, bkz. §7) makul bir
güvenle tahmin edilir — ancak o zaman ilgili cloud provider'ın (§12)
veya protokolün metadata/RCE payload'ına geçilir. Bu sıralama hem
gereksiz risk hem de "hangi cloud'da olduğunu bilmeden 6 farklı
provider'ın metadata endpoint'ini rastgele deneme" verimsizliğini
önler.

### 1.8 Oturumlar-Arası Devamlılık (Session Continuity)

Büyük bir scope (özellikle §2'deki wildcard/çoklu-host senaryosu)
tek bir konuşma oturumunda bitmeyebilir. Bu skill'in tüm state
tabloları (`probe_identity`/`probe_result`, host-triage skorları,
fingerprint hipotezleri, evidence kayıtları) **varsayılan olarak
yalnızca o anki oturumun belleğinde** tutulur — bir sonraki oturumda
bu bilgi kaybolur, **meğer ki açıkça kalıcı bir dosyaya yazılmış
olsun**. Bu bölüm, oturumlar arası devamlılığı nasıl sağlayacağını
tanımlar.

**1. Kalıcı state artifact'i — ne zaman ve nereye yazılır:** Scope
büyük görünüyorsa (tek oturumda bitmeyecek kadar çok host/parametre
varsa) veya kullanıcı açıkça "bunu birkaç oturuma bölelim" derse,
agent test oturumunun **erken bir noktasında** bir state dosyası
oluşturur (örn. `ssrf-engagement-state.json`, çalışma dizininde) ve
bu dosyayı **düzenli aralıklarla** (her yeni confirmed/probable
bulgu, her tamamlanan host, veya her birkaç probe'da bir) günceller.
Dosya şu bileşenleri içerir:

```json
{
  "scope": "*.example.com",
  "last_updated": "<zaman damgası>",
  "hosts": {
    "app1.example.com": {"status": "completed", "score": 8, "findings": [...]},
    "app2.example.com": {"status": "in-progress", "score": 6},
    "admin.example.com": {"status": "pending", "score": 9},
    "...": "..."
  },
  "probe_identities_tested": ["<probe_identity kayıtları, §2>"],
  "host_groups": {"sibling-group-1": ["app1...", "app2..."]},
  "pending_oob": ["<gönderilmiş ama henüz interactsh log'unda karşılığı görülmemiş canary'ler ve gönderilme zamanları>"],
  "confirmed_findings": ["<§14.1 formatında özet kayıtlar>"],
  "interactsh_domain_used": "<önceki oturumdaki canary domain, varsa>"
}
```

Bu şema bir zorunluluk değil, bir **öneridir** — agent, mevcut
ortamının araçlarına göre (bir not defteri, bir dosya, bir todo-list
mekanizması) en uygun kalıcı depolama şeklini seçer; önemli olan
şema değil, **hangi bilgilerin** kalıcı tutulması gerektiğidir.

**2. Yeni oturumun başındaki prosedür:** Bir oturum, önceki bir
engagement'a devam ediyorsa (kullanıcı bunu belirtir veya agent
çalışma dizininde bir state dosyası bulur):
```
1. State dosyasını oku
2. `last_updated` zaman damgasına bak — uzun bir süre geçtiyse
   (örn. birkaç gün+), hedefin davranışının DEĞİŞMİŞ olabileceğini
   varsay (patch, config değişikliği, WAF güncellemesi) — devam
   etmeden önce 1-2 baseline probe ile (§5) hedefin hâlâ aynı
   şekilde davrandığını hızlıca doğrula
3. `hosts` listesinde `status: pending`/`in-progress` olanlardan
   devam et — `completed` olanları TEKRARLAMA (bu, §2'deki duplicate
   önleme ilkesinin oturumlar arası uzantısıdır)
4. `pending_oob` listesindeki canary'leri kontrol et (bkz. madde 3)
5. Kaldığı yerden devam et, host-skoruna göre sıralamayı koru
```

**2b. Ortama göre uygulama farkı (KRİTİK — mekanizma araçtan bağımsız
ama ortamın kalıcı dosya sistemi olup olmadığına bağlıdır):**
- **Claude Code, aynı dizinde konuşma geçmişini geri yükleyen bir
  komutla (`--resume`/`--continue` gibi) devam ediliyorsa:** Agent
  zaten önceki konuşmayı hatırlar, state dosyası ek bir güvence/
  checkpoint görevi görür (özellikle çok uzun engagement'larda
  konuşma geçmişi budanmışsa faydalıdır) — dosya yine de okunmalı,
  ama bu senaryoda kritik değildir.
- **Claude Code, konuşma geçmişi geri yüklenmeden aynı dizinde
  yeniden başlatılıyorsa:** Agent'ın **hiçbir** konuşma hafızası
  yoktur — devamlılığın **tamamı** state dosyasına dayanır. Bu
  senaryoda, yeni oturumun başında agent'a açıkça "bu dizinde bir
  engagement state dosyası var mı kontrol et, varsa oradan devam et"
  talimatının verilmesi (veya bir proje talimat dosyasına
  bu kuralın yazılması) gerekir — dosya diskte durur ama agent
  kendiliğinden aramaz, bu adımın tetiklenmesi gerekir.
- **claude.ai (web/mobil arayüz, dosya sistemi kalıcı DEĞİL, her
  konuşma kendi geçici ortamında çalışır):** State dosyası bir
  konuşmadan diğerine **otomatik taşınmaz**. Devam etmek isteniyorsa
  dosyanın (§14'teki `present_files` ile üretilen çıktı gibi)
  **indirilip yeni konuşmaya tekrar yüklenmesi** gerekir.

**3. interactsh-client discontinuity — KRİTİK ve kolay gözden kaçan
bir nokta:** Önceki oturumda başlatılan `interactsh-client` süreci,
oturum bittiğinde muhtemelen **sonlanmıştır** — yeni oturumda
başlatılan bir `interactsh-client` **yeni bir canary domain**
üretir, eskisi değil. Bu, iki önemli sonuç doğurur:
- Önceki oturumdaki `pending_oob` listesindeki canary'lere gelecek
  olan gecikmeli bir OOB ping'i (örn. stored/indirect bir SSRF'in
  saatler sonra tetiklenmesi), **yeni oturumda artık asla
  görülemez** — eski canary domain'i dinleyen süreç artık çalışmıyor.
- **Fail-safe kural (KRİTİK — false negative'i önler):** Bu durumdaki
  bir stored/indirect aday, "test edildi, negatif" olarak
  **işaretlenmez** — `inconclusive/lost-due-to-session-gap` olarak
  işaretlenir ve **yeni bir canary ile yeniden test edilir**. Eski
  bir OOB sonucunun kaybolmuş olması hiçbir zaman "confirmed" bir
  bulguyu geçersiz kılmaz (zaten confirmed olan bir bulgu için bu
  sorun yoktur), ama henüz **beklemede** olan (yanıt bekleyen) bir
  aday için "sessizlik = negatif" varsayımı yapılmaz.
- Eğer engagement'ın uzun sürebileceği **baştan** biliniyorsa, tercih
  edilen yaklaşım `interactsh-client`'ı bir arka plan sürecinde
  (örn. `nohup`/`screen`/`tmux` ile, veya kalıcı bir sunucuda) uzun
  süre canlı tutmaktır — bu, aynı canary domain'in birden fazla
  oturum boyunca geçerli kalmasını sağlar ve yukarıdaki kayıp
  riskini tamamen ortadan kaldırır. Bu mümkün değilse (ortam her
  oturumda sıfırlanıyorsa), yukarıdaki fail-safe kural uygulanır.

**4. Genel ilke (bu bölümün özeti):** Oturumlar arası devamlılık,
**verimlilik** içindir (aynı işi tekrar yapmamak) — asla **kapsam
daraltma** aracı olarak kullanılmaz. Durum belirsizse (bir host'un
gerçekten tam test edilip edilmediği net değilse, bir OOB sonucunun
kaybolup kaybolmadığı belirsizse), varsayılan davranış **yeniden
test etmektir**, "muhtemelen zaten yapılmıştır" varsayımıyla
atlamak değil.

---

---

## Navigasyon İndeksi — Bölüm Numarası → Dosya

Bu skill, tek parça bir dosyadan bu klasör yapısına parçalanmıştır.
**Tüm bölüm numaraları (§1-§16) korunmuştur** — bir dosyanın içinde
"bkz. §8.4" gibi bir çapraz referans görürsen, aşağıdaki tablodan
§8.4'ün hangi dosyada olduğunu bul. İçerik, mimari kararlar (signal-
driven akış, evidence/attribution ayrımı, probe_identity/probe_result
state modeli, maturity-etiketli bypass taksonomisi) **hiçbir şekilde
değiştirilmeden**, yalnızca dosya organizasyonu amacıyla bölünmüştür.

**§1 (Genel Metodoloji Akışı) bu dosyanın (SKILL.md) yukarısındadır**
— execution contract olduğu için ayrı bir reference dosyasına
taşınmamış, §0 ile birlikte skill'in çekirdeğinde tutulmuştur.

| Bölüm | İçerik | Dosya |
|---|---|---|
| §2 | Discovery & Risk Scoring (endpoint kategorileri, parametre adları, risk skoru, duplicate önleme, çoklu host/wildcard triage) | `references/discovery.md` |
| §3 | Source→Sink Modellemesi ve komşu zafiyet sınıflarından ayrım (Open Redirect, CSRF, XXE, RFI/LFI, DNS rebinding) | `references/source-sink-boundaries.md` |
| §4 | SSRF Sink Discovery + Konsolide Input-Location Haritası | `references/discovery.md` (§2'nin devamında) |
| §5 | Generic SSRF Detection (canary probe, evidence kuralı, negatif kontrol) | `references/detection.md` |
| §6 | Context Detection (context türleri, tespit prosedürü, yetki context'i) | `references/context-detection.md` |
| §7 | Hedef/Protokol Fingerprinting (confidence modeli, negative capability matrix, egress fingerprinting, Sink Capability Matrix) | `references/fingerprinting.md` |
| §8.1-8.2.6 | Bypass Taksonomisi (B1-B28, maturity etiketleri, URL Parser Matrix, Canonical Target Resolution Model) | `references/bypass-techniques.md` |
| §8.3-8.4 | Evidence Kategorileri (causality vs attribution) ve False Positive/Negative Eliminasyonu | `references/evidence-and-classification.md` |
| §9 | Stored/Indirect/Blind SSRF, OOB (interactsh-client kurulum/kullanım) | `references/blind-and-stored-ssrf.md` |
| §10 | Confirmation, Impact Assessment, Confidence Scoring | `references/confirmation-and-impact.md` |
| §11 | Modern Mimari Notları (proxy-aware SSRF, microservice/mesh, Kubernetes, GraphQL, CI/CD) | `references/modern-architecture.md` |
| §12 (intro) + §12.1 | Protokol/Hedef Profilleri genel format + HTTP(S) | `references/protocols/http.md` |
| §12.2 | `file://` | `references/protocols/file.md` |
| §12.3 | `gopher://` (protokol smuggling) | `references/protocols/gopher.md` |
| §12.4-12.6 | `dict://`, `ftp/tftp/sftp/ldap/jar/netdoc`, rate-limiting fingerprinting | `references/protocols/other-schemes.md` |
| §12.7 | AWS IMDS | `references/cloud/aws.md` |
| §12.8 | GCP Metadata Server | `references/cloud/gcp.md` |
| §12.9 | Azure IMDS | `references/cloud/azure.md` |
| §12.10-12.12, §12.15 | Alibaba, Oracle, DigitalOcean, Hetzner/Linode/Vultr/Scaleway/OpenStack | `references/cloud/alt-providers.md` |
| §12.13 | Kubernetes API Server / Kubelet | `references/cloud/kubernetes.md` |
| §12.14 | Cloud Metadata Hızlı Referans Tablosu (tüm provider'ların özeti) | `references/cloud/overview.md` |
| §12.16 | Infrastructure/Proxy-Mediated SSRF (reverse-proxy/gateway misconfigürasyonu) | `references/infrastructure-mediated-ssrf.md` |
| §13 | CMS/Framework/Platform → Bilinen SSRF Sink Eşleme Tablosu | `references/framework-sinks.md` |
| §14 | Raporlama ve Payload Metadata Şeması | `references/reporting-and-metadata.md` |
| §15 | Referans Araçlar ve Kaynaklar | `references/tools-and-references.md` |
| §16 | SSRF → RCE Zincirleri (impact yükseltme referansı, derinleşme triage gate) | `references/rce-chains.md` |

### Önerilen okuma sırası (yeni bir SSRF testi başlatırken)

1. Yukarıdaki §0-§1 (bu dosya) — genel akışı ve execution contract'ı anla
2. `references/discovery.md` (§2, §4) — aday endpoint/parametreleri belirle
3. `references/detection.md` (§5) → `references/context-detection.md` (§6) → `references/fingerprinting.md` (§7)
4. Blok/negatif sinyal alındığında → `references/bypass-techniques.md` (§8.1-8.2.6)
5. Confirmation için → `references/evidence-and-classification.md` (§8.3-8.4), blind/stored ise `references/blind-and-stored-ssrf.md` (§9)
6. Confirmed sonrası → `references/confirmation-and-impact.md` (§10), hedefe göre `references/protocols/*.md` veya `references/cloud/*.md`
7. Raporlama için → `references/reporting-and-metadata.md` (§14)

Bu sıralama bir zorunluluk değildir — skill'in tamamı signal-driven
olduğu için, hangi dosyaya ne zaman bakılacağı gerçek zamanlı olarak
elde edilen sinyale göre değişir (bkz. §1.2 Signal→Decision→Action→Result).
