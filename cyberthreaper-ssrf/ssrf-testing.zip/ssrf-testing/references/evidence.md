# Evidence Kategorileri ve False Positive/Negative Eliminasyonu (§8.3–§8.4)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 8.3 Evidence Kategorileri — İki Ayrı Eksen: Causality vs Attribution

```
Eksen 1 — Causality (SSRF'in kendisi)
├── Full/reflected evidence      (hedeften dönen içerik response'ta görünüyor)
├── OOB evidence                 (interactsh callback alındı)
├── Semi-blind differential evidence (§5.1 üçlü karşılaştırma — geçerli/kapalı-port/geçersiz)
└── Stored/indirect execution evidence (zincir haritalama ile doğrulandı mı)

Eksen 2 — Attribution (hangi hedef/ağ/cloud)
├── Target fingerprint evidence   (§7 — header/format sinyalleri)
├── Error signature evidence      (hedefe özgü hata mesajı)
└── Framework/CMS fingerprint evidence (§13 tablosundan)

Destekleyici (tek başına ne causality ne attribution kanıtlar)
└── Context evidence              (payload doğru context'e oturdu mu)
```

**Kanıt bağımsızlığı (Eksen 1 içinde):** Aynı canary domain'ine
gönderilen, yalnızca şema/format farkı olan (örn. `http://` vs
`https://` aynı canary'ye) iki payload, **tek bir kanıt** (OOB
evidence) sayılır. Farklı bir **kanal** (örn. hem OOB hem timing
differential) ile elde edilen ikinci bir kanıt, farklı bir evidence
kategorisi olarak sayılır.

## 8.4 False Positive / False Negative Eliminasyonu

**Sınıflandırma — iki ayrı sonuç üretir (SSRF classification VE hedef
attribution classification ayrı ayrı raporlanır):**

*SSRF (causality) classification:*
- **Confirmed:** Eksen 1'den **tek bir kanıt türü bile** yeterlidir —
  **ancak OOB evidence'ın DNS-only alt türü bu kuralın istisnasıdır**,
  aşağıda ayrıca tanımlanmıştır:
  - **OOB evidence — HTTP interaction (tek başına yeterli):**
    interactsh log'unda benzersiz canary'ye ait gerçek bir HTTP
    isteği kaydı — bu tek başına confirmed için yeterlidir, çünkü bir
    HTTP isteğinin tamamlanması (§1.5 P4) yalnızca DNS çözümlemesini
    değil, gerçek bir TCP bağlantısı + protokol negotiation'ı da
    kanıtlar.
  - **OOB evidence — DNS-only (KOŞULLU, tek başına YETERLİ DEĞİL):**
    Yalnızca bir DNS lookup kaydı (HTTP isteği yok) görülmesi, tek
    başına **confirmed** saymak için yeterli değildir — çünkü bu
    kayıt CDN/reverse-proxy'nin kendi ön-kontrol sorgusundan, bir
    tarayıcı/renderer'ın DNS-prefetch davranışından, ara bir güvenlik
    tarayıcısından, veya DNS önbellek ısıtma mekanizmalarından
    kaynaklanıyor olabilir (bkz. §8.4 aşağıdaki false-positive
    kaynakları). DNS-only bir kayıt **confirmed** sayılabilmesi için
    ek olarak şunlar sağlanmalıdır:
    1. Canary benzersiz ve yalnızca bu spesifik teste ait olmalı,
    2. Sorgunun zamanlaması, uygulamaya gönderilen isteğin
       zamanlamasıyla makul bir korelasyon içinde olmalı (isteği
       gönderdikten saniyeler/dakikalar sonra, günler sonra değil —
       stored/indirect senaryolar hariç, bkz. §9.1),
    3. CDN/proxy/prefetch açıklaması makul biçimde elenmiş olmalı
       (örn. hedefin CDN kullanmadığı biliniyorsa, veya sorgunun
       hedefin bilinen origin IP aralığından geldiği interactsh
       log'unda görülüyorsa).
    Bu üç şart sağlanmıyorsa DNS-only evidence yalnızca **probable**
    olarak sınıflandırılır — bu, §10.5'teki confidence puanlamasında
    DNS-only OOB'un (+4) HTTP+DNS OOB'dan (+6) zaten daha düşük
    puanlanmasıyla da tutarlıdır.
  - **Full/reflected evidence:** Hedeften dönen içeriğin response'ta
    doğrulanabilir şekilde görünmesi.
  - **Semi-blind differential evidence (KOŞULLU — DNS-only OOB ile
    aynı mantık):** §5.1'deki üçlü karşılaştırma (geçerli host+açık
    port / geçerli host+kapalı port / geçersiz host) üç ayrı ve
    tutarlı sonuç veriyorsa — **ama bu tek başına otomatik "confirmed"
    değildir.** Aynı üçlü davranış, uygulamanın kendisinden değil,
    önündeki paylaşılan bir reverse-proxy/WAF/CDN katmanının **kendi**
    bağlantı-hata davranışından da kaynaklanabilir (bu katman birçok
    farklı backend için aynı hata ayrımını üretiyor olabilir, hedef
    uygulamaya özgü olmayabilir). Bu nedenle:
    - **Origin/application attribution netse** (örn. farkın hedef
      uygulamaya özgü bir hata mesajı/header'ında görülmesi, veya
      hedefin bilinen bir proxy/CDN katmanı olmadığının doğrulanması)
      → **confirmed**.
    - **Origin attribution belirsizse** (paylaşılan bir proxy/WAF
      katmanı olası ve elenmemişse) → **probable**, ikinci bağımsız
      bir kanalla (OOB veya full/reflected evidence) desteklenene
      kadar confirmed'e yükseltilmez.
    Bu koşul **payload denemesini durdurmaz** — differential probe
    yine standart akışta denenir, yalnızca sonucun "confirmed" mi
    "probable" mı sayılacağını netleştirir.
  - **Stored/Indirect evidence:** §9.1'deki zincirin her adımı ayrı
    doğrulanmış olmalı.
- **Probable:** Yalnızca timing sinyali var, origin attribution'ı
  belirsiz bir semi-blind differential var, veya semi-blind
  differential'ın yalnızca bir kısmı tutarlı.
- **Inconclusive:** Belirsiz/kısmi sinyal.
- **Negative:** Eksen 1'den hiçbir kanıt alınamadı.

*Target/hedef (attribution) classification — ayrı bir alan:*
- **Confirmed:** En az bir Strong indicator (§7) + tutarlı davranış.
- **Probable:** Yalnızca weak/medium indicator'lar var.
- **Unknown:** Hiçbir attribution sinyali toplanamadı — "Confirmed
  SSRF, hedef: unknown/internal-service" geçerli ve eksiksiz bir
  sonuçtur.

**Yaygın false-positive kaynakları:**
- **CDN/proxy'nin kendi davranışı:** Bazı CDN'ler/reverse proxy'ler
  URL'deki bir domain'e **kendileri** bir ön-kontrol isteği atabilir
  (örn. bir link-checker) — bu, hedef uygulamanın **kendisinin**
  SSRF'e açık olduğu anlamına gelmez, CDN katmanının davranışı
  olabilir; canary'nin **hangi IP'den** geldiğini (interactsh
  log'undaki source IP) hedef uygulamanın gerçek IP aralığıyla
  karşılaştırarak ayırt et.
- **DNS prefetch/önyükleme:** Bazı tarayıcı-tabanlı veya headless
  render araçları, sayfadaki tüm linkler için DNS prefetch yapabilir
  — bu, gerçek bir bağlantı denemesi olmayabilir, yalnızca DNS
  lookup'tır; interactsh log'unda yalnızca DNS kaydı olup HTTP isteği
  YOKSA bu ayrım not edilmelidir (yine de P2/P3 kanıtı olarak
  geçerlidir, ama P4/P5'e (protokol negotiation/response capture)
  ulaşmadığı belirtilmelidir).
- **Zaten var olan meşru bir "URL doğrulama" özelliği** — §6.1'de
  belirtildiği gibi, bazı özellikler kasıtlı olarak dışa istek atar;
  bağlamı kontrol et.

**Yaygın false-negative kaynakları:**
- **Zaman aşımı/yavaş yanıt:** Internal bir hedefe istek gerçekten
  gidiyor ama sonuç dönmeden önce request timeout'a uğruyor olabilir
  — bu durumda P2b (TCP connection attempt) kanıtı için timing farkına
  bakılmalı, "hiç cevap yok = SSRF yok" sonucuna hemen varılmamalı.
- **Yalnızca tek bir protokol/format denenip vazgeçilmesi** — §1.6
  fallback zincirine uyulmadan tek bir payload negatif döndüğünde
  pes edilmesi en sık false-negative kaynağıdır.

**Evidence Tablosu Şablonu** — her aday için tut:

| Alan | Açıklama |
|---|---|
| payload | Kullanılan tam URL/payload |
| context | full-url/hostname-only/path-fragment/header-value/xml-entity/config-value |
| status_code | Baseline ile karşılaştırmalı |
| response_diff | Length/timing/header farkı |
| interactsh_log | OOB log kaydı var mı, DNS mi HTTP mi |
| evidence_kategorisi | full-reflected / OOB / semi-blind-differential / stored-indirect (Eksen 1) veya target-fingerprint/error-signature/framework-fingerprint (Eksen 2) |
| ssrf_classification | confirmed / probable / inconclusive / negative |
| target_classification | confirmed / probable / unknown |
| confidence | §10.5 Confidence Scoring'e göre puan (yalnızca destekleyici) |
