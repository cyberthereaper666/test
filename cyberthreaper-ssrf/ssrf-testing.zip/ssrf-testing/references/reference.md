# Raporlama, Payload Metadata Şeması ve Referans Araçlar (§14, §15)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 14. Raporlama ve Payload Metadata Şeması

### 14.1 Raporlama Şablonu

Her SSRF bulgusu için rapor şu unsurları içermelidir:

1. **`vulnerability_class`** — bulgunun gerçek sınıfı, açıkça
   etiketlenir: `SSRF` / `OPEN_REDIRECT` (yanlışlıkla SSRF sanılmaması
   için, bkz. §3.1) / `XXE_SSRF_CHAIN` (XXE üzerinden dolaylı, bkz.
   §3.3) / `SSRF_AUTHORIZATION_BYPASS` (kasıtlı bir ağ aracının
   yetkisiz erişime açık olması, bkz. §6.1) / `PROTOCOL_SMUGGLING`
   (gopher/dict üzerinden internal servis manipülasyonu, bkz. §12.3)
   / `INFRASTRUCTURE_MEDIATED_SSRF` (reverse-proxy/gateway routing
   istismarı, application-level bir sink DEĞİL, bkz. §12.16) /
   `UNKNOWN`. **`file://` sonucu için özel not:** `file://` ile elde
   edilen bir dosya okuma, tek eksenli `SSRF` etiketi yerine iki
   eksenli raporlanmalıdır — `delivery: file` (§12.2, taşıma
   mekanizması SSRF'in genel modeliyle aynıdır) + `impact_class:
   local-file-read` (nihai etki, ağ üzerinden bir hedefe erişim değil,
   dosya sistemi okumasıdır) — bu, "SSRF" teriminin network-request
   çağrışımıyla tam örtüşmeyen bu sonucu daha doğru tanımlar.
2. **Hedef:** URL/route, HTTP method, etkilenen parametre/alan.
3. **SSRF türü ve confidence seviyesi** — **SSRF classification** ve
   **target classification** §8.4'teki tanıma göre **ayrı ayrı**
   raporlanır:
   - SSRF (causality) "confirmed" mi: Eksen 1'den **tek bir kanıt
     türü** (full/reflected / OOB / semi-blind-differential /
     stored-indirect) **yeterlidir** — DNS-only OOB için §8.4'teki
     koşullu kural geçerlidir.
   - Target (attribution) "confirmed" mi: en az bir Strong indicator
     + tutarlı behavior — SSRF classification'ından bağımsız bir alan.
   - Full mu Blind mi Semi-blind mi — bu ayrım (§1.4) rapor
     seviyesinde de zorunlu olarak belirtilmelidir çünkü impact
     kanıtlama yöntemini doğrudan etkiler.
   - **`network_capability`** — blind/semi-blind bulgular için ayrıca
     belirtilir: `dns-only` (yalnızca DNS çözümlemesi gözlemlendi,
     P2a/P3 koşullu) / `tcp-connect` (bağlantı kuruldu ama protokol
     tamamlanmadı) / `full-protocol` (P4 tamamlandı, HTTP/protokol
     etkileşimi doğrulandı). Bu alan, "DNS-only SSRF" gibi daha zayıf
     bir bulgunun "full SSRF" ile aynı güvenle raporlanmasını önler
     — ikisi de `confirmed` olabilir (DNS-only, §8.4'teki koşullar
     sağlanırsa) ama `network_capability` farkı okuyucuya gerçek
     kapsamı netleştirir.
   - confidence_score (§10.5) yalnızca destekleyici bilgidir.
4. **Detection payload'ı** — tam request/response ve interactsh log
   kaydı (varsa).
5. **Confirmation kanıtı** — "confirmed" için gereken tek Eksen-1
   kanıtının kendisi ve onun §5.1'e göre kurulmuş negatif kontrolü.
6. **Beklenen vs gerçekleşen sonuç** — net karşılaştırma.
7. **False-positive olmadığının kanıtı** — negatif kontrol, ve
   gerekiyorsa Open Redirect/XXE ayrımının gösterimi.
8. **Impact assessment gerekçesi** — §10.4'teki dört eksen: hedefin
   niteliği, elde edilen bilginin hassasiyeti, protokol smuggling ile
   ikincil etki var mı, yetkilendirme/allowlist context'i.
9. **Reproduction adımları** — başka birinin aynı sonucu tekrar
   üretebilmesi için yeterli detay.

**Rapora eklenmemesi gerekenler:** Zafiyeti kanıtlama amacı taşımayan,
elde edilebilecek credential'larla yapılabilecek zararlı aksiyonların
ayrıntılı bir listesi; zafiyetle doğrudan ilgisi olmayan hedef sistem
iç bilgileri.

### 14.2 Payload Metadata Şeması

Yeni bir payload eklerken, şu alanları takip et:

| Alan | Açıklama |
|---|---|
| protocol | Hangi protokol/şema (http/https/file/gopher/dict/ftp/ldap/jar/netdoc veya "generic") |
| target_environment | Hangi ortam (AWS/GCP/Azure/Alibaba/Oracle/DigitalOcean/Kubernetes/internal-generic) |
| syntax | Tam payload metni |
| context | full-url/hostname-only/path-fragment/header-value/xml-entity/config-value |
| purpose | detection / fingerprinting / confirmation / impact |
| expected_result | Beklenen çıktı (ham/raw temsil) |
| alternatives | Eşdeğer alternatif syntax'lar (IP encoding varyantları vb.) |
| behavior_dependency | default / configuration-dependent / version-dependent / application-specific |
| evidence_category | full-reflected / OOB / semi-blind-differential / stored-indirect / target-fingerprint |
| fp_risk | Yanlış pozitif riski: düşük / orta / yüksek |
| kaynak | Bu payload'ın kökeni |
| payload_stage *(yeni eklenen payload'lar için zorunlu)* | §1.5 Payload Stage Model'e göre: P0-input-acceptance / P1-parsing / P2a-dns-resolution / P2b-tcp-connection-attempt / P3-confirmed-contact / P4-protocol-negotiation / P5-response-capture / P6-impact |
| prerequisites *(yeni eklenen payload'lar için zorunlu)* | Bu payload'ın çalışması için gerekli önkoşullar (örn. `redirect_following=true`, `imds_version=v1`, `gopher_scheme_supported=true`) |
| side_effect_level *(yeni eklenen payload'lar için zorunlu)* | none / read-only / external-interaction (OOB) / state-changing (örn. Redis'e yazma) |

**Geriye dönük etiketleme yapılmıyor** — bu üç alan yalnızca
**bundan sonra eklenecek** içerik için zorunludur.

## 15. Referans Araçlar ve Kaynaklar

**Araçlar:**
- **interactsh-client** (bkz. §9.3) — OOB testleri için birincil ve
  bu skill'in merkezi bağımlılığı; blind SSRF confirmation'ının büyük
  çoğunluğu bu araca dayanır.
- **Gopherus** (`tarunkant/Gopherus`) — gopher protokol smuggling
  payload'larını (Redis, Memcached, SMTP, MySQL, FastCGI için) doğru
  RESP/binary encoding ile otomatik üreten bir araç; §12.3'teki elle
  hazırlanan payload'ların encoding hatasına açık olması nedeniyle
  gerçek testte bu aracın kullanılması önerilir.
- **remote-method-guesser** — Java RMI hedeflerine karşı gopher
  payload'ı hazırlamak/kullanmak için (Gopherus'un Java RMI'a özgü
  bir tamamlayıcısı); Java-tabanlı bir hedefte RMI servisi tespit
  edilirse kullanılır.
- **SSRFmap** — bilinen SSRF payload ailelerini (cloud metadata,
  protokol şemaları, IP encoding varyantları) otomatik deneyen bir
  tarama aracı; bu skill'in §5/§8'deki manuel/sinyal-güdümlü
  metodolojisinin yerine değil, tamamlayıcısı olarak düşünülmelidir —
  otomatik tarama negatif dönse bile bu skill'deki context-detection
  ve bypass metodolojisi elle uygulanmalıdır.
- **ipfuscator** (`dwisiswant0/ipfuscator`) — §8.2.2'deki IP encoding
  varyantlarının (decimal/octal/hex/karışık taban) tamamını bir IPv4
  adresinden otomatik üreten bir araç; elle üretmek yerine bu skill'in
  §8.2.1 sıralı deneme stratejisiyle birlikte kullanılabilir.
- **r3dir** (`Horlad/r3dir`) — §8.2.4'teki redirect-tabanlı bypass
  için kendi sunucunu barındırmadan seamless redirect-hedef fuzzing
  sağlayan bir redirection servisi; Burp'e Hackvertor tag'leriyle
  entegre edilebilir.
- **Singularity of Origin** — DNS rebinding saldırıları için özelleşmiş
  bir framework/araç (bkz. §3.5); `1u.ms` gibi hazır bir servis
  yeterli olmadığında (özel TTL/IP çifti senaryoları gerektiğinde)
  kullanılır.
- **OOB yakalama alternatifleri (interactsh dışında, denklik amaçlı
  listelenmiştir — bu skill interactsh'i birincil araç olarak
  benimser, §9.3):** Burp Collaborator (Burp Suite'e entegre),
  `canarytokens.org`, `ssrf-sheriff` (`teknogeek/ssrf-sheriff`),
  `webhook.site`, `pingb.in`.

**Bilgi kaynakları (araç değil, referans dokümantasyon):**
- **PortSwigger Web Security Academy — "Server-side request forgery
  (SSRF)"** — SSRF'nin temel taksonomisi (full/blind), cloud metadata
  istismarı ve yaygın bypass tekniklerine dair birincil eğitim
  kaynağı.
- **PayloadsAllTheThings** (`swisskyrepo/PayloadsAllTheThings`) —
  "Server Side Request Forgery" bölümü; cloud provider'a özgü
  metadata endpoint listeleri, IP encoding varyantları ve redirect
  status code (307/308) notları için geniş bir referans.
- **HackTricks** — "SSRF (Server Side Request Forgery)" ve
  "URL Format Bypass" alt sayfaları; protokol şeması istismarı, curl
  URL globbing, ve anormal redirect status code zinciri gibi ileri
  seviye teknikler için güncel tutulan bir kaynak, düzenli olarak
  tekrar kontrol edilmelidir.
- **Orange Tsai — "A New Era of SSRF: Exploiting URL Parser in
  Trending Programming Languages"** (Black Hat araştırması) — §8.2.3'teki
  parser confusion payload'larının birincil kaynağı; farklı dillerin
  URL parser'larının RFC 3986 yorumlama farklarını sistematik olarak
  belgeler.
- **Cloud provider resmi dokümantasyonu** (AWS IMDSv2 geçiş rehberi,
  GCP metadata server güvenlik notları, Azure IMDS dokümantasyonu) —
  her provider'ın kendi SSRF-koruma mekanizmasının (token/header
  zorunluluğu) güncel davranışını doğrulamak için birincil kaynaktır.
- **Not — bu dosyada bilinçli olarak yapılmayan bir şey:** Bu skill
  dosyası, hiçbir yerde spesifik bir CVE/GHSA kimliği veya kesin
  sürüm numarası hard-code etmez — davranış (ör. "IMDSv2 zorunlu
  ortamlarda token adımı gerekir") anlatılır ve şüpheli/yüksek etkili
  bir iddiayla karşılaşıldığında güncel kaynaktan **testte ampirik
  olarak** doğrulanması önerilir.
- **`verify_before_use` prensibi — özellikle bölgesel/az yaygın cloud
  provider profilleri için (§12.10-§12.15):** Bu skill'deki Hetzner,
  Linode/Akamai, Vultr, Scaleway, OpenStack gibi daha az global
  hedefte karşılaşılan provider profilleri, yazım anında doğrulanmış
  resmi dokümantasyona dayanır — ama bu tür sağlayıcıların
  API'leri/endpoint yolları AWS/GCP/Azure'a göre **daha sık ve daha az
  duyurulu** şekilde değişebilir. Bu profillerden biri kullanılmadan
  önce (özellikle bir payload art arda birkaç denemede de negatif
  dönüyorsa), agent'ın o provider'ın **o anki** resmi dokümantasyonunu
  hızlıca teyit etmesi (bir web araması ile) önerilir — bu, ekstra bir
  "izin" adımı değil, request bütçesini (§10.6) yanlış/eskimiş bir
  path'e harcamamak için bir verimlilik adımıdır.
