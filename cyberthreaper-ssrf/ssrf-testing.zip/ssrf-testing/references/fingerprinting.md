# Hedef/Protokol Fingerprinting — Confidence Seviyeli Sinyal Modeli (§7)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 7. Hedef/Protokol Fingerprinting — Confidence Seviyeli Sinyal Modeli

Generic detection **pozitif** çıktıktan sonra "hangi ağ/hedef/cloud
provider?" sorusuna cevap arayan aşama.

### Bu Bir "Kesin Karar Ağacı" Değildir

Her gözlem bir **confidence seviyesiyle** etiketlenmelidir:
- **Strong indicator** — hedefe özgü, taklit edilmesi zor bir sinyal
  (örn. AWS IMDS'e özgü `X-aws-ec2-metadata-token` header
  gereksinimi — bkz. §12.2).
- **Medium indicator** — birden fazla ortamda görülebilir ama belirli
  bir hedefi güçlü şekilde destekler (örn. `169.254.169.254` üzerinde
  bir cevap alınması — AWS/GCP/Azure/Alibaba/Oracle hepsi bu IP'yi
  kullanır, hangi provider olduğu response formatından anlaşılır).
- **Weak indicator** — tek başına düşük ayırt edicilik (örn. yalnızca
  bir timing farkı).
- **Negative indicator** — bir davranışın **olmaması** da bilgi verir
  (örn. `169.254.169.254`'e erişim tamamen bloklanmışsa, bu SSRF'i
  elemez, yalnızca hedefin cloud metadata'yı network seviyesinde
  filtrelediğini gösterir — bkz. §8.2 bypass).

### Sinyal Toplama Sırası (Rehber, Kesin Akış Değil)

```
http://169.254.169.254/ → cevap var mı?
 ├─ Evet, AWS formatına benzer JSON/plain-text dönüyor →
 │    AWS IMDS güçlü olasılık → §12.2
 ├─ Evet, "Metadata-Flavor: Google" header'ı isteniyor →
 │    GCP metadata server → §12.3
 ├─ Evet, Azure'a özgü "Metadata: true" header gereksinimi →
 │    Azure IMDS → §12.4
 ├─ Cevap yok/timeout → cloud metadata muhtemelen filtrelenmiş VEYA
 │    hedef bulut ortamında değil VEYA farklı bir IP kullanıyor
 │    (Alibaba/Oracle/DigitalOcean farklı bir IP/port kullanabilir,
 │    bkz. §12.5-§12.7) → alternatif provider IP'lerini dene
 └─ Kesinlikle erişim yok (network seviyesinde bloklanmış) →
      internal network taramasına odaklan (§9.4), cloud metadata
      hipotezini "ruled-out" olarak işaretle
```

### Hipotez Takibi — Fingerprint Bir Ranking'dir

```
target_hypotheses:
  - AWS IMDS:        leading    (169.254.169.254 cevap veriyor + JSON formatı AWS'e benziyor)
  - internal-service: candidate (localhost:8080'de bir servis cevap veriyor, henüz tanımlanmadı)
  - GCP metadata:     ruled-out (Metadata-Flavor header'ı olmadan istek reddedildi, GCP değil)
```

### Ek Sinyaller

- **DNS çözümleme davranışı (Medium indicator):** İç ağa özgü bir
  hostname formatının (örn. `*.internal`, `*.local`, `*.svc.cluster.
  local` — Kubernetes'e özgü) çözümlenip çözümlenmediği, hedefin
  container-orchestration ortamında olup olmadığına dair bir sinyaldir.
- **Response timing profili (Weak-Medium indicator):** Internal
  network'teki gerçek bir servise bağlanma (hızlı RST veya hızlı
  response) ile filtrelenmiş/DROP edilen bir bağlantı (timeout'a kadar
  bekleme) arasındaki timing farkı, bir port/host'un **var olup
  olmadığını** (canlı mı, kapalı mı, filtrelenmiş mi) ayırt etmede
  kullanılabilir — bu, sınırlı ve bounded bir "port tarama" tekniğidir
  (bkz. §9.4).
- **HTTP response header fingerprint (Strong-Medium indicator):**
  Hedeften dönen (full SSRF'te görülebilen) `Server:` header'ı,
  hata sayfası formatı — internal servisin ne olduğunu (nginx, bir
  admin panel, bir veritabanı yönetim arayüzü) doğrudan gösterebilir.
- **Cloud provider IP aralığı (Medium indicator):** Hedef domain'in
  çözümlendiği IP aralığı (AWS/GCP/Azure'un yayınladığı public IP
  range listeleri) hangi cloud'da barındırıldığına dair bir ön
  sinyal verir — bu, henüz hiçbir SSRF payload'ı denenmeden, yalnızca
  recon aşamasında toplanabilecek bir **ön-hipotez**dir.

### Negative Capability Matrix — Beklenen "Çalışmama" Davranışı

| Ortam | Beklenen NEGATİF (bu ortamda normaldir, "SSRF yok" anlamına gelmez) |
|---|---|
| IMDSv2 zorunlu AWS ortamı | Token'sız (IMDSv1 tarzı) doğrudan `GET http://169.254.169.254/...` isteği **reddedilir** — bu AWS'i elemez, yalnızca IMDSv2'nin zorunlu olduğunu gösterir; PUT ile token alma adımı gerekir (bkz. §12.2) |
| Container/Kubernetes ortamı, pod-level metadata erişimi kısıtlı | `169.254.169.254` erişimi bir NetworkPolicy/IMDS-proxy ile bloklanmış olabilir — bu, hedefin container-orchestration farkındalığı olduğunu gösterir, internal servis taramasına yönel |
| Modern HTTP client kütüphaneleri (bazı diller/sürümler) | `file://`, `gopher://` gibi şemalar bazı modern HTTP client'larda **varsayılan olarak devre dışıdır** — bu protokolü elemez, yalnızca o dilin/kütüphanenin hangi şemaları desteklediğine dair bir bilgidir (bkz. §12.1) |
| Zaten allowlist uygulayan bir SSRF-koruması | Yalnızca belirli bir domain listesine izin veriliyor olabilir — negatif sonuç, korumanın **var olduğunu** gösterir, bypass denemeleri §8.2'ye geçilmelidir |

**Kullanım kuralı:** Bir negatif sonuç gördüğünde önce bu tabloya bak
— "bu ortamda zaten beklenen bir negatif mi" sorusunu sormadan
"SSRF yok" sonucuna varma.

**Genelleştirilmiş çerçeve — her P0-P6 aşamasındaki bir negatif için
üç soru:** Yukarıdaki tablo ve aşağıdaki egress-fingerprinting
matrisi, aslında tek bir disipline dayanır — pipeline'ın **herhangi
bir aşamasında** bir negatif/blok sinyali görüldüğünde, üç soruyu
ayrı ayrı yanıtla:
1. **Bu ne kanıtlıyor?** (örn. "P2b başarısız" → bu aşamaya kadar
   olan her şeyin, DNS'in çalıştığını kanıtlıyor)
2. **Bu ne kanıtlamıyor?** (örn. "P2b başarısız" → bunun "SSRF yok"
   anlamına geldiğini kanıtlamıyor, yalnızca bu spesifik protokol/
   port/temsil için bir engel olduğunu gösteriyor)
3. **Sıradaki adım ne olmalı?** (örn. "P2b başarısız" → §8.2'deki
   bypass taksonomisine geç, veya farklı bir protokol/port dene)
Bu üçlüyü her aşamada uygulamak, "timeout gördüm = hiçbir şey olmadı"
veya "403 gördüm = SSRF yok" gibi hatalı kısa yolları önler.

### Egress Policy Fingerprinting — Aşama Bazlı Başarı/Başarısızlık Matrisi

Bir hedefin **hangi aşamada** engellemeye başladığı (DNS mi, TCP mi,
uygulama mı, redirect mi), yalnızca "SSRF var/yok" değil, hedefin
**ne tür bir egress kontrolü** uyguladığına dair zengin bir fingerprint
sinyalidir. Her aday için §1.5'teki P0-P6 aşamalarını sırayla
gözlemleyip aşağıdaki gibi bir matris çıkar:

| Örnek 1 — DNS-seviyesi filtre | Sonuç |
|---|---|
| P2a (DNS resolution) | başarılı |
| P2b (TCP connection) | başarısız (timeout/refused) |
| P4 (HTTP) | yok |
| Redirect revalidation | yok (test edilmedi) |
| **Yorum** | DNS çözümleniyor ama bağlantı network seviyesinde (egress firewall/security-group) engelleniyor — bypass hedefi TCP/network katmanı, URL-encoding değil |

| Örnek 2 — Uygulama-seviyesi filtre | Sonuç |
|---|---|
| P2a (DNS resolution) | başarılı |
| P2b (TCP connection) | başarılı |
| P4 (HTTP) | 403 (uygulama reddetti) |
| Redirect revalidation | yok (test edilmedi) |
| **Yorum** | Bağlantı kuruluyor ama uygulamanın kendisi (bir SSRF-koruma middleware'i) isteği reddediyor — bypass hedefi §8.2'deki encoding/parser teknikleri, network katmanı değil |

| Örnek 3 — Redirect-seviyesi filtre | Sonuç |
|---|---|
| P2a-P4 (ilk hedefe, allowlist'teki domain'e) | tamamı başarılı |
| Redirect (allowlist domain → internal IP) | reddedildi/farklı davranış |
| **Yorum** | validate-every-hop modeli aktif (bkz. §8.2.4) — B10 klasik redirect bypass'ı burada işe yaramaz, DNS/parser seviyesi tekniklere yönel |

**Kullanım kuralı:** Bu üç örnek şablon değildir, bir **gözlem
kaydetme disiplinidir** — her aday için hangi aşamada durduğunu not
etmek, hem o anki hedef için doğru bypass kategorisini seçmeyi hem de
aynı ortamdaki başka adaylar için zaman kazandırmayı sağlar (aynı
ortamda benzer bir egress modeli tekrar karşılaşılması muhtemeldir).

### Scheme Support Fingerprinting → Sink Capability Matrix (State Takibi)

**Düzeltme — "parse ediliyor" ile "gerçekten bağlanılabiliyor" aynı
şey değildir.** §12'deki protokol profillerini (http/https/file/
gopher/dict/ftp/ldap/ws/wss vb.) her birini tek tek "kör" denemek
yerine, bir hedefte hangi şemaların **kabul edildiğini** erken bir
taramada not etmek faydalıdır — ama bunu tek boyutlu (yes/no) değil,
**üç ayrı aşama** olarak kaydetmek gerekir, çünkü bir şemanın
"kabul edilmesi" (parse hatası vermemesi) onun gerçekten ağ
seviyesinde kullanılabildiğinin kanıtı değildir:

```
scheme_support:
  http:
    parse: yes       (URL formatı hatasız kabul ediliyor)
    connect: yes     (P2b — gerçek bir TCP bağlantı denemesi gözlemlendi)
    protocol: yes    (P4 — tam HTTP handshake/response alındı)
  gopher:
    parse: yes        (şema reddedilmedi)
    connect: unknown  (henüz bir OOB/timing testiyle doğrulanmadı)
    protocol: unknown
    evidence: none
  file:
    parse: no          (açıkça reddedildi — düşük öncelikli hale getir)
```

Bu üç katmanlı ayrım kritiktir: bir şemanın yalnızca `parse: yes`
olması (URL formatı kabul edildi) **hiçbir şekilde** o şemanın
gerçekten ağ/dosya sistemi seviyesinde kullanılabildiğini kanıtlamaz
— `connect`/`protocol` seviyesinde ayrıca P2b/P3/P4 kanıtı (§1.5,
§9.3) toplanmalıdır. Bir şema `parse: no` olarak işaretlendiğinde,
o şemaya dayanan bypass/impact teknikleri düşük öncelikli hale
getirilir — bu, request bütçesini (§10.6) daha akıllı harcamayı
sağlar, denemeyi tamamen yasaklamaz.

**Genişletilmiş Sink Capability Matrix — yalnızca şemayla sınırlı
değil, sink'in genel kapasitesini sistematik olarak kaydet:** Bir
SSRF sink'i confirmed olduktan sonra (§10.1), "SSRF var mı" sorusundan
"bu sink ne yapabiliyor" sorusuna geçilir — bu, doğrudan impact
assessment'ı (§10.4) besler:

| Kapasite | Unknown/Yes/No | Nasıl test edilir |
|---|---|---|
| `arbitrary_host` | — | Farklı hedef host'lar deneyerek (canary vs internal IP) |
| `arbitrary_port` | — | §9.4'teki sınırlı port taraması |
| `arbitrary_scheme` | — | Yukarıdaki `scheme_support` tablosu |
| `method_control` | — | Sink'in yalnızca GET mi yoksa saldırganın HTTP metodunu da belirleyebildiği mi (§12.7 IMDSv2 PUT notu bu alana bağlıdır) |
| `header_control` | — | Saldırganın outbound isteğe özel header ekleyip ekleyemediği (örn. GCP'nin `Metadata-Flavor` header'ı gerektirmesi bu alana bağlıdır) |
| `body_control` | — | Saldırganın outbound isteğin body'sini belirleyip belirleyemediği (§12.3 gopher/protokol smuggling bu alana bağlıdır) |
| `redirect_followed` | — | §8.2.4 |
| `redirect_revalidation` | — | §8.2.4/§8.2.6 |
| `dns_resolution_observed` | — | P2a |
| `response_reflected` | — | Full mi blind mi (§1.4) |
| `response_headers_visible` | — | Yalnızca body mi, header'lar da mı görünüyor |
| `timeout_controllable` | — | Saldırganın bir timeout/gecikme süresi belirleyip belirleyemediği |
| `outbound_proxy_used` | — | Bkz. aşağıdaki "Proxy-Aware SSRF" notu, §11 |
| `stored_execution` | — | §9.1 |
| `retry_behavior` | — | Hata durumunda otomatik tekrar deniyor mu (B21 ile ilgili) |

Bu tablo tek seferde doldurulmaz — her satır, ilgili confirmation
adımı (§10) tamamlandıkça güncellenir; `unknown` kalan satırlar
eksik bir test değil, henüz araştırılmamış bir kapasite olarak
işaretlenir.

### Kurallar

- Aynı uygulamada birden fazla outbound isteği tetikleyen mekanizma
  bulunabilir (örn. ana uygulama sunucusu ile arka planda çalışan bir
  worker/queue-consumer farklı ağ konumlarında olabilir) —
  fingerprinting **her endpoint için ayrı** yapılmalı.
- **Raporlama kuralı:** Nihai raporda hedef/provider adı **"confirmed"**
  veya **"olası/probable"** olarak açıkça etiketlenmelidir.
