# Confirmation, Impact Assessment ve SSRF→RCE Zincirleri (§10, §16)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 10. Confirmation, Impact Assessment, Confidence Scoring

### 10.1 Dört Ayrı Katman (Birbirine Karıştırılmamalı)

1. **Detection** → outbound istek atılıyor mu? (§5)
2. **Fingerprinting** → hangi hedef/ağ/cloud? (§7)
3. **Confirmation** → detection sonucunu **bağımsız bir evidence
   kategorisiyle** yeniden doğrulama (§8.3).
4. **Impact Assessment** → zafiyetin yetki dahilinde gerçek etkisi.

### 10.2 Confirmation Önceliği

Önce sistemde **kalıcı değişiklik yapmayan** (side-effect-free)
yöntemler denenir — OOB confirmation (§9.3) doğası gereği zaten
side-effect-free'dir. **Ama dikkat:** side-effect-free ≠ risksiz/
zararsız — cloud metadata'dan okunan bir credential hedefe göre
gerçekten hassas olabilir (bkz. §0.2).

**Differential confirmation:** §5.1'deki üçlü karşılaştırma tekniğini
kullan. **Düzeltme (§8.4 ile tutarlılık):** Bu teknik **yalnızca
origin/application attribution netleştirilmişse** Eksen 1 (causality)
için tek başına "confirmed" SSRF'e yeterlidir — origin attribution
belirsizse (paylaşılan bir proxy/WAF katmanı olasılığı elenmemişse)
"probable" olarak kalır, ikinci bağımsız bir kanalla (OOB veya
full/reflected evidence) desteklenene kadar yükseltilmez. Ayrıntılı
koşul ve gerekçe için §8.4'e bakınız.

### 10.3 Gerçekten Gerekli Olan Sınırlar

§0.2 ile birebir aynı: dosya/veri silme/değiştirme yok, kalıcı sistem
değişikliği yok, reverse shell/kalıcı C2 yok, kasıtlı ağır DoS/tam
port taraması yok, scope dışına sıçrama yok (üçüncü taraf sistemler
taranmaz). Bunların dışında kalan her şey (cloud metadata/credential
okuma, internal servis banner toplama, internal admin paneline
erişimin gösterilmesi) serbesttir.

### 10.4 Impact Assessment Dört Ekseni

1. **Erişilen hedefin niteliği** — yalnızca localhost/kendi
   servisine mi erişildi, yoksa gerçek bir internal network segmentine
   mi, yoksa cloud metadata/credential servisine mi.
2. **Elde edilen bilginin/erişimin hassasiyeti** — bir versiyon
   banner'ı mı, yoksa aktif bir cloud credential'ı mı (credential
   varsa, bu credential'ın **hangi yetkilere** sahip olduğu — bkz.
   §12.2 "credential kapsamı doğrulama" — impact'i büyük ölçüde
   belirler).
3. **Protokol smuggling ile ulaşılan ikincil etki** — gopher/dict
   üzerinden internal bir servise (Redis, Memcached, SMTP) yazma
   kapasitesi varsa, bu SSRF'nin salt "bilgi okuma"nın ötesinde
   **internal sistemi manipüle etme** (örn. Redis'e yazarak RCE'ye
   zincirleme) kapasitesine işaret eder — ayrı ve daha yüksek bir
   impact seviyesi olarak raporlanmalı.
4. **Yetkilendirme/allowlist context'i** (bkz. §6.1) — bulgu, kasıtlı
   bir "ağ aracı" özelliğinin yetkisiz kullanıcılara açık olması mı,
   yoksa hiç beklenmeyen bir sink mi; ikisi de "confirmed SSRF"dir
   ama raporlama çerçevesi (authorization bypass vs. yeni sink) farklı
   olmalıdır.

### 10.5 Confidence Scoring — ÖRNEK/ÖNERİ MODEL

```
SSRF classification    = Eksen 1 kuralı (§8.4)   ← TEK belirleyici
Target classification  = Eksen 2 kuralı (§8.4)   ← AYRI, bağımsız
confidence_score        = aşağıdaki puanlama       ← YALNIZCA öncelik/raporlama,
                                                      classification'ı ASLA belirlemez
```

**KRİTİK DÜZELTME — puan eşiği bir classification kuralı DEĞİLDİR,
bunu asla öyle okuma:** Aşağıdaki puanlama, yalnızca birden fazla
`probable` veya `inconclusive` bulgu arasında **hangisine önce
bakılacağını** sıralamak için bir yardımcıdır. **Zayıf sinyallerin
toplamı asla "confirmed" üretmez** — örneğin `partial differential
(+2)` + `timing (+1)` + başka bir zayıf sinyal toplamı 5'i geçse bile,
bu kombinasyon §8.4'ün evidence-kategorisi kurallarına göre
`confirmed` **DEĞİLDİR** (§8.4'te confirmed için gereken şey belirli
bir evidence **kategorisinin** kendisidir — full/reflected, OOB,
origin-attribution'lı differential, veya stored/indirect — zayıf
sinyallerin puan toplamı değil). Aşağıdaki puan aralıkları yalnızca
**§8.4'ün zaten belirlediği** classification'ın yanında **destekleyici
bir öncelik göstergesi** olarak okunmalıdır, classification'ı
**türetmek için kullanılmaz**:

**Eksen 1 — SSRF (causality), destekleyici puanlama (classification
her zaman §8.4'ten gelir, bu tablodan DEĞİL):**

| Kanıt | Örnek puan (yalnızca öncelik sıralaması için) |
|---|---|
| Semi-blind differential evidence (tek başına, kısmi, origin attribution belirsiz) | +2 (§8.4'e göre bu tek başına HİÇBİR ZAMAN confirmed değildir, kaç zayıf sinyalle toplanırsa toplansın) |
| Semi-blind differential evidence (üçlü karşılaştırmanın tamamı tutarlı + origin attribution netleşmiş) | +4 (§8.4'e göre bu confirmed'dir — puan burada zaten confirmed OLDUKTAN sonra yalnızca bir referans değeridir) |
| Timing evidence | +1 (§8.4'e göre bu ASLA tek başına confirmed değildir) |
| Full/reflected evidence | +5 (§8.4'e göre tek başına confirmed) |
| OOB evidence (yalnızca DNS, koşullar sağlanmamış) | +4 (§8.4'e göre bu koşullar sağlanmadan probable'dır) |
| OOB evidence (DNS + HTTP interaction) | +6 (§8.4'e göre tek başına confirmed) |
| Stored/indirect execution evidence | +5 (§8.4'e göre tek başına confirmed) |

**Kullanım kuralı:** Agent önce §8.4'ün evidence-kategorisi kurallarını
uygulayarak classification'ı belirler (confirmed/probable/
inconclusive/negative); yukarıdaki puanlama yalnızca **aynı
classification tier'ındaki** (örn. birden fazla `probable` bulgu)
adaylar arasında hangisine önce derinlemesine bakılacağını
sıralamak için **isteğe bağlı** olarak kullanılabilir.

**Eksen 2 — Target (attribution), destekleyici puanlama (aynı
prensip, classification §8.4'ten gelir):**

| Kanıt | Örnek puan (yalnızca öncelik sıralaması için) |
|---|---|
| Weak indicator | +1 |
| Medium indicator | +2 |
| Strong indicator | +4 |

### 10.6 Ne Zaman Durulmalı

**Kritik ayrım — "detection durur" ile "test biter" AYNI ŞEY
DEĞİLDİR:** Aşağıdaki kurallar yalnızca **detection/confirmation**
aşamasının (§10.1 adım 1-3) ne zaman durdurulacağını tanımlar.
Detection confirmed olduktan sonra **impact assessment** (§10.1 adım
4, §10.4, §12'deki protokol/cloud-özel derinleştirme, §16'daki
zincirler) **devam eder** — "confirmed" etiketi impact araştırmasının
sonu değil, başlangıcıdır. Örneğin bir SSRF confirmed olduğunda
gereksiz ek **detection** payload'ı (aynı canary'yi farklı formatlarda
tekrar tekrar doğrulamak) durur, ama "bu hangi cloud'da, hangi
credential'a erişiliyor, gopher ile ne kadar derinleşebiliyor"
soruları (§12, §16) **ayrı bir aşamadır ve durmaz** — bu ikisi
karıştırılırsa erken durma false-negative'e yol açar (SSRF bulunur
ama gerçek impact hiç araştırılmadan rapor yazılır).

- Skor "confirmed" eşiğine ulaştığında gereksiz ek **detection**/
  confirmation payload'ı denenmez — bu, impact assessment'ın
  durdurulacağı anlamına gelmez (yukarıdaki ayrıma bakınız).
- Aday başına belirlenen request bütçesi (**bu skill'de sabit bir
  sayı değildir** — burada verilen "15 request" tamamen illüstratif
  bir örnektir; gerçek değer hedefin rate-limit toleransına, WAF
  hassasiyetine ve bulgunun kritikliğine göre agent tarafından o an
  belirlenir, düşük riskli/toleranslı bir hedefte çok daha yüksek
  olabilir) tükendiğinde → "inconclusive" işaretle, sıradaki adaya geç.
- Tek bir 403/401/406 (bir sonraki payload'ı **beklemeden**, §8.2'deki
  kurala göre) → doğrudan bypass denemesine geç (§8.2), bu bir
  "durma" sinyali değildir.
- **Gerçek rate-limiting** sinyali (art arda 3+ istekte HTTP 429,
  veya belirgin bir gecikme/throttling davranışı) → backoff uygula;
  bu, 403/blok sinyalinden **farklı** bir durumdur ve bypass
  denemesini durdurmaz, yalnızca istekler arası bekleme süresini
  artırır.

### 10.7 Paralel/Sıralı Çalışma

- Farklı endpoint'lerdeki generic probe'lar paralel yürütülebilir
  (canary'lerin biricik olması koşuluyla — karışma riski yok).
- Aynı endpoint içindeki fingerprinting/bypass adımları **sıralı**
  olmalı (özellikle port taraması, §9.4 sınırlarına uymak için).

## 16. SSRF → RCE Zincirleri (Impact Yükseltme Referansı)

Bu bölüm, §10.4'teki impact assessment'ı somutlaştırmak için, bu
skill'in daha önce tanımladığı bileşenlerin (§12 protokol profilleri,
§11 modern mimari, §9.1 stored/indirect) **nasıl art arda
zincirlenerek RCE'ye kadar gidebileceğini** özetler — yeni bir teknik
tanımlamaz, mevcut bölümlere çapraz referans verir.

**Derinleşme Triage Gate — KRİTİK, request bütçesini korur:** Bir
SSRF confirmed olduğunda, aşağıdaki zincirlerin **hepsini otomatik
olarak** denemek (gopher→Redis→FastCGI, K8s exec, Envoy config
manipülasyonu vb.) hem gereksiz request bütçesi tüketir hem de
düşük-değerli bir SSRF'i orantısız bir efor gerektiren bir "impact
avcılığına" çevirir. Derinleşmeden önce hızlı bir triage sorusu
sorulmalı — bu bir **eleme** değil, **derinleşme sırasını belirleme**
mekanizmasıdır (aynı §2'deki host/parametre skorlaması mantığı):

```
SSRF confirmed
   ↓
Hedef ne? (scheme_support/Sink Capability Matrix'ten, §7)
   ├─ Yalnızca kendi kontrolündeki canary/dış bir servis
   │  → düşük öncelikli derinleşme; bulguyu full/blind SSRF olarak
   │    raporla, gopher/RCE zincirlerini DENEMEDEN bırakmak makuldür
   │    (yine de scope/zaman izin veriyorsa denenebilir, yasak değil)
   ├─ 169.254.169.254/cloud metadata veya bilinen bir internal servis
   │  (Redis/Elasticsearch/K8s API vb. fingerprint edildi)
   │  → YÜKSEK öncelikli derinleşme; ilgili §12 profili ve/veya
   │    aşağıdaki zincir tablosu uygulanır
   └─ Bilinmiyor/henüz fingerprint edilmedi
      → önce §7 fingerprinting'e geri dön, hedefi belirle, sonra
        bu triage'a geri gel
```

Bu triage, **hiçbir zinciri yasaklamaz** — yalnızca "hangi sırayla,
ne kadar efor harcanacağı" kararını hedefin gözlemlenen değerine
bağlar. Düşük değerli bir hedefte de scope/zaman bolsa zincirler
denenebilir; yüksek değerli bir hedefte bu triage'ı atlayıp
doğrudan derinleşmek her zaman haklıdır.

**KRİTİK ÖNKOŞUL GATE — bu bölüm §10'daki confirmation'ın YERİNE
geçmez:** Aşağıdaki her zincir, **yalnızca** SSRF ve zincirdeki **her
ara kapasite bağımsız olarak confirmed olduktan sonra** bir sonraki
adıma geçilerek uygulanır. "SSRF confirmed" tek başına "zincirdeki
sonraki adım da çalışacak" anlamına **gelmez** — örneğin "Redis'e
gopher ile erişim confirmed" ile "Redis üzerinden RCE confirmed"
arasında **çok sayıda bağımsız koşul** vardır (Redis'in çalıştığı
kullanıcının dosya yazma izni, `CONFIG SET`'in devre dışı bırakılıp
bırakılmadığı, hedef dizinin yazılabilir olup olmadığı, SSH'ın
`authorized_keys` dosyasını nasıl işlediği, vb.). Doğru
sınıflandırma zincirin **her adımını ayrı ayrı** confirmed/
probable/inconclusive olarak işaretlemektir:

```
SSRF confirmed (§10.1)
   ↓
[ara kapasite 1] confirmed/probable/inconclusive — bağımsız kanıt gerekir
   ↓
[ara kapasite 2] confirmed/probable/inconclusive — bağımsız kanıt gerekir
   ↓
...
   ↓
RCE confirmed (yalnızca zincirin TAMAMI ayrı ayrı doğrulanmışsa)
```

| Zincir | Adımlar (her adım AYRI doğrulanmalı, otomatik varsayılmaz) | İlgili Bölümler |
|---|---|---|
| Redis → SSH key yazma → SSH ile RCE | (1) **[confirmed gerekir]** gopher ile Redis'e `CONFIG SET dir /root/.ssh/` — Redis'in `CONFIG` komutuna izin verdiği ayrıca doğrulanmalı (bazı yapılandırmalarda `rename-command`/`protected-mode` ile kapatılmıştır) (2) **[confirmed gerekir]** `CONFIG SET dbfilename authorized_keys` (3) **[confirmed gerekir]** `SET` ile saldırganın public key'ini value olarak yaz (4) **[confirmed gerekir]** `SAVE` ile dosyaya yaz — Redis'in çalıştığı kullanıcının `/root/.ssh/` dizinine yazma izni olup olmadığı ayrı bir koşuldur, genelde Redis root olarak ÇALIŞMAZ, bu adım çoğu gerçek hedefte başarısız olur (5) **[confirmed gerekir]** SSH ile bağlan — bu adımın başarısı yalnızca yukarıdaki TÜM adımların gerçekten çalıştığının kanıtıdır | §12.3 (gopher/Redis payload'ları) |
| FastCGI/PHP-FPM → RCE | **[confirmed gerekir]** gopher ile FastCGI protokolüne saldırganın PHP kodunu içeren bir `SCRIPT_FILENAME`+ham PHP payload'ı gönderme (Gopherus'un FastCGI modülü bu encoding'i otomatik üretir) — hedef path'in gerçekten var olduğu ve PHP-FPM'in bu path'i işlediği ayrı bir önkoşuldur | §12.3 (Gopherus aracı), §15 |
| AWS IMDS → User Data okuma → RCE | (1) **[confirmed]** `iam/security-credentials/` ile credential çal (2) **[confirmed gerekir]** `EC2 DescribeInstanceAttribute --attribute userData` ile (credential'ı kullanarak) instance'ın user-data'sını oku — credential'ın bu spesifik API çağrısına yetkili olduğu ayrı bir koşuldur, IAM policy dar kapsamlıysa bu adım başarısız olur (3) **[probable/inconclusive, hedefe özel]** script içinde hardcode edilmiş bir secret/credential veya zafiyetli bir kurulum adımı varsa bunu istismar et — bu adımın varlığı garanti değildir | §12.7 (AWS IMDS), §10.4 |
| Kubernetes API → Pod exec → RCE | (0) **[AYRI ÖNKOŞUL — SSRF'in doğal sonucu DEĞİLDİR]** service account token'ı elde etmek genelde bir **dosya okuma** vektörü gerektirir (`/var/run/secrets/kubernetes.io/serviceaccount/token`) — SSRF tek başına bu dosyayı okuyamaz, bu adım yalnızca SSRF'in **başka bir zafiyetle** (örn. §12.2'deki `file://` okuma, veya ayrı bir LFI) zincirlendiği durumlarda mümkündür; token elde edilmeden bu zincirin geri kalanı **hiç başlamaz** (1) **[confirmed gerekir, adım 0 sağlanmışsa]** K8s API'nin `pods/exec` subresource'una token ile istek atarak bir pod içinde komut çalıştır — kimlik doğrulanmış kullanıcının bu yetkiye sahip olması (RBAC) **ayrı ve genelde kısıtlı** bir koşuldur, çoğu service account'ta bu yetki yoktur | §11 (Kubernetes API server), §12.13, §12.2 (file:// önkoşulu) |
| Service mesh Envoy admin → config manipülasyonu | (1) **[confirmed]** `/config_dump` ile mesh topolojisini çıkar (2) **[probable/inconclusive, hedefe özel]** admin API'nin config-değiştirme endpoint'lerine yazma izni varsa trafiği kendi kontrolündeki bir servise yönlendir — birçok gerçek dünya kurulumunda admin API salt-okunur/read-only olarak açıktır, yazma her zaman mümkün değildir | §11 (Envoy admin API path'leri) |
| Reverse proxy absolute-URI/SNI istismarı → internal admin panel'e tam erişim | §12.16'daki misconfigürasyonla proxy'yi forward-proxy'ye çevir (confirmed gerekir), ardından internal admin panellerini (Keycloak, SOAP/Axis2 vb.) doğrudan hedefle | §12.16 |

**Kullanım notu:** Bu tablo bir **checklist değil, bir impact-mantığı
referansıdır** — her satırdaki adımların her biri hedefe özel
koşullara (versiyon, yapılandırma, yetki) bağlıdır; agent bir SSRF
confirmed olduktan sonra (§10.1-§10.2) bu tabloyu tarayarak "bu
spesifik hedefte hangi zincir mantıklı bir sonraki adım olabilir"
sorusunu sorar, tüm zincirleri körlemesine denemez, ve **hiçbir ara
adımı bir öncekinin başarısından otomatik olarak çıkarsamaz.**
