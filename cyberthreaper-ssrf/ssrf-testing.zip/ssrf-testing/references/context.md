# Context Detection (§6)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 6. Context Detection

### Context Türleri

- **Full-URL context** — parametre tam bir URL bekliyor (`https://
  example.com/path?query`), en esnek ve en yaygın context.
- **Hostname-only context** — yalnızca host/domain kabul ediliyor,
  şema/path uygulama tarafından sabit ekleniyor.
- **Path-fragment context** — yalnızca path kısmı kontrol ediliyor,
  host sabit (bu context'te klasik SSRF genelde mümkün değildir, ama
  path traversal ile birlikte kullanılan bir base-URL manipülasyonu
  mümkün olabilir — bkz. §8.2 URL parser confusion).
- **Header-value context** — `X-Forwarded-Host`, `X-Forwarded-For`,
  `Referer` gibi bir HTTP header'ın değeri, bazı reverse-proxy/
  yönlendirme mantıklarında bir outbound isteğin hedefini
  etkileyebilir.
- **XML-entity context** — bkz. §3.3, XXE üzerinden dolaylı.
- **Config/manifest-value context** — bir YAML/JSON config değeri
  (webhook kaydı, data source tanımı — bkz. §9.1 stored/indirect).
- **Multipart/file-upload context** — bir dosyanın **içeriğinde**
  gömülü bir URL referansı (örn. bir SVG dosyasının içindeki
  `<image href="...">`, bir DOCX/PDF içindeki harici referans —
  bu genelde XXE/SSRF overlap'inin somut bir örneğidir).

### Context Tespit Prosedürü

**Temel soru (format tespitinden ÖNCE sorulmalı):** "Uygulama bu
input'u outbound isteğin **hangi bileşenine** yerleştiriyor?" —
yalnızca "hangi format kabul edildi" sorusu yeterli değildir, çünkü
aynı format kabulü çok farklı bir yerleştirme deseninin sonucu
olabilir. Örnek desenler:
```
input = "example.com"          → sabit "https://" + input (hostname-only)
input = "foo"                  → sabit "https://api.example.com/" + input (path-only, base sabit)
input = "example.com/path"     → doğrudan internal HTTP client'a geçiyor (tam URL)
input = "https://x.com"        → bir config/YAML alanına yazılıp SONRADAN başka bir
                                   süreç tarafından okunup istek atılıyor (stored/indirect, §9.1)
```
Bu farkı ayırt etmeden yalnızca "hangi format hata vermedi" bilgisiyle
ilerlemek, yanlış bir canary formatı seçilmesine (örn. gerçekte
path-only context'te tam URL denemeye devam etmek) ve gereksiz yere
başarısız probe'larla request bütçesini tüketmeye yol açar.

**Pratik prosedür:**
1. Önce **tam bir URL** gönder, kabul ediliyor mu gözlemle.
2. Hata dönüyorsa yalnızca hostname gönder, ardından yalnızca path.
3. Hangi formatın "geçerli" kabul edildiğini (hata vermeyen) tespit
   ettikten sonra, yukarıdaki temel soruyu tekrar sor: kabul edilen
   bu format, gerçekten **doğrudan** bir outbound isteğin parçası mı
   oluyor, yoksa bir **ara adımdan** (config kaydı, başka bir alana
   birleştirme, stored bir alan) mı geçiyor? Yanıt belirsizse, bir
   canary göndererek P2a/P2b (§1.5) ile doğrudan doğrulama tercih
   edilir — yalnızca "format kabul edildi" gözlemine güvenilmez.
4. Canary probe'ları bu tespit edilen desene göre otomatik zenginleştir.

### 6.1 Yetki/İzin Context'i — "Bu Zaten Meşru Bir Özellik mi?"

Bazı endpoint'ler **kasıtlı olarak** sunucu tarafında dışa istek
atma özelliği sunar (§2'deki "ağ aracı" kategorisi — ping/traceroute/
webhook test aracı gibi). Bu durumda asıl soru "SSRF var mı" değil,
**"bu özellik yetkisiz/düşük ayrıcalıklı kullanıcılara açık mı, ve
hedef kısıtlaması (yalnızca dış IP'lere izin, internal IP'lere izin
yok) doğru uygulanıyor mu"** sorusudur — bu, SSRF'nin **authorization/
allowlist bypass** alt türüdür ve confirmation prosedürü aynıdır
(§9), yalnızca raporlama çerçevesi farklıdır (bkz. §10.4).
