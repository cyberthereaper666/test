# Stored / Indirect / Blind SSRF (§9)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 9. Stored / Indirect / Blind SSRF

### 9.1 Stored/Indirect Zincir Haritalama

1. Payload'ı (canary URL) biricik bir marker ile olası "kaynak" alana
   gönder (webhook kaydı, data source tanımı, "profil resmi URL'i"
   gibi bir kayıt).
2. Uygulamanın bu URL'i **ne zaman/nerede** çağırabileceğini
   haritalandır: bir sonraki webhook tetiklenme döngüsü, bir
   zamanlanmış senkronizasyon job'u, admin panelinde "önizleme" işlevi,
   bir başka kullanıcının işlemi tetiklediği bir bildirim akışı.
3. Her olası tetikleme noktasını (mümkünse) tetikle veya bekle.
4. Zincir 2+ adımdan oluşuyorsa her adımı ayrı doğrula.

**Gerçek dünya deseni — webhook zinciri:** Bir kullanıcı kendi
"webhook URL'ini" kaydeder (örn. bir CI/CD entegrasyonu, bir
bildirim servisi); uygulama bu URL'e **başka bir olay** (örn. bir
build tamamlandığında, bir sipariş oluştuğunda) gerçekleştiğinde
istek atar — saldırgan kendi isteğinde hiçbir zaman doğrudan cevap
göremeyebilir, etkiyi yalnızca OOB ile gözlemleyebilir.

**Gerçek dünya deseni — "veri kaynağı" senkronizasyonu:** Bir
dashboard/monitoring aracında kayıtlı bir "data source URL'i", periyodik
bir arka plan job'u tarafından **düzenli aralıklarla** çağrılır — bu,
tek seferlik bir SSRF'den farklı olarak **tekrarlayan** bir OOB sinyali
üretir, bu da confirmation'ı kolaylaştırır (interactsh log'u zamanla
birden fazla kayıt gösterir).

**Stored/indirect evidence için ek kayıt alanları — "kim/nerede tetikledi"
sorusu (özellikle çok kiracılı/multi-tenant SaaS'ta kritik bir impact
belirleyicisi):** §9.1'deki zinciri doğrularken, yalnızca "OOB geldi
mi" değil, mümkünse şu bağlamı da not et — çünkü aynı stored SSRF'in
etkisi, isteği **hangi bileşenin, hangi kimlikle, hangi ağdan**
attığına göre büyük ölçüde değişir:

| Alan | Açıklama | Neden önemli |
|---|---|---|
| `stored_by` | Payload'ı kim kaydetti (saldırganın kendi hesabı mı, farklı bir yetki seviyesindeki bir kullanıcı mı) | Yetki sınırı aşımı olup olmadığını gösterir |
| `triggered_by` | Tetikleyen olay kimin eylemiyle oldu (saldırganın kendisi mi, başka bir kullanıcı/admin mi, zamanlanmış bir job mı) | Cross-tenant/cross-user etkiyi netleştirir |
| `executing_component` | İsteği fiilen atan bileşen: frontend / application-server / worker / queue-consumer / cron / proxy / gateway / renderer / external-service / unknown | Aynı URL'in farklı bileşenlerde farklı ağ erişimine sahip olabileceğini yakalar (bkz. aşağıdaki not) |
| `execution_network` | İsteğin çıktığı ağ konumu (biliniyorsa) — ana uygulama VPC'si mi, ayrı bir worker VPC'si mi, admin-only bir ayrıcalıklı ağ mı | İmpact assessment'ta (§10.4) "hangi network segmentine erişildiği" sorusunu doğrudan besler |
| `execution_time` | Tetiklemenin ne zaman gerçekleştiği (anlık mı, dakikalar/saatler sonra mı) | Blind confirmation'da OOB log'unu doğru zaman aralığında aramak için gerekli |

**Neden `executing_component` önemli — somut örnek:** Bir frontend
sunucusunun outbound isteği genel internete çıkabilirken, aynı URL'i
işleyen bir arka plan worker'ı **ayrı, daha ayrıcalıklı bir VPC'de**
çalışıyor olabilir (örn. bir "rapor üretim worker'ı" internal
veritabanı ağına erişebilirken, web-facing sunucu erişemez) — bu
durumda stored SSRF'in gerçek etkisi, saldırganın **doğrudan test
ettiği** komponentten değil, **payload'ı gerçekte çalıştıran**
komponentten belirlenir. Bu alan bilinmiyorsa `unknown` olarak
bırakılır — bu da geçerli bir sonuçtur, ama impact assessment'ta
"execution component doğrulanamadı, gerçek etki bilinenden daha
yüksek olabilir" notu düşülmelidir.

### 9.2 Renderer/Döküman-Aracılı Dolaylı SSRF (ve Gerçek XXE Overlap'i Ayrımı)

Bir dosya yükleme özelliğinde, dosyanın **içeriğinde** gömülü bir URL
referansı barındırması ve bu dosyanın sunucu tarafında **işlenirken**
o referansı çekmesi — bu, tek bir mekanizma değil, **kök nedeni
tamamen farklı olan iki ayrı senaryoyu** kapsar; bunları
karıştırmamak, hangi metodolojinin (bu skill mi, ayrı bir XXE skill'i
mi) uygulanacağını doğru belirlemek için kritiktir:

**(A) Renderer-aracılı doğrudan SSRF — XML DTD/entity işleme
GEREKTİRMEZ, bu skill'in doğrudan kapsamındadır:** Birçok format
(SVG, HTML, bazı DOCX/PDF üretim zincirleri) **tasarım gereği** harici
kaynaklara referans verebilir ve bu referanslar bir renderer/
görüntüleyici tarafından **normal, DTD-dışı bir mekanizmayla**
(görüntü/stylesheet/font yükleme) çekilir:
```xml
<!-- SVG içinde harici resim referansı — bu DTD/ENTITY DEĞİL,
     SVG'nin kendi <image> elemanının normal href çözümlemesidir -->
<svg xmlns="http://www.w3.org/2000/svg">
  <image href="http://<canary>.oast.fun/x.png" />
</svg>
```
Bu senaryoda sink, bir XML **parser'ının DTD/entity işleme
mekanizması değil**, SVG/HTML **renderer'ının** kendi kaynak-yükleme
davranışıdır — detection ve confirmation doğrudan bu skill'in
standart akışıyla (§5, §9.3) yapılır, **XXE skill'ine devretmeye
gerek yoktur**. Aynı kategori: `<use href="...">`, harici
stylesheet/font referansları, DOCX/PDF üretim zincirlerinde işlenen
harici resim/şablon referansları.

**(B) Gerçek XXE-aracılı SSRF — XML DTD/ENTITY işleme GEREKTİRİR, ayrı
skill'e devir noktası (bkz. §3.3):**
```xml
<!DOCTYPE foo [ <!ENTITY xxe SYSTEM "http://<canary>.oast.fun/"> ]>
<root>&xxe;</root>
```
Burada sink gerçekten bir XML parser'ın **DTD/ENTITY çözümleme**
mekanizmasıdır — kök neden, DOCTYPE tanımına external entity
enjekte edilebilmesidir, SVG/HTML'in "normal" kaynak yüklemesiyle
**alakası yoktur**. Bu senaryoda önce XXE skill'inin detection/
confirmation metodolojisi (DTD işleme, `disallow-doctype-decl` gibi
parser bayrakları) uygulanmalı, XXE confirmed olduktan **sonra**
elde edilen "harici istek attırma" kapasitesi bu skill'deki §12 ile
birleştirilmelidir (bkz. §3.3).

**Pratik ayrım testi:** Payload'ın **DOCTYPE/ENTITY tanımı
gerektirip gerektirmediğine** bak. Hedef format (SVG/HTML gibi)
zaten kendi href/src attribute'u üzerinden **doğrudan** (DOCTYPE'siz)
bir harici referansı çekiyorsa → (A), bu skill'in doğrudan kapsamı.
Yalnızca bir DOCTYPE bloğu içinde tanımlanan bir ENTITY üzerinden
çalışıyorsa → (B), önce XXE skill'i.

### 9.3 Blind SSRF — Out-of-band (OOB) — Birincil Confirmation Yöntemi

**SSRF'de OOB, EL/SSTI'dan farklı olarak "opsiyonel bir güçlendirici
kanıt" değil, çoğu zaman TEK mümkün confirmation yöntemidir** —
çünkü blind SSRF'nin doğası gereği hiçbir response reflection'ı
yoktur. Bu nedenle **blind/stored SSRF ihtimali olan** bir hedefte
interactsh-client'ın **erken kurulması tercih edilir** (SHOULD) —
ama bu **mutlak bir önkoşul (MUST) değildir**. Full-response SSRF
(hedeften dönen içerik doğrudan response'ta görülüyor), source-code
üzerinden zaten confirmed bir sink, veya §12.16'daki infrastructure-
mediated SSRF gibi doğrudan gözlemlenebilir senaryolarda, OOB
altyapısı kurulmadan da test başlatılabilir ve confirmation
tamamlanabilir — bu durumlarda interactsh kurulumunu beklemek
gereksiz bir gecikmedir. Pratik kural: hedefte **ilk birkaç generic
probe** (§5) sonucunda full/reflected bir evidence hemen elde
edilirse OOB'a hiç gerek kalmayabilir; ilk sonuçlar blind/belirsiz
görünüyorsa, interactsh-client o noktada (mümkünse yine erken)
başlatılır.

#### OOB Callback Aracı — interactsh-client

**Kurulum:**
```bash
go install -v github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest
```

Go kurulu değilse önce Go'yu kurun (Debian/Ubuntu):
```bash
sudo apt update && sudo apt install -y golang-go
export PATH=$PATH:$(go env GOPATH)/bin
```

**Kullanım — test oturumunun başında bir kez başlat:**
```bash
interactsh-client -v | tee interactsh-oob.log
```
Bu komut sana biricik bir alan adı verir (örn.
`8f3a2b1c.oast.fun` gibi). Bu alan adını, o oturumdaki **tüm**
SSRF adaylarının payload'larında kullan, her payload için path/
subdomain segmentini benzersiz tutarak:

```
# Doğrudan HTTP(S) canary — her aday parametre için ayrı subdomain
http://param1.8f3a2b1c.oast.fun/
https://param2.8f3a2b1c.oast.fun/

# Stored/indirect zincir — hangi tetikleme noktasının çalıştığını
# ayırt etmek için ayrı path segmenti
http://8f3a2b1c.oast.fun/webhook-trigger-test

# DNS-only doğrulama (yalnızca hostname çözümleniyor mu, HTTP hiç
# gitmeden — bkz. §8.4, tek başına koşullu bir kanıttır, otomatik
# "confirmed" sayılmaz):
dns-only-check.8f3a2b1c.oast.fun
```

interactsh-client çıktısı hem **DNS interaction** (yalnızca hostname
çözümlendi) hem **HTTP interaction** (gerçek bir HTTP isteği geldi)
kayıtlarını ayrı ayrı gösterir — bu ayrım, §1.5'teki P2a (DNS
resolution) ile P4 (protocol negotiation/HTTP) arasındaki
farkı doğrudan karşılar; yalnızca DNS kaydı varsa P3'e (confirmed
contact) **kısmen** ulaşılmıştır — §8.4'teki koşullu kural
(benzersizlik + zamanlama korelasyonu + CDN/prefetch eleme) sağlanana
kadar bu tek başına "confirmed" sayılmaz — HTTP kaydı da varsa P4'e
tam olarak ulaşılmıştır ve tek başına yeterlidir.

**Yaşam döngüsü kuralı — KRİTİK:** `interactsh-client`'ı **testin en
başında** başlat ve **log tutarak** çalışır durumda bırak. Agent, o
hedefteki **tüm** SSRF adaylarını tamamen test edip bitirene kadar
interactsh-client'ı **kapatma** — OOB ping'leri (özellikle stored/
indirect senaryolarda, bir webhook'un bir sonraki tetiklenme
döngüsünde) saatler sonra bile gelebilir.

```
1. interactsh-client başlat + logla   (test oturumunun en başında)
2. Tüm SSRF adaylarını sırayla test et (§1 ana akış)
3. Her canary payload'ı gönderdiğinde bunu bir "bekleyen OOB" listesine ekle
4. Tüm adaylar test edildikten sonra bile, interactsh log dosyasını
   bir süre daha izlemeye devam et
5. Ancak TÜM bekleyen OOB'lar için makul bir bekleme süresi geçtikten
   ve rapor yazımına geçildikten sonra interactsh-client'ı kapat
```

**Cloud metadata payload'larında OOB'un rolü — dolaylı confirmation:**
Cloud metadata endpoint'lerinin (§12) kendisi genelde bir OOB
callback yapmaz (`169.254.169.254` saldırganın domain'ine geri
bağlanmaz) — bu durumlarda OOB, metadata payload'ından **önce**,
hedefin gerçekten "hangi cloud'da olduğunu ve outbound istek attığını"
doğrulamak için kullanılır (§1.7 Prerequisite Gate); metadata'nın
kendisinin okunup okunmadığı ise §5.1'deki full/semi-blind evidence
teknikleriyle (response'ta credential görünmesi, veya blind ise
§9.2'deki gibi elde edilen credential'ın dolaylı yollarla dışarı
sızdırılması — örn. metadata içeriğini tekrar bir HTTP isteğinin
parçası olarak canary domain'ine POST ettiren bir zincir, EĞER
hedefte böyle bir ikincil zincir mümkünse) doğrulanır.

### 9.4 Blind SSRF — Timing-based ve Sınırlı Port Taraması

- Açık bir port (hızlı RST/response) ile kapalı/filtrelenmiş bir port
  (timeout'a kadar bekleme) arasındaki timing farkı, port taraması
  için kullanılabilir.
- Ağ varyansını elemek için birden fazla ölçüm al, istatistiksel eşik
  kullan (median + 3×IQR). Timing tek başına **probable** kanıt
  sayılır, confirmed için OOB veya full/reflected evidence tercih
  edilmelidir.
- **Daha yüksek hassasiyet gereken durumlar için (opsiyonel, zorunlu
  değil):** Median+3×IQR eşiği hızlı ve pratik bir varsayılandır;
  eğer ağ varyansı yüksek ve sonuç sınırda (borderline) çıkıyorsa,
  N=5-10'luk iki örneklem grubunu (baseline vs aday port) bir
  **Mann-Whitney U testi** (dağılım normal olmayabileceği için
  t-testinden daha uygun bir non-parametrik alternatif) ile
  karşılaştırmak, "gerçekten farklı mı yoksa tesadüf mü" sorusuna
  daha nicel bir cevap verir. Bu, median+3×IQR'nin **yerine geçen**
  zorunlu bir adım değil, belirsiz/sınırda kalan sonuçlar için
  isteğe bağlı bir hassasiyet artırma adımıdır.

**Sınırlı port taraması kuralı — KRİTİK (§0.2 ile bağlantılı):**
Timing tabanlı port taraması §0.2'deki "kasıtlı ağır DoS yok" kuralına
tabidir. Somut sınırlar:
- Taranacak port sayısı **makul ve hedefe özel gerekçeli** olmalıdır
  (örn. "bu bir Redis/Elasticsearch/internal-admin-panel arıyoruz,
  o yüzden 6379/9200/8080/8443/9090 gibi bilinen portları
  hedefliyoruz" — 1-65535 arası kör bir tam port taraması **yapılmaz**).
- Somut başlangıç değeri: **N=5** ölçüm (baseline ve her port için
  ayrı ayrı), ağ/sunucu varyansı yüksekse N=10'a çıkar.
- Ardışık çok sayıda port denemesi arasında (özellikle rate-limit
  sinyali alındığında) makul bir bekleme uygulanmalı.
