# gopher:// — Binary Protokol Smuggling (§12.3)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

> Her profil şu yapıyla organize edilmiştir: Technology/environment
> fingerprint, Payload sözdizimi, Confirmation/impact payload'ları,
> Kısıtlama/savunma notları, Version/Configuration notları. Tüm
> confirmation payload'ları **otomatik "safe" değildir** — hedefe
> göre hassas bilgi/erişim sağlayabilir (bkz. §10.2).

## 12.3 `gopher://` — Binary Protokol Smuggling (Yüksek Etkili)

Gopher protokolü, ham TCP payload'ını **olduğu gibi** hedef porta
göndermeye izin verdiği için, HTTP client'ının `gopher://` desteği
varsa, SSRF'i **birçok raw/text-tabanlı TCP protokolü için** (Redis,
Memcached, SMTP, hatta ham HTTP request'i) bir payload taşıyıcısı
olarak kullanmak mümkün hale gelir — bu, blind SSRF'i internal servis
**manipülasyonuna** (yalnızca okuma değil, yazma/RCE zincirine)
dönüştürebilen en yüksek etkili tekniklerden biridir. **Kapsam
notu:** Bu "herhangi bir protokol" anlamına gelmez — pratik başarı,
hedef client'ın gopher desteğine, URL-encoding'in doğru
hazırlanmasına, hedef protokolün bağlantı/handshake semantiğine
(TLS gerektiren protokoller gopher ile taşınamaz), timeout
davranışına ve aradaki proxy'lerin ham TCP akışını bozup
bozmadığına bağlıdır — her yeni hedef protokol için ayrı ayrı
doğrulanması gerekir.

- **Sözdizimi:** `gopher://<host>:<port>/_<URL-encoded-binary-payload>`
- **Redis'e komut yazdırma (klasik örnek — RCE'ye zincirlenebilir,
  Redis kendi başına RCE değildir ama SSH key yazma/cron job
  enjeksiyonu gibi bilinen zincirlerle RCE'ye taşınabilir):**
  ```
  gopher://127.0.0.1:6379/_*1%0d%0a%244%0d%0aINFO%0d%0a
  ```
  (Bu, Redis'e ham RESP protokolü ile `INFO` komutu gönderen minimal
  bir örnektir — gerçek bir "dosyaya yaz" zinciri için `CONFIG SET
  dir`/`CONFIG SET dbfilename`/`SET`/`SAVE` komutlarının ardışık
  gopher payload'ına encode edilmesi gerekir; bu encoding'i elle
  yapmak hataya açıktır.)
- **SMTP'ye e-posta gönderme (internal mail relay'i istismar etme):**
  ```
  gopher://127.0.0.1:25/_HELO x%0d%0aMAIL FROM:<a@x.com>%0d%0aRCPT
  TO:<victim@x.com>%0d%0aDATA%0d%0aSubject: test%0d%0a%0d%0abody%0d%0a.%0d%0aQUIT
  ```
- **Memcached'e key yazma:**
  ```
  gopher://127.0.0.1:11211/_%0d%0aset%20key%200%200%205%0d%0avalue%0d%0a
  ```
- **Payload üretim aracı:** Bu tür gopher payload'larını elle
  hazırlamak yerine **Gopherus** (bkz. §15) gibi bir üretici araç
  kullanılması önerilir — Redis/Memcached/SMTP/MySQL/FastCGI için
  doğru RESP/binary encoding'i otomatik üretir, elle hazırlanan
  payload'lardaki encoding hatalarını önler.
- **Kısıtlama:** `gopher://` desteği modern HTTP client'ların
  **çoğunda varsayılan olarak kapalıdır** (örn. cURL'ün bazı
  build'lerinde `--enable-gopher` gerekir, birçok dilin native HTTP
  kütüphanesi hiç desteklemez) — bu protokolü elemez, yalnızca
  hedefin hangi HTTP client'ı/kütüphaneyi kullandığına bağlı olduğunu
  gösterir (§7 fingerprinting'e katkı sağlar: gopher çalışıyorsa bu,
  hedefin muhtemelen PHP `cURL` veya benzer geniş-protokol-destekli
  bir client kullandığının bir sinyalidir).
