# HTTP(S) — Temel Protokol ve Redirect Davranışı (§12.1)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

> Her profil şu yapıyla organize edilmiştir: Technology/environment
> fingerprint, Payload sözdizimi, Confirmation/impact payload'ları,
> Kısıtlama/savunma notları, Version/Configuration notları. Tüm
> confirmation payload'ları **otomatik "safe" değildir** — hedefe
> göre hassas bilgi/erişim sağlayabilir (bkz. §10.2).

## 12.1 HTTP(S) — Temel Protokol ve Redirect Davranışı

- **Generic detection:** §5'teki canary probe'ları (`http://`,
  `https://`) doğrudan bu protokolü hedefler — SSRF'nin en yaygın ve
  en kolay tetiklenen alt türüdür.
- **Redirect takip davranışı — kritik bir fingerprint ve bypass
  aracı:** Hedef uygulamanın HTTP client'ının 3xx redirect'leri
  **otomatik takip edip etmediği** hem bir fingerprint sinyali
  (hangi kütüphane/framework kullanıldığına dair) hem de bir bypass
  aracıdır (§8.2.4). Test etmek için kendi kontrolündeki bir
  endpoint'ten 301/302 ile canary domain'ine yönlendiren bir zincir
  kur, redirect'in takip edilip edilmediğini interactsh log'undan
  doğrula.
- **HTTP method/header kontrolü:** Bazı sink'ler yalnızca `GET`
  atarken bazıları (örn. bir "webhook test" özelliği) `POST` ile
  birlikte kullanıcı tanımlı bir body/header da gönderebilir — bu,
  hedef internal servise (örn. bir internal API'ye) daha zengin bir
  istek attırma imkanı sağlayabilir, keşfedilmeli.
- **Header injection (CRLF) ile SSRF'in genişletilmesi — detaylı akış:**
  Eğer hedef URL'in bir parçası (örn. path/query) sunucunun
  oluşturduğu outbound isteğin **header'larına** enjekte edilebiliyorsa
  (nadir ama gerçek bir zafiyet deseni — CRLF injection ile ek header/
  hatta yeni bir istek satırı ekleme), bu SSRF'nin etkisini "GET isteği
  atma"nın ötesine, **request smuggling**'e kadar genişletebilir:
  ```
  http://internal-host:80/%0d%0aHost:%20other-internal-service%0d%0a%0d%0aGET%20/admin%20HTTP/1.1%0d%0aHost:%20other-internal-service
  ```
  Bu deseni doğrulamak için önce tek bir ek header enjekte edilip
  edilemediği test edilir (basit CRLF injection); başarılıysa,
  **ikinci bir tam HTTP request satırı** enjekte edilip edilemediği
  denenir (yukarıdaki gibi) — bu, sunucunun internal hedefe attığı
  TEK bir isteğin, aslında hedef tarafından **iki ayrı istek** olarak
  yorumlanmasını sağlar (klasik request smuggling deseni, burada
  SSRF'nin kendisi "attacker-controlled" ilk isteği taşıyan araçtır).
  `Content-Length`/`Transfer-Encoding` çift header'ı enjekte edilebiliyorsa
  (CL.TE/TE.CL desenleri) etki daha da büyür — bu durumda kök neden
  hâlâ SSRF'dir (sink URL'i outbound isteğin bir header/body parçasına
  gömüyor) ama bulgu **hem SSRF hem request smuggling** olarak, iki
  ayrı impact boyutuyla raporlanmalıdır.
- **WebSocket şemaları (`ws://`, `wss://`) — internal WebSocket
  servislerine bağlantı:** Bazı SSRF sink'leri (özellikle genel amaçlı
  bir "URL'e bağlan" özelliği sunan proxy/gateway/monitoring
  araçlarında) `ws://`/`wss://` şemasını da kabul edebilir:
  ```
  ws://127.0.0.1:8080/
  ws://<internal-service>:<port>/socket
  ```
  Confirmation için WebSocket handshake'inin tamamlanıp
  tamamlanmadığı (HTTP 101 Switching Protocols yanıtı, veya bir
  timing/OOB sinyali — bir WebSocket sunucusu genelde farklı bir
  timing profiline sahiptir) gözlemlenir. Impact: internal WebSocket
  servisleri (gerçek zamanlı dashboard'lar, iç mesajlaşma/bildirim
  sistemleri, bazı admin panellerinin canlı-güncelleme kanalları) bu
  yolla keşfedilip dinlenmeye çalışılabilir — full-duplex bir kanal
  olduğu için yalnızca "bağlantı kuruldu" kanıtı bile (mesaj içeriği
  görülemese dahi) blind SSRF'den daha zengin bir P4 (protocol
  negotiation) kanıtıdır.
- **HTTP/2 `:authority` pseudo-header notu:** HTTP/2 (ve HTTP/3)
  kullanan modern proxy/gateway'lerde, klasik `Host:` header'ının
  yerini `:authority` pseudo-header'ı alır. Bazı yanlış yapılandırılmış
  proxy'ler routing kararını `:authority` değerine göre verirken
  arkadaki `Host:` header'ını (varsa) hiç kontrol etmez — bu, §12.16'daki
  reverse-proxy/absolute-URI istismarının HTTP/2-özgü bir varyantıdır;
  test için istemcinin (curl `--http2`, veya bir HTTP/2 destekli proxy
  aracı) `:authority` değerini payload olarak manipüle edebilmesi
  gerekir. HTTP/3 (QUIC) hâlâ nadir bir hedef yüzeyidir, bu skill
  bunun için ayrı bir somut payload seti önermez — yalnızca hedefte
  HTTP/3 tespit edilirse (`Alt-Svc: h3` header'ı) yukarıdaki
  `:authority` mantığının orada da geçerli olabileceği not düşülür.
