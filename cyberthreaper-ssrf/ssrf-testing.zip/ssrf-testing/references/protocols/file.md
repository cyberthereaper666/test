# file:// — Yerel Dosya Sistemi Erişimi (§12.2)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

> Her profil şu yapıyla organize edilmiştir: Technology/environment
> fingerprint, Payload sözdizimi, Confirmation/impact payload'ları,
> Kısıtlama/savunma notları, Version/Configuration notları. Tüm
> confirmation payload'ları **otomatik "safe" değildir** — hedefe
> göre hassas bilgi/erişim sağlayabilir (bkz. §10.2).

## 12.2 `file://` — Yerel Dosya Sistemi Erişimi

**Sınıflandırma notu — EN BAŞTA netleştirilmeli:** `file://` ile elde
edilen bir sonuç, kavramsal olarak "SSRF" teriminin network-request
çağrışımıyla tam örtüşmez — burada **ağ üzerinden bir hedefe erişim**
değil, **doğrudan dosya sistemi okuması** söz konusudur. Bu skill'in
raporlama modeli bunu iki eksende ele alır (bkz. §14.1): `delivery:
file` (taşıma mekanizması aynı sink modelini paylaşır — kullanıcı
kontrolündeki bir "URL" hâlâ sink'e besleniyor) + `impact_class:
local-file-read` (nihai etki ağ erişimi değil dosya okumasıdır). Bu
ayrımı okumadan önce bilmek, aşağıdaki payload'ların ne zaman "SSRF"
ne zaman "yerel dosya okuma" olarak raporlanması gerektiğini baştan
netleştirir.

- **Delivery:** `file:///etc/passwd`, `file:///c:/windows/win.ini`
  (Windows), `file://localhost/etc/passwd` (bazı parser'lar host
  kısmının `localhost` olmasını bekler).
- **Kullanım koşulu:** Yalnızca HTTP client kütüphanesinin `file://`
  şemasını desteklediği durumlarda çalışır — birçok modern HTTP
  client kütüphanesi (özellikle dedicated "HTTP only" client'lar)
  bunu **desteklemez**; ama uygulama genel amaçlı bir URL-açma
  fonksiyonu (örn. Java'da `URL.openStream()`, PHP'de
  `file_get_contents()` URL wrapper'ları açıkken, Python'da
  `urllib.request.urlopen()`) kullanıyorsa çalışabilir.
- **Impact:** Doğrudan dosya okuma — bu, SSRF'nin LFI (Local File
  Inclusion) ile kesiştiği tek gerçek nokta olabilir (§3.4'teki
  ayrım burada da geçerlidir: içerik yalnızca **okunuyor/görüntüleniyor**
  ise SSRF/file-read, **kod olarak çalıştırılıyorsa** RFI/LFI).
