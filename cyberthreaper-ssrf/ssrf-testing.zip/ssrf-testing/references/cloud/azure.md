# Azure — Instance Metadata Service (IMDS) (§12.9)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

> Her profil şu yapıyla organize edilmiştir: Technology/environment
> fingerprint, Payload sözdizimi, Confirmation/impact payload'ları,
> Kısıtlama/savunma notları, Version/Configuration notları. Tüm
> confirmation payload'ları **otomatik "safe" değildir** — hedefe
> göre hassas bilgi/erişim sağlayabilir (bkz. §10.2).

## 12.9 Azure — Instance Metadata Service (IMDS)

- **Endpoint:** `http://169.254.169.254/metadata/instance?api-version=2021-02-01`
- **Zorunlu header:**
  ```
  Header: Metadata: true
  ```
- **Managed Identity token endpoint'i:**
  ```
  http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/
  Header: Metadata: true
  ```
