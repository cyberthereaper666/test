# Kubernetes — API Server ve Kubelet (§12.13)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

> Her profil şu yapıyla organize edilmiştir: Technology/environment
> fingerprint, Payload sözdizimi, Confirmation/impact payload'ları,
> Kısıtlama/savunma notları, Version/Configuration notları. Tüm
> confirmation payload'ları **otomatik "safe" değildir** — hedefe
> göre hassas bilgi/erişim sağlayabilir (bkz. §10.2).

## 12.13 Kubernetes — API Server ve Kubelet

- **API server (kimlik doğrulamalı, bir service account token'ı
  gerektirir — SSRF tek başına yeterli olmayabilir, §11'de belirtilen
  zincire bakınız):**
  ```
  https://kubernetes.default.svc/api/v1/namespaces/<ns>/pods
  Header: Authorization: Bearer <service-account-token>
  ```
- **Kubelet API (bazı yapılandırmalarda kimlik doğrulamasız):**
  ```
  http://<node-ip>:10250/pods
  http://<node-ip>:10255/pods       (salt-okunur, eski/bazı ortamlarda hâlâ açık)
  ```
